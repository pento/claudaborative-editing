var J = (r) => {
  throw TypeError(r);
};
var $ = (r, e, t) => e.has(r) || J("Cannot " + t);
var d = (r, e, t) => ($(r, e, "read from private field"), t ? t.call(r) : e.get(r)), y = (r, e, t) => e.has(r) ? J("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(r) : e.set(r, t), w = (r, e, t, s) => ($(r, e, "write to private field"), s ? s.call(r, t) : e.set(r, t), t), m = (r, e, t) => ($(r, e, "access private method"), t);
import { logger } from "@php-wasm/logger";
import { dirname, joinPaths, Semaphore, createSpawnHandler, basename, normalizePath, AcquireTimeoutError, splitShellCommand } from "@php-wasm/util";
import { parse, stringify } from "ini";
import { StreamedFile } from "@php-wasm/stream-compression";
class ErrnoError extends Error {
  constructor(e, t, s) {
    super(t, s), this.name = "ErrnoError", this.errno = e;
  }
}
const FileErrorCodes = {
  0: "No error occurred. System call completed successfully.",
  1: "Argument list too long.",
  2: "Permission denied.",
  3: "Address in use.",
  4: "Address not available.",
  5: "Address family not supported.",
  6: "Resource unavailable, or operation would block.",
  7: "Connection already in progress.",
  8: "Bad file descriptor.",
  9: "Bad message.",
  10: "Device or resource busy.",
  11: "Operation canceled.",
  12: "No child processes.",
  13: "Connection aborted.",
  14: "Connection refused.",
  15: "Connection reset.",
  16: "Resource deadlock would occur.",
  17: "Destination address required.",
  18: "Mathematics argument out of domain of function.",
  19: "Reserved.",
  20: "File exists.",
  21: "Bad address.",
  22: "File too large.",
  23: "Host is unreachable.",
  24: "Identifier removed.",
  25: "Illegal byte sequence.",
  26: "Operation in progress.",
  27: "Interrupted function.",
  28: "Invalid argument.",
  29: "I/O error.",
  30: "Socket is connected.",
  31: "There is a directory under that path.",
  32: "Too many levels of symbolic links.",
  33: "File descriptor value too large.",
  34: "Too many links.",
  35: "Message too large.",
  36: "Reserved.",
  37: "Filename too long.",
  38: "Network is down.",
  39: "Connection aborted by network.",
  40: "Network unreachable.",
  41: "Too many files open in system.",
  42: "No buffer space available.",
  43: "No such device.",
  44: "There is no such file or directory OR the parent directory does not exist.",
  45: "Executable file format error.",
  46: "No locks available.",
  47: "Reserved.",
  48: "Not enough space.",
  49: "No message of the desired type.",
  50: "Protocol not available.",
  51: "No space left on device.",
  52: "Function not supported.",
  53: "The socket is not connected.",
  54: "Not a directory or a symbolic link to a directory.",
  55: "Directory not empty.",
  56: "State not recoverable.",
  57: "Not a socket.",
  58: "Not supported, or operation not supported on socket.",
  59: "Inappropriate I/O control operation.",
  60: "No such device or address.",
  61: "Value too large to be stored in data type.",
  62: "Previous owner died.",
  63: "Operation not permitted.",
  64: "Broken pipe.",
  65: "Protocol error.",
  66: "Protocol not supported.",
  67: "Protocol wrong type for socket.",
  68: "Result too large.",
  69: "Read-only file system.",
  70: "Invalid seek.",
  71: "No such process.",
  72: "Reserved.",
  73: "Connection timed out.",
  74: "Text file busy.",
  75: "Cross-device link.",
  76: "Extension: Capabilities insufficient."
};
function getEmscriptenFsError(r) {
  const e = typeof r == "object" ? r == null ? void 0 : r.errno : null;
  if (e in FileErrorCodes)
    return FileErrorCodes[e];
}
function rethrowFileSystemError(r = "") {
  return function(t) {
    return function(...s) {
      try {
        return t.apply(this, s);
      } catch (n) {
        const i = typeof n == "object" ? n == null ? void 0 : n.errno : null;
        if (i in FileErrorCodes) {
          const o = FileErrorCodes[i], a = typeof s[1] == "string" ? s[1] : null, c = a !== null ? r.replaceAll("{path}", a) : r;
          throw new ErrnoError(
            i,
            `${c}: ${o}`,
            {
              cause: n
            }
          );
        }
        throw n;
      }
    };
  };
}
class FSHelpers {
  /**
   * Reads a file from the PHP filesystem and returns it as a string.
   *
   * @throws {@link @php-wasm/universal:ErrnoError} – If the file doesn't exist.
   * @param FS
   * @param  path - The file path to read.
   * @returns The file contents.
   */
  static readFileAsText(e, t) {
    return new TextDecoder().decode(FSHelpers.readFileAsBuffer(e, t));
  }
  /**
   * Reads a file from the PHP filesystem and returns it as an array buffer.
   *
   * @throws {@link @php-wasm/universal:ErrnoError} – If the file doesn't exist.
   * @param FS
   * @param  path - The file path to read.
   * @returns The file contents.
   */
  static readFileAsBuffer(e, t) {
    return e.readFile(t);
  }
  /**
   * Overwrites data in a file in the PHP filesystem.
   * Creates a new file if one doesn't exist yet.
   *
   * @param FS
   * @param  path - The file path to write to.
   * @param  data - The data to write to the file.
   */
  static writeFile(e, t, s) {
    e.writeFile(t, s);
  }
  /**
   * Removes a file from the PHP filesystem.
   *
   * @throws {@link @php-wasm/universal:ErrnoError} – If the file doesn't exist.
   * @param FS
   * @param  path - The file path to remove.
   */
  static unlink(e, t) {
    e.unlink(t);
  }
  /**
   * Moves a file or directory in the PHP filesystem to a
   * new location.
   *
   * @param FS
   * @param fromPath The path to rename.
   * @param toPath The new path.
   */
  static mv(e, t, s) {
    try {
      const n = e.lookupPath(t).node.mount, i = FSHelpers.fileExists(e, s) ? e.lookupPath(s).node.mount : e.lookupPath(dirname(s)).node.mount;
      n.mountpoint !== i.mountpoint ? (FSHelpers.copyRecursive(e, t, s), FSHelpers.isDir(e, t) ? FSHelpers.rmdir(e, t, { recursive: !0 }) : e.unlink(t)) : e.rename(t, s);
    } catch (n) {
      const i = getEmscriptenFsError(n);
      throw i ? new Error(
        `Could not move ${t} to ${s}: ${i}`,
        {
          cause: n
        }
      ) : n;
    }
  }
  /**
   * Removes a directory from the PHP filesystem.
   *
   * @param FS
   * @param path The directory path to remove.
   * @param options Options for the removal.
   */
  static rmdir(e, t, s = { recursive: !0 }) {
    const n = e.lookupPath(t, { follow: !1 });
    if ((n == null ? void 0 : n.node.mount.mountpoint) === t)
      throw new ErrnoError(10);
    s != null && s.recursive && FSHelpers.listFiles(e, t).forEach((i) => {
      const o = `${t}/${i}`;
      FSHelpers.isDir(e, o) ? FSHelpers.rmdir(e, o, s) : FSHelpers.unlink(e, o);
    }), e.getPath(e.lookupPath(t).node) === e.cwd() && e.chdir(joinPaths(e.cwd(), "..")), e.rmdir(t);
  }
  /**
   * Lists the files and directories in the given directory.
   *
   * @param FS
   * @param  path - The directory path to list.
   * @param  options - Options for the listing.
   * @returns The list of files and directories in the given directory.
   */
  static listFiles(e, t, s = { prependPath: !1 }) {
    if (!FSHelpers.fileExists(e, t))
      return [];
    try {
      const n = e.readdir(t).filter(
        (i) => i !== "." && i !== ".."
      );
      if (s.prependPath) {
        const i = t.replace(/\/$/, "");
        return n.map((o) => `${i}/${o}`);
      }
      return n;
    } catch (n) {
      return logger.error(n, { path: t }), [];
    }
  }
  /**
   * Checks if a directory exists in the PHP filesystem.
   *
   * @param FS
   * @param  path – The path to check.
   * @returns True if the path is a directory, false otherwise.
   */
  static isDir(e, t) {
    return FSHelpers.fileExists(e, t) ? e.isDir(e.lookupPath(t, { follow: !0 }).node.mode) : !1;
  }
  /**
   * Checks if a file exists in the PHP filesystem.
   *
   * @param FS
   * @param  path – The path to check.
   * @returns True if the path is a file, false otherwise.
   */
  static isFile(e, t) {
    return FSHelpers.fileExists(e, t) ? e.isFile(e.lookupPath(t, { follow: !0 }).node.mode) : !1;
  }
  /**
   * Creates a symlink in the PHP filesystem.
   *
   * @param FS
   * @param target
   * @param link
   */
  static symlink(e, t, s) {
    return e.symlink(t, s);
  }
  /**
   * Checks if a path is a symlink in the PHP filesystem.
   *
   * @param FS
   * @param path
   * @returns True if the path is a symlink, false otherwise.
   */
  static isSymlink(e, t) {
    return FSHelpers.fileExists(e, t) ? e.isLink(e.lookupPath(t).node.mode) : !1;
  }
  /**
   * Reads the target of a symlink in the PHP filesystem.
   * @param FS
   * @param path
   * @returns The target of the symlink.
   * @throws {@link @php-wasm/universal:ErrnoError} – If the path is not a symlink.
   */
  static readlink(e, t) {
    return e.readlink(t);
  }
  /**
   * Gets the real path of a file in the PHP filesystem.
   * @param FS
   * @param path
   *
   * @returns The real path of the file.
   */
  static realpath(e, t) {
    return e.lookupPath(t, { follow: !0 }).path;
  }
  /**
   * Checks if a file (or a directory) exists in the PHP filesystem.
   *
   * @param FS
   * @param  path - The file path to check.
   * @returns True if the file exists, false otherwise.
   */
  static fileExists(e, t) {
    try {
      return e.lookupPath(t), !0;
    } catch {
      return !1;
    }
  }
  /**
   * Recursively creates a directory with the given path in the PHP filesystem.
   * For example, if the path is `/root/php/data`, and `/root` already exists,
   * it will create the directories `/root/php` and `/root/php/data`.
   *
   * @param FS
   * @param  path - The directory path to create.
   */
  static mkdir(e, t) {
    e.mkdirTree(t);
  }
  static copyRecursive(e, t, s) {
    try {
      const n = e.lookupPath(t).node;
      if (e.isDir(n.mode)) {
        if (t === s || s.startsWith(`${t}/`))
          throw new ErrnoError(28);
        e.mkdirTree(s);
        const i = e.readdir(t).filter(
          (o) => o !== "." && o !== ".."
        );
        for (const o of i)
          FSHelpers.copyRecursive(
            e,
            joinPaths(t, o),
            joinPaths(s, o)
          );
      } else e.isLink(n.mode) ? e.symlink(e.readlink(t), s) : e.writeFile(s, e.readFile(t));
    } catch (n) {
      const i = getEmscriptenFsError(n);
      throw i ? new Error(
        `Could not copy ${t} to ${s}: ${i}`,
        {
          cause: n
        }
      ) : n;
    }
  }
}
FSHelpers.readFileAsText = rethrowFileSystemError('Could not read "{path}"')(
  FSHelpers.readFileAsText
);
FSHelpers.readFileAsBuffer = rethrowFileSystemError('Could not read "{path}"')(
  FSHelpers.readFileAsBuffer
);
FSHelpers.writeFile = rethrowFileSystemError('Could not write to "{path}"')(
  FSHelpers.writeFile
);
FSHelpers.unlink = rethrowFileSystemError('Could not unlink "{path}"')(
  FSHelpers.unlink
);
FSHelpers.rmdir = rethrowFileSystemError('Could not remove directory "{path}"')(
  FSHelpers.rmdir
);
FSHelpers.listFiles = rethrowFileSystemError(
  'Could not list files in "{path}"'
)(FSHelpers.listFiles);
FSHelpers.isDir = rethrowFileSystemError('Could not stat "{path}"')(
  FSHelpers.isDir
);
FSHelpers.isFile = rethrowFileSystemError('Could not stat "{path}"')(
  FSHelpers.isFile
);
FSHelpers.realpath = rethrowFileSystemError('Could not stat "{path}"')(
  FSHelpers.realpath
);
FSHelpers.fileExists = rethrowFileSystemError('Could not stat "{path}"')(
  FSHelpers.fileExists
);
FSHelpers.mkdir = rethrowFileSystemError('Could not create directory "{path}"')(
  FSHelpers.mkdir
);
const _private = /* @__PURE__ */ new WeakMap();
var x;
class PHPWorker {
  /** @inheritDoc */
  constructor(e, t) {
    y(this, x);
    this.absoluteUrl = "", this.documentRoot = "", this.chroot = null, w(this, x, /* @__PURE__ */ new Map()), this.onMessageListeners = [], _private.set(this, {
      monitor: t
    }), e && this.__internal_setRequestHandler(e);
  }
  __internal_setRequestHandler(e) {
    this.absoluteUrl = e.absoluteUrl, this.documentRoot = e.documentRoot, this.chroot = this.documentRoot, _private.set(this, {
      ..._private.get(this),
      requestHandler: e
    });
  }
  /**
   * @internal
   * @deprecated
   * Do not use this method directly in the code consuming
   * the web API. It will change or even be removed without
   * a warning.
   */
  __internal_getPHP() {
    return _private.get(this).php;
  }
  /**
   * @internal
   * @deprecated
   * Do not use this method directly in the code consuming
   * the web API. It will change or even be removed without
   * a warning.
   */
  __internal_getRequestHandler() {
    return _private.get(this).requestHandler;
  }
  async setPrimaryPHP(e) {
    _private.set(this, {
      ..._private.get(this),
      php: e
    });
  }
  /** @inheritDoc @php-wasm/universal!PHPRequestHandler.pathToInternalUrl  */
  pathToInternalUrl(e) {
    return _private.get(this).requestHandler.pathToInternalUrl(e);
  }
  /** @inheritDoc @php-wasm/universal!PHPRequestHandler.internalUrlToPath  */
  internalUrlToPath(e) {
    return _private.get(this).requestHandler.internalUrlToPath(e);
  }
  /**
   * The onDownloadProgress event listener.
   */
  async onDownloadProgress(e) {
    var t;
    return (t = _private.get(this).monitor) == null ? void 0 : t.addEventListener("progress", e);
  }
  /** @inheritDoc @php-wasm/universal!PHP.mv  */
  async mv(e, t) {
    return _private.get(this).php.mv(e, t);
  }
  /** @inheritDoc @php-wasm/universal!PHP.rmdir  */
  async rmdir(e, t) {
    return _private.get(this).php.rmdir(e, t);
  }
  /** @inheritDoc @php-wasm/universal!PHPRequestHandler.request */
  async request(e) {
    return await _private.get(this).requestHandler.request(e);
  }
  /**
   * Handles a request with streaming support for large responses.
   * Returns a StreamedPHPResponse that allows processing the response
   * body incrementally without buffering the entire response in memory.
   *
   * This is useful for large file downloads (>2GB) that would otherwise
   * exceed JavaScript's Uint8Array size limits.
   *
   * @param request - PHP Request data.
   */
  async requestStreamed(e) {
    return await _private.get(this).requestHandler.requestStreamed(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.run */
  async run(e) {
    const { php: t, reap: s } = await this.acquirePHPInstance();
    try {
      return await t.run(e);
    } finally {
      s();
    }
  }
  /** @inheritDoc @php-wasm/universal!/PHP.cli */
  async cli(e, t) {
    const { php: s, reap: n } = await this.acquirePHPInstance();
    let i;
    try {
      i = await s.cli(e, t);
    } catch (o) {
      throw n(), o;
    }
    return i.finished.finally(n), i;
  }
  /** @inheritDoc @php-wasm/universal!/PHP.chdir */
  chdir(e) {
    return this.chroot = e, _private.get(this).php.chdir(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.chdir */
  cwd() {
    return _private.get(this).php.cwd();
  }
  /**
   * @returns A PHP instance with a consistent chroot.
   */
  async acquirePHPInstance() {
    const { php: e, reap: t } = await _private.get(this).requestHandler.instanceManager.acquirePHPInstance();
    return this.chroot !== null && e.chdir(this.chroot), this.registerWorkerListeners(e), { php: e, reap: t };
  }
  /** @inheritDoc @php-wasm/universal!/PHP.setSapiName */
  setSapiName(e) {
    _private.get(this).php.setSapiName(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.mkdir */
  mkdir(e) {
    return _private.get(this).php.mkdir(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.mkdirTree */
  mkdirTree(e) {
    return _private.get(this).php.mkdirTree(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.readFileAsText */
  readFileAsText(e) {
    return _private.get(this).php.readFileAsText(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.readFileAsBuffer */
  readFileAsBuffer(e) {
    return _private.get(this).php.readFileAsBuffer(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.writeFile */
  writeFile(e, t) {
    return _private.get(this).php.writeFile(e, t);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.unlink */
  unlink(e) {
    return _private.get(this).php.unlink(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.listFiles */
  listFiles(e, t) {
    return _private.get(this).php.listFiles(e, t);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.isDir */
  isDir(e) {
    return _private.get(this).php.isDir(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.isFile */
  isFile(e) {
    return _private.get(this).php.isFile(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.fileExists */
  fileExists(e) {
    return _private.get(this).php.fileExists(e);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.onMessage */
  onMessage(e) {
    return this.onMessageListeners.push(e), async () => {
      this.onMessageListeners = this.onMessageListeners.filter(
        (t) => t !== e
      );
    };
  }
  /** @inheritDoc @php-wasm/universal!/PHP.defineConstant */
  defineConstant(e, t) {
    _private.get(this).php.defineConstant(e, t);
  }
  /** @inheritDoc @php-wasm/universal!/PHP.addEventListener */
  addEventListener(e, t) {
    d(this, x).has(e) || d(this, x).set(e, /* @__PURE__ */ new Set()), d(this, x).get(e).add(t);
  }
  /**
   * Removes an event listener for a PHP event.
   * @param eventType - The type of event to remove the listener from.
   * @param listener - The listener function to be removed.
   */
  removeEventListener(e, t) {
    var s;
    (s = d(this, x).get(e)) == null || s.delete(t);
  }
  dispatchEvent(e) {
    const t = d(this, x).get(e.type);
    if (t)
      for (const s of t)
        s(e);
  }
  registerWorkerListeners(e) {
    e.addEventListener("*", async (t) => {
      this.dispatchEvent(t);
    }), e.onMessage(async (t) => {
      for (const s of this.onMessageListeners) {
        const n = await s(t);
        if (n)
          return n;
      }
      return "";
    });
  }
  async [Symbol.asyncDispose]() {
    var e;
    await ((e = _private.get(this).requestHandler) == null ? void 0 : e[Symbol.asyncDispose]());
  }
}
x = new WeakMap();
function isExitCode(r) {
  return r instanceof Error ? (r == null ? void 0 : r.name) === "ExitStatus" && "status" in r : !1;
}
const RuntimeId = Symbol("RuntimeId"), loadedRuntimes = /* @__PURE__ */ new Map();
let lastRuntimeId = 0;
async function loadPHPRuntime(r, ...e) {
  const t = Object.assign({}, ...e), [s, n, i] = makePromise(), o = r.init(currentJsRuntime, {
    onAbort(c) {
      i(c), logger.error(c);
    },
    ENV: {},
    // Emscripten sometimes prepends a '/' to the path, which
    // breaks vite dev mode. An identity `locateFile` function
    // fixes it.
    locateFile: (c) => c,
    ...t,
    noInitialRun: !0,
    onRuntimeInitialized() {
      t.onRuntimeInitialized && t.onRuntimeInitialized(o), n();
    }
  });
  await s;
  const a = ++lastRuntimeId;
  return o.FS, o.id = a, o.originalExit = o._exit, o._exit = function(c) {
    return o.outboundNetworkProxyServer && (o.outboundNetworkProxyServer.close(), o.outboundNetworkProxyServer.closeAllConnections()), loadedRuntimes.delete(a), o.originalExit(c);
  }, o[RuntimeId] = a, loadedRuntimes.set(a, o), a;
}
function popLoadedRuntime(r, {
  dangerouslyKeepTheRuntimeInTheMap: e = !1
} = {}) {
  var s;
  const t = loadedRuntimes.get(r);
  if (!t)
    throw new Error(`Runtime with id ${r} not found`);
  if (e) {
    if (!((s = process == null ? void 0 : process.env) != null && s.TEST))
      throw new Error("Cannot pop runtime in non-test environment");
    return t;
  }
  return loadedRuntimes.delete(r), t;
}
const currentJsRuntime = function() {
  var r;
  return typeof process < "u" && ((r = process.release) == null ? void 0 : r.name) === "node" ? "NODE" : typeof window < "u" ? "WEB" : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? "WORKER" : "NODE";
}(), makePromise = () => {
  const r = [], e = new Promise((t, s) => {
    r.push(t, s);
  });
  return r.unshift(e), r;
}, responseTexts = {
  500: "Internal Server Error",
  502: "Bad Gateway",
  404: "Not Found",
  403: "Forbidden",
  401: "Unauthorized",
  400: "Bad Request",
  301: "Moved Permanently",
  302: "Found",
  307: "Temporary Redirect",
  308: "Permanent Redirect",
  204: "No Content",
  201: "Created",
  200: "OK"
};
var N, O;
const W = class W {
  constructor(e, t, s, n) {
    /**
     * Headers stream that doesn't get locked when the consumer
     * reads the parsed headers. api.ts transfers the obj.getHeadersStream(),
     * and boot-playground-remote.ts copies the streamedResponse.headers.
     * Both streams must be readable when the StreamedPHPResponse is transferred
     * from the worker thread into the service worker.
     */
    y(this, N);
    /**
     * Headers stream reserved for internal parsing.
     */
    y(this, O);
    this.cachedParsedHeaders = null, this.cachedStdoutBytes = null, this.cachedStderrText = null;
    const [i, o] = e.tee();
    w(this, N, i), w(this, O, o), this.stdout = t, this.stderr = s, this.exitCode = n;
  }
  /**
   * Creates a StreamedPHPResponse from a buffered PHPResponse.
   * Useful for unifying response handling when both types may be returned.
   */
  static fromPHPResponse(e) {
    const t = new ReadableStream({
      start(a) {
        a.enqueue(e.bytes), a.close();
      }
    }), s = [];
    for (const [a, c] of Object.entries(e.headers))
      for (const l of c)
        s.push(`${a}: ${l}`);
    const n = JSON.stringify({
      status: e.httpStatusCode,
      headers: s
    }), i = new ReadableStream({
      start(a) {
        a.enqueue(new TextEncoder().encode(n)), a.close();
      }
    }), o = new ReadableStream({
      start(a) {
        e.errors.length > 0 && a.enqueue(
          new TextEncoder().encode(e.errors)
        ), a.close();
      }
    });
    return new W(
      i,
      t,
      o,
      Promise.resolve(e.exitCode)
    );
  }
  /**
   * Creates a StreamedPHPResponse for a given HTTP status code.
   * Shorthand for `StreamedPHPResponse.fromPHPResponse(PHPResponse.forHttpCode(...))`.
   */
  static forHttpCode(e, t = "") {
    return W.fromPHPResponse(
      PHPResponse.forHttpCode(e, t)
    );
  }
  /**
   * Returns the raw headers stream for serialization purposes.
   * For parsed headers, use the `headers` property instead.
   */
  getHeadersStream() {
    return d(this, N);
  }
  /**
   * True if the response is successful (HTTP status code 200-399),
   * false otherwise.
   */
  async ok() {
    try {
      const e = await this.httpStatusCode;
      return e >= 200 && e < 400;
    } catch {
      return !1;
    }
  }
  /**
   * Resolves when the response has finished processing – either successfully or not.
   */
  get finished() {
    return Promise.allSettled([this.exitCode.finally(() => {
    })]).then(
      () => {
      }
    );
  }
  /**
   * Resolves once HTTP headers are available.
   */
  get headers() {
    return this.getParsedHeaders().then((e) => e.headers);
  }
  /**
   * Resolves once HTTP status code is available.
   */
  get httpStatusCode() {
    return this.getParsedHeaders().then((e) => e.httpStatusCode).then((e) => e !== void 0 ? e : this.getParsedHeaders().then(
      (t) => t.httpStatusCode,
      () => 200
    )).catch(() => 500);
  }
  /**
   * Exposes the stdout bytes as they're produced by the PHP instance
   */
  get stdoutText() {
    return this.stdoutBytes.then(
      (e) => new TextDecoder().decode(e)
    );
  }
  /**
   * Exposes the stdout bytes as they're produced by the PHP instance
   */
  get stdoutBytes() {
    return this.cachedStdoutBytes || (this.cachedStdoutBytes = streamToBytes(this.stdout)), this.cachedStdoutBytes;
  }
  /**
   * Exposes the stderr bytes as they're produced by the PHP instance
   */
  get stderrText() {
    return this.cachedStderrText || (this.cachedStderrText = streamToText(this.stderr)), this.cachedStderrText;
  }
  async getParsedHeaders() {
    return this.cachedParsedHeaders || (this.cachedParsedHeaders = parseHeadersStream(
      d(this, O)
    )), await this.cachedParsedHeaders;
  }
};
N = new WeakMap(), O = new WeakMap();
let StreamedPHPResponse = W;
async function parseHeadersStream(r) {
  const e = await streamToText(r);
  let t;
  try {
    t = JSON.parse(e);
  } catch {
    return { headers: {}, httpStatusCode: 200 };
  }
  const s = {};
  for (const n of t.headers) {
    if (!n.includes(": "))
      continue;
    const i = n.indexOf(": "), o = n.substring(0, i).toLowerCase(), a = n.substring(i + 2);
    o in s || (s[o] = []), s[o].push(a);
  }
  return {
    headers: s,
    httpStatusCode: t.status
  };
}
async function streamToText(r) {
  const e = r.pipeThrough(new TextDecoderStream()).getReader(), t = [];
  for (; ; ) {
    const { done: s, value: n } = await e.read();
    if (s)
      return t.join("");
    n && t.push(n);
  }
}
async function streamToBytes(r) {
  const e = r.getReader(), t = [];
  for (; ; ) {
    const { done: s, value: n } = await e.read();
    if (s) {
      const i = t.reduce(
        (c, l) => c + l.byteLength,
        0
      ), o = new Uint8Array(i);
      let a = 0;
      for (const c of t)
        o.set(c, a), a += c.byteLength;
      return o;
    }
    n && t.push(n);
  }
}
class PHPResponse {
  constructor(e, t, s, n = "", i = 0) {
    this.httpStatusCode = e, this.headers = t, this.bytes = s, this.exitCode = i, this.errors = n;
  }
  static forHttpCode(e, t = "") {
    return new PHPResponse(
      e,
      {},
      new TextEncoder().encode(
        t || responseTexts[e] || ""
      )
    );
  }
  static fromRawData(e) {
    return new PHPResponse(
      e.httpStatusCode,
      e.headers,
      e.bytes,
      e.errors,
      e.exitCode
    );
  }
  static async fromStreamedResponse(e) {
    return await e.finished, new PHPResponse(
      await e.httpStatusCode,
      await e.headers,
      await e.stdoutBytes,
      await e.stderrText,
      await e.exitCode
    );
  }
  /**
   * True if the response is successful (HTTP status code 200-399),
   * false otherwise.
   */
  ok() {
    return this.httpStatusCode >= 200 && this.httpStatusCode < 400;
  }
  toRawData() {
    return {
      headers: this.headers,
      bytes: this.bytes,
      errors: this.errors,
      exitCode: this.exitCode,
      httpStatusCode: this.httpStatusCode
    };
  }
  /**
   * Response body as JSON.
   */
  get json() {
    return JSON.parse(this.text);
  }
  /**
   * Response body as text.
   */
  get text() {
    return new TextDecoder().decode(this.bytes);
  }
}
var _a;
const kError = Symbol("error"), kMessage = Symbol("message");
class ErrorEvent2 extends (_a = Event, _a) {
  /**
   * Create a new `ErrorEvent`.
   *
   * @param type The name of the event
   * @param options A dictionary object that allows for setting
   *                  attributes via object members of the same name.
   */
  constructor(e, t = {}) {
    super(e), this[kError] = t.error === void 0 ? null : t.error, this[kMessage] = t.message === void 0 ? "" : t.message;
  }
  get error() {
    return this[kError];
  }
  get message() {
    return this[kMessage];
  }
}
Object.defineProperty(ErrorEvent2.prototype, "error", { enumerable: !0 });
Object.defineProperty(ErrorEvent2.prototype, "message", { enumerable: !0 });
const ErrorEvent = typeof globalThis.ErrorEvent == "function" ? globalThis.ErrorEvent : ErrorEvent2;
class UnhandledRejectionsTarget extends EventTarget {
  constructor() {
    super(...arguments), this.listenersCount = 0;
  }
  addEventListener(e, t, s) {
    ++this.listenersCount, super.addEventListener(
      e,
      t,
      s
    );
  }
  removeEventListener(e, t, s) {
    --this.listenersCount, super.removeEventListener(
      e,
      t,
      s
    );
  }
  hasListeners() {
    return this.listenersCount > 0;
  }
}
function improveWASMErrorReporting(r) {
  const e = new UnhandledRejectionsTarget();
  for (const t in r.wasmExports)
    if (typeof r.wasmExports[t] == "function") {
      const s = r.wasmExports[t];
      r.wasmExports[t] = function(...n) {
        var i;
        try {
          return s(...n);
        } catch (o) {
          if (!(o instanceof Error))
            throw o;
          r.lastAsyncifyStackSource && (o.cause = r.lastAsyncifyStackSource);
          const a = clarifyErrorMessage(
            o,
            (i = r.lastAsyncifyStackSource) == null ? void 0 : i.stack
          );
          if (e.hasListeners()) {
            o.message = a;
            const c = new ErrorEvent("error", { error: o });
            throw e.dispatchEvent(c), o;
          }
          throw (!isExitCode(o) || o.status !== 0) && showCriticalErrorBox(a), o;
        }
      };
    }
  return e;
}
let functionsMaybeMissingFromAsyncify = [];
function getFunctionsMaybeMissingFromAsyncify() {
  return functionsMaybeMissingFromAsyncify;
}
function clarifyErrorMessage(r, e) {
  if (r.message === "unreachable") {
    let t = UNREACHABLE_ERROR;
    e || (t += `

This stack trace is lacking. For a better one initialize 
the PHP runtime with debug: true, e.g. loadNodeRuntime('8.1', { emscriptenOptions: { debug: true } }).

`);
    const s = new Set(
      extractPHPFunctionsFromStack(e || "")
    );
    let n = r;
    do {
      for (const i of extractPHPFunctionsFromStack(
        n.stack || ""
      ))
        s.add(i);
      n = n.cause;
    } while (n);
    functionsMaybeMissingFromAsyncify = Array.from(s);
    for (const i of s)
      t += `    * ${i}
`;
    return t += `Original error message: ${r.message}
`, t;
  }
  return r.message;
}
const UNREACHABLE_ERROR = `
"unreachable" WASM instruction executed.

The typical reason is a PHP function missing from the ASYNCIFY_ONLY
list when building PHP.wasm.

You will need to file a new issue in the WordPress Playground repository
and paste this error message there:

https://github.com/WordPress/wordpress-playground/issues/new

If you're a core developer, the typical fix is to:

* Isolate a minimal reproduction of the error
* Add a reproduction of the error to php-asyncify.spec.ts in the WordPress Playground repository
* Run 'npm run fix-asyncify'
* Commit the changes, push to the repo, release updated NPM packages

Below is a list of all the PHP functions found in the stack trace to
help with the minimal reproduction. If they're all already listed in
the Dockerfile, you'll need to trigger this error again with long stack
traces enabled. In node.js, you can do it using the --stack-trace-limit=100
CLI option: 

`, redBg = "\x1B[41m", bold = "\x1B[1m", reset = "\x1B[0m", eol = "\x1B[K";
let logged = !1;
function showCriticalErrorBox(r) {
  if (!logged && (logged = !0, !(r != null && r.trim().startsWith("Program terminated with exit")))) {
    logger.log(`${redBg}
${eol}
${bold}  WASM ERROR${reset}${redBg}`);
    for (const e of r.split(`
`))
      logger.log(`${eol}  ${e} `);
    logger.log(`${reset}`);
  }
}
function extractPHPFunctionsFromStack(r) {
  try {
    const e = r.split(`
`).slice(1).map((t) => {
      const s = t.trim().substring(3).split(" ");
      return {
        fn: s.length >= 2 ? s[0] : "<unknown>",
        isWasm: t.includes("wasm:/")
      };
    }).filter(
      ({ fn: t, isWasm: s }) => s && !t.startsWith("dynCall_") && !t.startsWith("invoke_")
    ).map(({ fn: t }) => t);
    return Array.from(new Set(e));
  } catch {
    return [];
  }
}
const STRING = "string", NUMBER = "number", __private__dont__use = Symbol("__private__dont__use");
class PHPExecutionFailureError extends Error {
  constructor(e, t, s) {
    super(e), this.response = t, this.source = s;
  }
}
const PHP_INI_PATH = "/internal/shared/php.ini", AUTO_PREPEND_SCRIPT = "/internal/shared/auto_prepend_file.php", OPCACHE_FILE_FOLDER = "/internal/shared/opcache";
var C, R, b, k, T, H, _, f, Y, X, Q, K, Z, ee, te, re, q, se, z, V;
class PHP {
  /**
   * Initializes a PHP runtime.
   *
   * @internal
   * @param  PHPRuntime - Optional. PHP Runtime ID as initialized by loadPHPRuntime.
   * @param  requestHandlerOptions - Optional. Options for the PHPRequestHandler. If undefined, no request handler will be initialized.
   */
  constructor(r) {
    y(this, f);
    y(this, C);
    y(this, R, !1);
    y(this, b, null);
    y(this, k, /* @__PURE__ */ new Map([
      // Listen to all events
      ["*", /* @__PURE__ */ new Set()]
    ]));
    y(this, T, []);
    y(this, H, {});
    y(this, _, {
      enabled: !1,
      recreateRuntime: () => 0,
      needsRotating: !1,
      maxRequests: 400,
      requestsMade: 0
    });
    this.semaphore = new Semaphore({ concurrency: 1 }), r !== void 0 && this.initializeRuntime(r), this.addEventListener("request.error", (e) => {
      e.source === "php-wasm" && (d(this, _).needsRotating = !0);
    });
  }
  /**
   * Adds an event listener for a PHP event.
   * @param eventType - The type of event to listen for.
   * @param listener - The listener function to be called when the event is triggered.
   */
  addEventListener(r, e) {
    d(this, k).has(r) || d(this, k).set(r, /* @__PURE__ */ new Set()), d(this, k).get(r).add(e);
  }
  /**
   * Removes an event listener for a PHP event.
   * @param eventType - The type of event to remove the listener from.
   * @param listener - The listener function to be removed.
   */
  removeEventListener(r, e) {
    var t;
    (t = d(this, k).get(r)) == null || t.delete(e);
  }
  dispatchEvent(r) {
    const e = [
      ...d(this, k).get(r.type) || [],
      ...d(this, k).get("*") || []
    ];
    if (e)
      for (const t of e)
        t(r);
  }
  /**
   * Listens to message sent by the PHP code.
   *
   * To dispatch messages, call:
   *
   *     post_message_to_js(string $data)
   *
   *     Arguments:
   *         $data (string) – Data to pass to JavaScript.
   *
   * @example
   *
   * ```ts
   * const php = await PHP.load('8.0');
   *
   * php.onMessage(
   *     // The data is always passed as a string
   *     function (data: string) {
   *         // Let's decode and log the data:
   *         console.log(JSON.parse(data));
   *     }
   * );
   *
   * // Now that we have a listener in place, let's
   * // dispatch a message:
   * await php.run({
   *     code: `<?php
   *         post_message_to_js(
   *             json_encode([
   *                 'post_id' => '15',
   *                 'post_title' => 'This is a blog post!'
   *             ])
   *         ));
   *     `,
   * });
   * ```
   *
   * @param listener Callback function to handle the message.
   */
  onMessage(r) {
    return d(this, T).push(r), async () => {
      w(this, T, d(this, T).filter(
        (e) => e !== r
      ));
    };
  }
  async setSpawnHandler(handler) {
    typeof handler == "string" && (handler = createSpawnHandler(eval(handler))), this[__private__dont__use].spawnProcess = handler;
  }
  /** @deprecated Use PHPRequestHandler instead. */
  get absoluteUrl() {
    return this.requestHandler.absoluteUrl;
  }
  /** @deprecated Use PHPRequestHandler instead. */
  get documentRoot() {
    return this.requestHandler.documentRoot;
  }
  /** @deprecated Use PHPRequestHandler instead. */
  pathToInternalUrl(r) {
    return this.requestHandler.pathToInternalUrl(r);
  }
  /** @deprecated Use PHPRequestHandler instead. */
  internalUrlToPath(r) {
    return this.requestHandler.internalUrlToPath(r);
  }
  initializeRuntime(r) {
    if (this[__private__dont__use])
      throw new Error("PHP runtime already initialized.");
    const e = popLoadedRuntime(r);
    if (!e)
      throw new Error("Invalid PHP runtime id.");
    if (this[__private__dont__use] = e, this[__private__dont__use].ccall(
      "wasm_set_phpini_path",
      null,
      ["string"],
      [PHP_INI_PATH]
    ), !this.fileExists(PHP_INI_PATH)) {
      const t = [
        // OPCache
        "opcache.enable = 1",
        "opcache.enable_cli = 1",
        "opcache.jit = 0",
        "opcache.interned_strings_buffer = 8",
        "opcache.max_accelerated_files = 1000",
        "opcache.memory_consumption = 64",
        "opcache.max_wasted_percentage = 5",
        "opcache.file_cache = " + OPCACHE_FILE_FOLDER,
        // Always enable the file cache.
        "opcache.file_cache_only = 1",
        "opcache.file_cache_consistency_checks = 1"
      ];
      this.fileExists(OPCACHE_FILE_FOLDER) || this.mkdir(OPCACHE_FILE_FOLDER), this.writeFile(
        PHP_INI_PATH,
        [
          "auto_prepend_file=" + AUTO_PREPEND_SCRIPT,
          "memory_limit=256M",
          "ignore_repeated_errors = 1",
          "error_reporting = E_ALL",
          "display_errors = 1",
          "html_errors = 1",
          "display_startup_errors = On",
          "log_errors = 1",
          "always_populate_raw_post_data = -1",
          "upload_max_filesize = 2000M",
          "post_max_size = 2000M",
          "allow_url_fopen = On",
          "allow_url_include = Off",
          "session.save_path = /home/web_user",
          "implicit_flush = 1",
          "output_buffering = 0",
          "max_execution_time = 0",
          "max_input_time = -1",
          ...t
        ].join(`
`)
      );
    }
    this.fileExists(AUTO_PREPEND_SCRIPT) || this.writeFile(
      AUTO_PREPEND_SCRIPT,
      `<?php
				// Define constants set via defineConstant() calls
				if(file_exists('/internal/shared/consts.json')) {
					$consts = json_decode(file_get_contents('/internal/shared/consts.json'), true);
					foreach ($consts as $const => $value) {
						if (!defined($const) && is_scalar($value)) {
							define($const, $value);
						}
					}
				}
				// Preload all the files from /internal/shared/preload
				foreach (glob('/internal/shared/preload/*.php') as $file) {
					require_once $file;
				}
				`
    ), e.onMessage = async (t) => {
      for (const s of d(this, T)) {
        const n = await s(t);
        if (n)
          return n;
      }
      return "";
    }, w(this, b, improveWASMErrorReporting(e)), this.dispatchEvent({
      type: "runtime.initialized"
    });
  }
  /** @inheritDoc */
  async setSapiName(r) {
    if (this[__private__dont__use].ccall(
      "wasm_set_sapi_name",
      NUMBER,
      [STRING],
      [r]
    ) !== 0)
      throw new Error(
        "Could not set SAPI name. This can only be done before the PHP WASM module is initialized.Did you already dispatch any requests?"
      );
    w(this, C, r);
  }
  /**
   * Changes the current working directory in the PHP filesystem.
   * This is the directory that will be used as the base for relative paths.
   * For example, if the current working directory is `/root/php`, and the
   * path is `data`, the absolute path will be `/root/php/data`.
   *
   * @param  path - The new working directory.
   */
  chdir(r) {
    this[__private__dont__use].FS.chdir(r);
  }
  /**
   * Gets the current working directory in the PHP filesystem.
   *
   * @returns The current working directory.
   */
  cwd() {
    return this[__private__dont__use].FS.cwd();
  }
  /**
   * Changes the permissions of a file or directory.
   * @param path - The path to the file or directory.
   * @param mode - The new permissions.
   */
  chmod(r, e) {
    this[__private__dont__use].FS.chmod(r, e);
  }
  /**
   * Do not use. Use new PHPRequestHandler() instead.
   * @deprecated
   */
  async request(r) {
    if (logger.debug(
      "PHP.request() is deprecated. Please use new PHPRequestHandler() instead."
    ), !this.requestHandler)
      throw new Error("No request handler available.");
    return this.requestHandler.request(r);
  }
  /**
   * Runs PHP code.
   *
   * This low-level method directly interacts with the WebAssembly
   * PHP interpreter.
   *
   * Every time you call run(), it prepares the PHP
   * environment and:
   *
   * * Resets the internal PHP state
   * * Populates superglobals ($_SERVER, $_GET, etc.)
   * * Handles file uploads
   * * Populates input streams (stdin, argv, etc.)
   * * Sets the current working directory
   *
   * You can use run() in two primary modes:
   *
   * ### Code snippet mode
   *
   * In this mode, you pass a string containing PHP code to run.
   *
   * ```ts
   * const result = await php.run({
   * 	code: `<?php echo "Hello world!";`
   * });
   * // result.text === "Hello world!"
   * ```
   *
   * In this mode, information like __DIR__ or __FILE__ isn't very
   * useful because the code is not associated with any file.
   *
   * Under the hood, the PHP snippet is passed to the `zend_eval_string`
   * C function.
   *
   * ### File mode
   *
   * In the file mode, you pass a scriptPath and PHP executes a file
   * found at a that path:
   *
   * ```ts
   * php.writeFile(
   * 	"/www/index.php",
   * 	`<?php echo "Hello world!";"`
   * );
   * const result = await php.run({
   * 	scriptPath: "/www/index.php"
   * });
   * // result.text === "Hello world!"
   * ```
   *
   * In this mode, you can rely on path-related information like __DIR__
   * or __FILE__.
   *
   * Under the hood, the PHP file is executed with the `php_execute_script`
   * C function.
   *
   * The `run()` method cannot be used in conjunction with `cli()`.
   *
   * @example
   * ```js
   * const result = await php.run({
   * 	code: `<?php
   * 		$fp = fopen('php://stderr', 'w');
   * 		fwrite($fp, "Hello, world!");
   * 	`
   * });
   * // result.errors === "Hello, world!"
   * ```
   *
   * @deprecated Use stream() instead.
   * @param  request - PHP runtime options.
   */
  async run(r) {
    const e = await this.runStream(r), t = await PHPResponse.fromStreamedResponse(e);
    if (t.exitCode !== 0)
      throw new PHPExecutionFailureError(
        `PHP.run() failed with exit code ${t.exitCode}. 

=== Stdout ===
 ${t.text}

=== Stderr ===
 ${t.errors}`,
        t,
        "request"
      );
    return t;
  }
  /**
   * Runs PHP code and returns a StreamedPHPResponse object that can be used to
   * process the output incrementally.
   *
   * This low-level method directly interacts with the WebAssembly
   * PHP interpreter and provides streaming capabilities for processing
   * PHP output as it becomes available.
   *
   * Every time you call stream(), it prepares the PHP
   * environment and:
   *
   * * Resets the internal PHP state
   * * Populates superglobals ($_SERVER, $_GET, etc.)
   * * Handles file uploads
   * * Populates input streams (stdin, argv, etc.)
   * * Sets the current working directory
   *
   * You can use stream() in two primary modes:
   *
   * ### Code snippet mode
   *
   * In this mode, you pass a string containing PHP code to run.
   *
   * ```ts
   * const streamedResponse = await php.stream({
   * 	code: `<?php echo "Hello world!";`
   * });
   * // Process output incrementally
   * for await (const chunk of streamedResponse.text) {
   * 	console.log(chunk);
   * }
   * ```
   *
   * In this mode, information like __DIR__ or __FILE__ isn't very
   * useful because the code is not associated with any file.
   *
   * Under the hood, the PHP snippet is passed to the `zend_eval_string`
   * C function.
   *
   * ### File mode
   *
   * In the file mode, you pass a scriptPath and PHP executes a file
   * found at that path:
   *
   * ```ts
   * php.writeFile(
   * 	"/www/index.php",
   * 	`<?php echo "Hello world!";"`
   * );
   * const streamedResponse = await php.stream({
   * 	scriptPath: "/www/index.php"
   * });
   * // Process output incrementally
   * for await (const chunk of streamedResponse.text) {
   * 	console.log(chunk);
   * }
   * ```
   *
   * In this mode, you can rely on path-related information like __DIR__
   * or __FILE__.
   *
   * Under the hood, the PHP file is executed with the `php_execute_script`
   * C function.
   *
   * The `stream()` method cannot be used in conjunction with `cli()`.
   *
   * @example
   * ```js
   * const streamedResponse = await php.stream({
   * 	code: `<?php
   * 		for ($i = 0; $i < 5; $i++) {
   * 			echo "Line $i\n";
   * 			flush();
   * 		}
   * 	`
   * });
   *
   * // Process output as it becomes available
   * for await (const chunk of streamedResponse.text) {
   * 	console.log('Received:', chunk);
   * }
   *
   * // Get the final exit code
   * const exitCode = await streamedResponse.exitCode;
   * console.log('Exit code:', exitCode);
   * ```
   *
   * @see run() – a synchronous version of this method.
   * @param request - PHP runtime options.
   * @returns A StreamedPHPResponse object.
   */
  async runStream(r) {
    const e = await this.semaphore.acquire();
    let t;
    const s = m(this, f, V).call(this, async () => {
      if (d(this, R) || (await this[__private__dont__use].ccall(
        "php_wasm_init",
        null,
        [],
        [],
        {
          isAsync: !0
        }
      ), w(this, R, !0)), r.scriptPath && !this.fileExists(r.scriptPath))
        throw new Error(
          `The script path "${r.scriptPath}" does not exist.`
        );
      m(this, f, X).call(this, r.relativeUri || ""), m(this, f, ee).call(this, r.method || "GET");
      const i = normalizeHeaders(r.headers || {}), o = i.host || "example.com:443", a = m(this, f, Z).call(this, o, r.protocol || "http");
      if (m(this, f, Q).call(this, o), m(this, f, K).call(this, a), m(this, f, te).call(this, i), r.body && (t = m(this, f, re).call(this, r.body)), typeof r.code == "string")
        this.writeFile("/internal/eval.php", r.code), m(this, f, q).call(this, "/internal/eval.php");
      else if (typeof r.scriptPath == "string")
        m(this, f, q).call(this, r.scriptPath || "");
      else
        throw new TypeError(
          "The request object must have either a `code` or a `scriptPath` property."
        );
      const c = m(this, f, Y).call(this, r.$_SERVER, i, a);
      for (const u in c)
        m(this, f, se).call(this, u, c[u]);
      const l = r.env || {};
      for (const u in l)
        m(this, f, z).call(this, u, l[u]);
      return await this[__private__dont__use].ccall(
        "wasm_sapi_handle_request",
        NUMBER,
        [],
        [],
        { async: !0 }
      );
    }), n = () => {
      if (t)
        try {
          this[__private__dont__use].free(t);
        } catch (i) {
          logger.error(i);
        }
      e(), this.dispatchEvent({
        type: "request.end"
      });
    };
    return s.then(
      (i) => (i.finished.finally(n), i),
      (i) => {
        try {
          n();
        } catch {
        } finally {
          throw i;
        }
      }
    );
  }
  /**
   * Defines a constant in the PHP runtime.
   * @param key - The name of the constant.
   * @param value - The value of the constant.
   */
  defineConstant(r, e) {
    let t = {};
    try {
      t = JSON.parse(
        this.fileExists("/internal/shared/consts.json") && this.readFileAsText("/internal/shared/consts.json") || "{}"
      );
    } catch {
    }
    this.writeFile(
      "/internal/shared/consts.json",
      JSON.stringify({
        ...t,
        [r]: e
      })
    );
  }
  /**
   * Recursively creates a directory with the given path in the PHP filesystem.
   * For example, if the path is `/root/php/data`, and `/root` already exists,
   * it will create the directories `/root/php` and `/root/php/data`.
   *
   * @param  path - The directory path to create.
   */
  mkdir(r) {
    const e = FSHelpers.mkdir(this[__private__dont__use].FS, r);
    return this.dispatchEvent({ type: "filesystem.write" }), e;
  }
  /**
   * @deprecated Use mkdir instead.
   */
  mkdirTree(r) {
    return FSHelpers.mkdir(this[__private__dont__use].FS, r);
  }
  /**
   * Reads a file from the PHP filesystem and returns it as a string.
   *
   * @throws {@link @php-wasm/universal:ErrnoError} – If the file doesn't exist.
   * @param  path - The file path to read.
   * @returns The file contents.
   */
  readFileAsText(r) {
    return FSHelpers.readFileAsText(this[__private__dont__use].FS, r);
  }
  /**
   * Reads a file from the PHP filesystem and returns it as an array buffer.
   *
   * @throws {@link @php-wasm/universal:ErrnoError} – If the file doesn't exist.
   * @param  path - The file path to read.
   * @returns The file contents.
   */
  readFileAsBuffer(r) {
    return FSHelpers.readFileAsBuffer(this[__private__dont__use].FS, r);
  }
  /**
   * Overwrites data in a file in the PHP filesystem.
   * Creates a new file if one doesn't exist yet.
   *
   * @param  path - The file path to write to.
   * @param  data - The data to write to the file.
   */
  writeFile(r, e) {
    const t = FSHelpers.writeFile(
      this[__private__dont__use].FS,
      r,
      e
    );
    return this.dispatchEvent({ type: "filesystem.write" }), t;
  }
  /**
   * Removes a file from the PHP filesystem.
   *
   * @throws {@link @php-wasm/universal:ErrnoError} – If the file doesn't exist.
   * @param  path - The file path to remove.
   */
  unlink(r) {
    const e = FSHelpers.unlink(this[__private__dont__use].FS, r);
    return this.dispatchEvent({ type: "filesystem.write" }), e;
  }
  /**
   * Moves a file or directory in the PHP filesystem to a
   * new location.
   *
   * @param fromPath The path to rename.
   * @param toPath The new path.
   */
  mv(r, e) {
    const t = FSHelpers.mv(
      this[__private__dont__use].FS,
      r,
      e
    );
    return this.dispatchEvent({ type: "filesystem.write" }), t;
  }
  /**
   * Copies a file or directory in the PHP filesystem to a
   * new location.
   *
   * @param fromPath The source path.
   * @param toPath The target path.
   */
  cp(r, e) {
    const t = FSHelpers.copyRecursive(
      this[__private__dont__use].FS,
      r,
      e
    );
    return this.dispatchEvent({ type: "filesystem.write" }), t;
  }
  /**
   * Removes a directory from the PHP filesystem.
   *
   * @param path The directory path to remove.
   * @param options Options for the removal.
   */
  rmdir(r, e = { recursive: !0 }) {
    const t = FSHelpers.rmdir(
      this[__private__dont__use].FS,
      r,
      e
    );
    return this.dispatchEvent({ type: "filesystem.write" }), t;
  }
  /**
   * Lists the files and directories in the given directory.
   *
   * @param  path - The directory path to list.
   * @param  options - Options for the listing.
   * @returns The list of files and directories in the given directory.
   */
  listFiles(r, e = { prependPath: !1 }) {
    return FSHelpers.listFiles(
      this[__private__dont__use].FS,
      r,
      e
    );
  }
  /**
   * Checks if a directory exists in the PHP filesystem.
   *
   * @param  path – The path to check.
   * @returns True if the path is a directory, false otherwise.
   */
  isDir(r) {
    return FSHelpers.isDir(this[__private__dont__use].FS, r);
  }
  /**
   * Checks if a file exists in the PHP filesystem.
   *
   * @param  path – The path to check.
   * @returns True if the path is a file, false otherwise.
   */
  isFile(r) {
    return FSHelpers.isFile(this[__private__dont__use].FS, r);
  }
  /**
   * Creates a symlink in the PHP filesystem.
   * @param target
   * @param path
   */
  symlink(r, e) {
    return FSHelpers.symlink(this[__private__dont__use].FS, r, e);
  }
  /**
   * Checks if a path is a symlink in the PHP filesystem.
   *
   * @param path
   * @returns True if the path is a symlink, false otherwise.
   */
  isSymlink(r) {
    return FSHelpers.isSymlink(this[__private__dont__use].FS, r);
  }
  /**
   * Reads the target of a symlink in the PHP filesystem.
   *
   * @param path
   * @returns The target of the symlink.
   */
  readlink(r) {
    return FSHelpers.readlink(this[__private__dont__use].FS, r);
  }
  /**
   * Resolves the real path of a file in the PHP filesystem.
   * @param path
   * @returns The real path of the file.
   */
  realpath(r) {
    return FSHelpers.realpath(this[__private__dont__use].FS, r);
  }
  /**
   * Checks if a file (or a directory) exists in the PHP filesystem.
   *
   * @param  path - The file path to check.
   * @returns True if the file exists, false otherwise.
   */
  fileExists(r) {
    return FSHelpers.fileExists(this[__private__dont__use].FS, r);
  }
  /**
   * Enables inline PHP runtime rotation after a certain number of requests
   * or an internal crash.
   */
  enableRuntimeRotation(r) {
    w(this, _, {
      ...d(this, _),
      enabled: !0,
      recreateRuntime: r.recreateRuntime,
      maxRequests: r.maxRequests ?? 400
    });
  }
  async rotateRuntime() {
    if (!d(this, _).enabled)
      throw new Error(
        "Runtime rotation is not enabled. Call enableRuntimeRotation() first."
      );
    await this.hotSwapPHPRuntime(
      await d(this, _).recreateRuntime()
    ), d(this, _).requestsMade = 0, d(this, _).needsRotating = !1;
  }
  /**
   * Hot-swaps the PHP runtime for a new one without
   * interrupting the operations of this PHP instance.
   *
   * @param runtime
   */
  async hotSwapPHPRuntime(r) {
    const e = this[__private__dont__use].FS, t = this.listFiles("/").map((c) => `/${c}`), s = this[__private__dont__use].spawnProcess, n = e.cwd();
    e.chdir("/");
    const i = Object.entries(d(this, H)).map(
      ([c, l]) => ({
        mountHandler: l.mountHandler,
        vfsPath: c
      })
    ), o = Object.values(
      d(this, H)
    ).reverse();
    for (const c of o)
      await c.unmount();
    try {
      this.exit();
    } catch {
    }
    this.initializeRuntime(r), s && (this[__private__dont__use].spawnProcess = s), d(this, C) && this.setSapiName(d(this, C));
    const a = this[__private__dont__use].FS;
    for (const c of t)
      c && c !== "/request" && copyMEMFSNodes(e, a, c);
    for (const { mountHandler: c, vfsPath: l } of i)
      this.mkdir(l), await this.mount(l, c);
    try {
      a.chdir(n);
    } catch (c) {
      throw new Error(
        `Failed to restore CWD to ${n} after PHP runtime rotation.`,
        {
          cause: c
        }
      );
    }
  }
  /**
   * Mounts a filesystem to a given path in the PHP filesystem.
   *
   * @param  virtualFSPath - Where to mount it in the PHP virtual filesystem.
   * @param  mountHandler - The mount handler to use.
   * @return Unmount function to unmount the filesystem.
   */
  async mount(r, e) {
    const t = await e(
      this,
      this[__private__dont__use].FS,
      r
    ), s = {
      mountHandler: e,
      unmount: async () => {
        await t(), delete d(this, H)[r];
      }
    };
    return d(this, H)[r] = s, () => {
      s.unmount();
    };
  }
  /**
   * Starts a PHP CLI session with given arguments.
   *
   * This method can only be used when PHP was compiled with the CLI SAPI
   * and it cannot be used in conjunction with `run()`.
   *
   * Once this method finishes running, the PHP instance is no
   * longer usable and should be discarded. This is because PHP
   * internally cleans up all the resources and calls exit().
   *
   * @param  argv - The arguments to pass to the CLI.
   * @returns The exit code of the CLI session.
   */
  async cli(r, e = {}) {
    if (basename(r[0] ?? "") !== "php")
      return this.subProcess(r, e);
    d(this, R) && (d(this, _).needsRotating = !0);
    const t = await this.semaphore.acquire();
    return await m(this, f, V).call(this, () => {
      const s = e.env || {};
      for (const [n, i] of Object.entries(s))
        m(this, f, z).call(this, n, i);
      r = [r[0], "-c", PHP_INI_PATH, ...r.slice(1)];
      for (const n of r)
        this[__private__dont__use].ccall(
          "wasm_add_cli_arg",
          null,
          [STRING],
          [n]
        );
      return this[__private__dont__use].ccall("run_cli", null, [], [], {
        async: !0
      });
    }).then((s) => (s.exitCode.finally(t), s)).finally(() => {
      d(this, _).needsRotating = !0;
    });
  }
  /**
   * Runs an arbitrary CLI command using the spawn handler associated
   * with this PHP instance.
   *
   * @param argv
   * @param options
   * @returns StreamedPHPResponse.
   */
  async subProcess(r, e = {}) {
    const t = this[__private__dont__use].spawnProcess(
      r[0],
      r.slice(1),
      {
        env: e.env,
        cwd: e.cwd ?? this.cwd()
      }
    ), s = await createInvertedReadableStream();
    t.on("error", (a) => {
      safeStreamError$1(s.controller, a);
    });
    const n = (a) => {
      try {
        s.controller.enqueue(a);
      } catch {
        t.stderr.off("data", n);
      }
    };
    t.stderr.on("data", n);
    const i = await createInvertedReadableStream(), o = (a) => {
      try {
        i.controller.enqueue(a);
      } catch {
        t.stdout.off("data", o);
      }
    };
    return t.stdout.on("data", o), t.on("exit", () => {
      setTimeout(() => {
        try {
          s.controller.close();
        } catch {
        }
        try {
          i.controller.close();
        } catch {
        }
      }, 0);
    }), new StreamedPHPResponse(
      // Headers stream
      new ReadableStream({
        start(a) {
          a.close();
        }
      }),
      i.stream,
      s.stream,
      // Exit code
      new Promise((a) => {
        t.on("exit", (c) => {
          a(c);
        });
      })
    );
  }
  setSkipShebang(r) {
    this[__private__dont__use].ccall(
      "wasm_set_skip_shebang",
      null,
      [NUMBER],
      [r ? 1 : 0]
    );
  }
  exit(r = 0) {
    this.dispatchEvent({
      type: "runtime.beforeExit"
    });
    try {
      this[__private__dont__use]._exit(r);
    } catch {
    }
    w(this, R, !1), w(this, b, null), this[__private__dont__use] && (delete this[__private__dont__use].onMessage, delete this[__private__dont__use]);
  }
  [Symbol.dispose]() {
    this.exit(0);
  }
}
C = new WeakMap(), R = new WeakMap(), b = new WeakMap(), k = new WeakMap(), T = new WeakMap(), H = new WeakMap(), _ = new WeakMap(), f = new WeakSet(), /**
 * Prepares the $_SERVER entries for the PHP runtime.
 *
 * @param defaults Default entries to include in $_SERVER.
 * @param headers HTTP headers to include in $_SERVER (as HTTP_ prefixed entries).
 * @param port HTTP port, used to determine infer $_SERVER['HTTPS'] value if none
 *             was provided.
 * @returns Computed $_SERVER entries.
 */
Y = function(r, e, t) {
  const s = {
    ...r || {}
  };
  s.HTTPS = s.HTTPS || t === 443 ? "on" : "off";
  for (const n in e) {
    let i = "HTTP_";
    ["content-type", "content-length"].includes(n.toLowerCase()) && (i = ""), s[`${i}${n.toUpperCase().replace(/-/g, "_")}`] = e[n];
  }
  return s;
}, X = function(r) {
  this[__private__dont__use].ccall(
    "wasm_set_request_uri",
    null,
    [STRING],
    [r]
  );
  let e = "";
  r.includes("?") && (e = r.substring(r.indexOf("?") + 1)), this[__private__dont__use].ccall(
    "wasm_set_query_string",
    null,
    [STRING],
    [e]
  );
}, Q = function(r) {
  this[__private__dont__use].ccall(
    "wasm_set_request_host",
    null,
    [STRING],
    [r]
  );
}, K = function(r) {
  this[__private__dont__use].ccall(
    "wasm_set_request_port",
    null,
    [NUMBER],
    [r]
  );
}, Z = function(r, e) {
  let t;
  try {
    t = parseInt(new URL(r).port, 10);
  } catch {
  }
  return (!t || isNaN(t) || t === 80) && (t = e === "https" ? 443 : 80), t;
}, ee = function(r) {
  this[__private__dont__use].ccall(
    "wasm_set_request_method",
    null,
    [STRING],
    [r]
  );
}, te = function(r) {
  r.cookie && this[__private__dont__use].ccall(
    "wasm_set_cookies",
    null,
    [STRING],
    [r.cookie]
  ), r["content-type"] && this[__private__dont__use].ccall(
    "wasm_set_content_type",
    null,
    [STRING],
    [r["content-type"]]
  ), r["content-length"] && this[__private__dont__use].ccall(
    "wasm_set_content_length",
    null,
    [NUMBER],
    [parseInt(r["content-length"], 10)]
  );
}, re = function(r) {
  let e, t;
  typeof r == "string" ? (logger.warn(
    "Passing a string as the request body is deprecated. Please use a Uint8Array instead. See https://github.com/WordPress/wordpress-playground/issues/997 for more details"
  ), t = this[__private__dont__use].lengthBytesUTF8(r), e = t + 1) : (t = r.byteLength, e = r.byteLength);
  const s = this[__private__dont__use].malloc(e);
  if (!s)
    throw new Error("Could not allocate memory for the request body.");
  return typeof r == "string" ? this[__private__dont__use].stringToUTF8(
    r,
    s,
    e + 1
  ) : this[__private__dont__use].HEAPU8.set(r, s), this[__private__dont__use].ccall(
    "wasm_set_request_body",
    null,
    [NUMBER],
    [s]
  ), this[__private__dont__use].ccall(
    "wasm_set_content_length",
    null,
    [NUMBER],
    [t]
  ), s;
}, q = function(r) {
  this[__private__dont__use].ccall(
    "wasm_set_path_translated",
    null,
    [STRING],
    [r]
  );
}, se = function(r, e) {
  this[__private__dont__use].ccall(
    "wasm_add_SERVER_entry",
    null,
    [STRING, STRING],
    [r, e]
  );
}, z = function(r, e) {
  this[__private__dont__use].ccall(
    "wasm_add_ENV_entry",
    null,
    [STRING, STRING],
    [r, e]
  );
}, V = async function(r) {
  d(this, _).enabled && d(this, _).needsRotating && await this.rotateRuntime(), ++d(this, _).requestsMade, d(this, _).requestsMade >= d(this, _).maxRequests && (d(this, _).needsRotating = !0);
  const e = this[__private__dont__use], t = await createInvertedReadableStream();
  e.onHeaders = (h) => {
    a || s || t.controller.enqueue(h.slice());
  };
  let s = !1;
  const n = () => {
    s || (s = !0, t.controller.close());
  }, i = await createInvertedReadableStream();
  e.onStdout = (h) => {
    n(), !a && i.controller.enqueue(h.slice());
  };
  const o = await createInvertedReadableStream();
  e.onStderr = (h) => {
    a || o.controller.enqueue(h.slice());
  };
  let a = !1, c;
  const u = (async () => {
    var h;
    try {
      return await Promise.race([
        r(),
        new Promise((g, E) => {
          var j;
          c = (G) => {
            isExitCode(G.error) || E(G.error);
          }, (j = d(this, b)) == null || j.addEventListener(
            "error",
            c,
            { once: !0 }
          );
        })
      ]);
    } catch (p) {
      if (isExitCode(p))
        return p.status;
      safeStreamError$1(i.controller, p), safeStreamError$1(o.controller, p), safeStreamError$1(t.controller, p), a = !0;
      for (const g in this)
        typeof this[g] == "function" && (this[g] = () => {
          throw new Error(
            "PHP runtime has crashed – see the earlier error for details."
          );
        });
      throw this.functionsMaybeMissingFromAsyncify = getFunctionsMaybeMissingFromAsyncify(), p;
    } finally {
      a || (safeStreamClose$1(i.controller), safeStreamClose$1(o.controller), n(), a = !0), (h = d(this, b)) == null || h.removeEventListener(
        "error",
        c
      );
    }
  })().then(
    (h) => (h !== 0 && this.dispatchEvent({
      type: "request.error",
      error: new Error(
        `PHP.run() failed with exit code ${h}.`
      ),
      // Distinguish between PHP request and PHP-wasm errors
      source: "php-wasm"
    }), h),
    (h) => {
      const p = h.source ?? "php-wasm";
      throw this.dispatchEvent({
        type: "request.error",
        error: h,
        source: p
      }), h;
    }
  );
  return new StreamedPHPResponse(
    t.stream,
    i.stream,
    o.stream,
    u
  );
};
function normalizeHeaders(r) {
  const e = {};
  for (const t in r)
    e[t.toLowerCase()] = r[t];
  return e;
}
function copyMEMFSNodes(r, e, t) {
  if (getNodeType(r, t) !== "memfs" || !["memfs", "missing"].includes(getNodeType(e, t)))
    return;
  const s = r.lookupPath(t);
  if (!r.isDir(s.node.mode)) {
    e.writeFile(t, r.readFile(t));
    return;
  }
  e.mkdirTree(t);
  const n = r.readdir(t).filter((i) => i !== "." && i !== "..");
  for (const i of n)
    copyMEMFSNodes(r, e, joinPaths(t, i));
}
async function createInvertedReadableStream(r = {}) {
  let e;
  const t = new Promise(
    (i) => {
      e = i;
    }
  ), s = new ReadableStream({
    ...r,
    start(i) {
      if (e(i), r.start)
        return r.start(i);
    }
  }), n = await t;
  return {
    stream: s,
    controller: n
  };
}
function safeStreamError$1(r, e) {
  try {
    r.error(e);
  } catch {
  }
}
function safeStreamClose$1(r) {
  try {
    r.close();
  } catch {
  }
}
const getNodeType = (r, e) => {
  try {
    return "contents" in r.lookupPath(e, { follow: !0 }).node ? "memfs" : (
      /**
      * Could be NODEFS, PROXYFS, etc.
      */
      "not-memfs"
    );
  } catch {
    return "missing";
  }
};
async function getPhpIniEntries(r, e) {
  const t = parse(await r.readFileAsText(PHP_INI_PATH));
  if (e === void 0)
    return t;
  const s = {};
  for (const n of e)
    s[n] = t[n];
  return s;
}
async function setPhpIniEntries(r, e) {
  const t = parse(await r.readFileAsText(PHP_INI_PATH));
  for (const [s, n] of Object.entries(e))
    n == null ? delete t[s] : t[s] = n;
  await r.writeFile(PHP_INI_PATH, stringify(t));
}
async function withPHPIniValues(r, e, t) {
  const s = await r.readFileAsText(PHP_INI_PATH);
  try {
    return await setPhpIniEntries(r, e), await t();
  } finally {
    await r.writeFile(PHP_INI_PATH, s);
  }
}
async function printDebugDetails(r, e) {
  e && printResponseDebugDetails(
    await PHPResponse.fromStreamedResponse(e)
  ), await prettyPrintFullStackTrace(r);
}
async function prettyPrintFullStackTrace(r) {
  let e = r, t = !0;
  for (; e; )
    t || process.stderr.write(`
Caused by:

`), process.stderr.write(e.originalErrorClassName ?? e.name), process.stderr.write(": " + e.message + `
`), process.stderr.write(
      (e.stack + "").split(`
`).slice(1).join(`
`)
    ), process.stderr.write(`
`), e.response && printResponseDebugDetails(e.response), e.phpLogs && (process.stderr.write(`

==== PHP error log ====

`), process.stderr.write(e.phpLogs)), e = e.cause, t = !1;
  process.stderr.write(`
`);
}
function printResponseDebugDetails(r) {
  process.stderr.write(
    `
    exitCode=${r.exitCode} httpStatusCode=${r.httpStatusCode} `
  );
  const e = r.headers && Object.keys(r.headers).length > 0;
  e || process.stderr.write("responseHeaders=(empty) "), r.text || process.stderr.write("stdout=(empty) "), r.errors || process.stderr.write("stderr=(empty) "), process.stderr.write(`
`), e && process.stderr.write(
    `
==== PHP response headers ====

${JSON.stringify(
      r.headers,
      null,
      2
    )}

`
  ), r.text && (process.stderr.write(`
==== PHP stdout ====

`), process.stderr.write(r.text)), r.errors && (process.stderr.write(`
==== PHP stderr ====

`), process.stderr.write(r.errors)), process.stderr.write(`
`);
}
class HttpCookieStore {
  constructor() {
    this.cookies = {};
  }
  rememberCookiesFromResponseHeaders(e) {
    if (e != null && e["set-cookie"])
      for (const t of e["set-cookie"])
        try {
          if (!t.includes("="))
            continue;
          const s = t.indexOf("="), n = t.substring(0, s), i = t.substring(s + 1).split(";")[0];
          this.cookies[n] = i;
        } catch (s) {
          logger.error(s);
        }
  }
  getCookieRequestHeader() {
    const e = [];
    for (const t in this.cookies)
      e.push(`${t}=${this.cookies[t]}`);
    return e.join("; ");
  }
}
function streamReadFileFromPHP(r, e) {
  return new ReadableStream({
    async pull(t) {
      const s = await r.readFileAsBuffer(e);
      t.enqueue(s), t.close();
    }
  });
}
async function* iteratePhpFiles(r, e, {
  relativePaths: t = !0,
  pathPrefix: s,
  exceptPaths: n = []
} = {}) {
  e = normalizePath(e);
  const i = [e];
  for (; i.length; ) {
    const o = i.pop();
    if (!o)
      return;
    const a = await r.listFiles(o);
    for (const c of a) {
      const l = `${o}/${c}`;
      if (n.includes(l.substring(e.length + 1)))
        continue;
      await r.isDir(l) ? i.push(l) : yield new StreamedFile(
        streamReadFileFromPHP(r, l),
        t ? joinPaths(
          s || "",
          l.substring(e.length + 1)
        ) : l
      );
    }
  }
}
function writeFilesStreamToPhp(r, e) {
  return new WritableStream({
    async write(t) {
      const s = joinPaths(e, t.name);
      t.type === "directory" ? await r.mkdir(s) : (await r.mkdir(dirname(s)), await r.writeFile(
        s,
        new Uint8Array(await t.arrayBuffer())
      ));
    }
  });
}
class SinglePHPInstanceManager {
  constructor(e) {
    if (this.isAcquired = !1, !e.php && !e.phpFactory)
      throw new Error(
        "SinglePHPInstanceManager requires either php or phpFactory"
      );
    this.php = e.php, this.phpFactory = e.phpFactory;
  }
  async getPrimaryPhp() {
    return this.php ? this.php : (this.phpPromise || (this.phpPromise = this.phpFactory().then((e) => (this.php = e, this.phpPromise = void 0, e))), this.phpPromise);
  }
  async acquirePHPInstance() {
    if (this.isAcquired)
      throw new Error(
        "The PHP instance already acquired. SinglePHPInstanceManager cannot spawn another PHP instance since, by definition, it only manages a single PHP instance."
      );
    const e = await this.getPrimaryPhp();
    return this.isAcquired = !0, {
      php: e,
      reap: () => {
        this.isAcquired = !1;
      }
    };
  }
  async [Symbol.asyncDispose]() {
    this.php && this.php.exit();
  }
}
class MaxPhpInstancesError extends Error {
  constructor(e) {
    super(
      `Requested more concurrent PHP instances than the limit (${e}).`
    ), this.name = this.constructor.name;
  }
}
class PHPProcessManager {
  constructor(e) {
    this.instances = [], this.idleInstances = [], this.maxPhpInstances = (e == null ? void 0 : e.maxPhpInstances) ?? 2, this.phpFactory = e == null ? void 0 : e.phpFactory, this.semaphore = new Semaphore({
      concurrency: this.maxPhpInstances,
      timeout: (e == null ? void 0 : e.timeout) || 3e4
    });
  }
  /**
   * Get the primary PHP instance (the first one spawned).
   * If no instance exists yet, one will be spawned and marked as idle.
   */
  async getPrimaryPhp() {
    if (this.instances.length > 0)
      return this.instances[0];
    this.primaryPhpPromise || (this.primaryPhpPromise = this.spawnInstance(!0));
    try {
      return await this.primaryPhpPromise;
    } finally {
      this.primaryPhpPromise = void 0;
    }
  }
  /**
   * Acquire a PHP instance for processing a request.
   *
   * Returns an idle instance from the pool, or spawns a new one if
   * the pool isn't at capacity. If all instances are busy, waits
   * until one becomes available.
   *
   * @throws {MaxPhpInstancesError} when the timeout is reached waiting
   *                                for an available instance.
   */
  async acquirePHPInstance() {
    let e;
    try {
      e = await this.semaphore.acquire();
    } catch (s) {
      throw s instanceof AcquireTimeoutError ? new MaxPhpInstancesError(this.maxPhpInstances) : s;
    }
    const t = await this.getOrSpawnInstance();
    return {
      php: t,
      reap: () => {
        this.idleInstances.push(t), e();
      }
    };
  }
  /**
   * Get an idle instance or spawn a new one.
   */
  async getOrSpawnInstance() {
    return this.instances.length === 0 && await this.getPrimaryPhp(), this.idleInstances.length === 0 && await this.spawnInstance(!1), this.idleInstances.pop();
  }
  /**
   * Spawn a new PHP instance.
   */
  async spawnInstance(e) {
    if (!this.phpFactory)
      throw new Error(
        "phpFactory must be set before spawning instances."
      );
    const t = await this.phpFactory({ isPrimary: e });
    return this.instances.push(t), this.idleInstances.push(t), t;
  }
  async [Symbol.asyncDispose]() {
    for (const e of this.instances)
      e.exit();
    this.instances = [], this.idleInstances = [];
  }
}
const SupportedPHPVersions = [
  "8.5",
  "8.4",
  "8.3",
  "8.2",
  "8.1",
  "8.0",
  "7.4"
], LatestSupportedPHPVersion = SupportedPHPVersions[0], SupportedPHPVersionsList = SupportedPHPVersions, DEFAULT_BASE_URL = "http://example.com";
function toRelativeUrl(r) {
  return r.origin === "null" ? r.toString() : r.toString().substring(r.origin.length);
}
function removePathPrefix(r, e) {
  return !e || !r.startsWith(e) ? r : r.substring(e.length);
}
function ensurePathPrefix(r, e) {
  return !e || r.startsWith(e) ? r : e + r;
}
async function encodeAsMultipart(r) {
  const e = `----${Math.random().toString(36).slice(2)}`, t = `multipart/form-data; boundary=${e}`, s = new TextEncoder(), n = [];
  for (const [c, l] of Object.entries(r))
    n.push(`--${e}\r
`), n.push(`Content-Disposition: form-data; name="${c}"`), l instanceof File && n.push(`; filename="${l.name}"`), n.push(`\r
`), l instanceof File && (n.push("Content-Type: application/octet-stream"), n.push(`\r
`)), n.push(`\r
`), l instanceof File ? n.push(await fileToUint8Array(l)) : n.push(l), n.push(`\r
`);
  n.push(`--${e}--\r
`);
  const i = n.reduce((c, l) => c + l.length, 0), o = new Uint8Array(i);
  let a = 0;
  for (const c of n)
    o.set(
      typeof c == "string" ? s.encode(c) : c,
      a
    ), a += c.length;
  return { bytes: o, contentType: t };
}
function fileToUint8Array(r) {
  return r.arrayBuffer().then((e) => new Uint8Array(e));
}
const _default = "application/octet-stream", asx = "video/x-ms-asf", atom = "application/atom+xml", avi = "video/x-msvideo", avif = "image/avif", bin = "application/octet-stream", bmp = "image/x-ms-bmp", cco = "application/x-cocoa", cjs = "application/javascript", css = "text/css", data = "application/octet-stream", deb = "application/octet-stream", der = "application/x-x509-ca-cert", dmg = "application/octet-stream", doc = "application/msword", docx = "application/vnd.openxmlformats-officedocument.wordprocessingml.document", eot = "application/vnd.ms-fontobject", flv = "video/x-flv", gif = "image/gif", gz = "application/gzip", hqx = "application/mac-binhex40", htc = "text/x-component", html = "text/html", ico = "image/x-icon", iso = "application/octet-stream", jad = "text/vnd.sun.j2me.app-descriptor", jar = "application/java-archive", jardiff = "application/x-java-archive-diff", jng = "image/x-jng", jnlp = "application/x-java-jnlp-file", jpg = "image/jpeg", jpeg = "image/jpeg", js = "application/javascript", json = "application/json", kml = "application/vnd.google-earth.kml+xml", kmz = "application/vnd.google-earth.kmz", m3u8 = "application/vnd.apple.mpegurl", m4a = "audio/x-m4a", m4v = "video/x-m4v", md = "text/plain", mid = "audio/midi", mjs = "application/javascript", mml = "text/mathml", mng = "video/x-mng", mov = "video/quicktime", mp3 = "audio/mpeg", mp4 = "video/mp4", mpeg = "video/mpeg", msi = "application/octet-stream", odg = "application/vnd.oasis.opendocument.graphics", odp = "application/vnd.oasis.opendocument.presentation", ods = "application/vnd.oasis.opendocument.spreadsheet", odt = "application/vnd.oasis.opendocument.text", ogg = "audio/ogg", otf = "font/otf", pdf = "application/pdf", pl = "application/x-perl", png = "image/png", ppt = "application/vnd.ms-powerpoint", pptx = "application/vnd.openxmlformats-officedocument.presentationml.presentation", prc = "application/x-pilot", ps = "application/postscript", ra = "audio/x-realaudio", rar = "application/x-rar-compressed", rpm = "application/x-redhat-package-manager", rss = "application/rss+xml", rtf = "application/rtf", run = "application/x-makeself", sea = "application/x-sea", sit = "application/x-stuffit", svg = "image/svg+xml", swf = "application/x-shockwave-flash", tcl = "application/x-tcl", tar = "application/x-tar", tif = "image/tiff", ts = "video/mp2t", ttf = "font/ttf", txt = "text/plain", wasm = "application/wasm", wbmp = "image/vnd.wap.wbmp", webm = "video/webm", webp = "image/webp", wml = "text/vnd.wap.wml", wmlc = "application/vnd.wap.wmlc", wmv = "video/x-ms-wmv", woff = "font/woff", woff2 = "font/woff2", xhtml = "application/xhtml+xml", xls = "application/vnd.ms-excel", xlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", xml = "text/xml", xpi = "application/x-xpinstall", xspf = "application/xspf+xml", zip = "application/zip", mimeTypes = {
  _default,
  "3gpp": "video/3gpp",
  "7z": "application/x-7z-compressed",
  asx,
  atom,
  avi,
  avif,
  bin,
  bmp,
  cco,
  cjs,
  css,
  data,
  deb,
  der,
  dmg,
  doc,
  docx,
  eot,
  flv,
  gif,
  gz,
  hqx,
  htc,
  html,
  ico,
  iso,
  jad,
  jar,
  jardiff,
  jng,
  jnlp,
  jpg,
  jpeg,
  js,
  json,
  kml,
  kmz,
  m3u8,
  m4a,
  m4v,
  md,
  mid,
  mjs,
  mml,
  mng,
  mov,
  mp3,
  mp4,
  mpeg,
  msi,
  odg,
  odp,
  ods,
  odt,
  ogg,
  otf,
  pdf,
  pl,
  png,
  ppt,
  pptx,
  prc,
  ps,
  ra,
  rar,
  rpm,
  rss,
  rtf,
  run,
  sea,
  sit,
  svg,
  swf,
  tcl,
  tar,
  tif,
  ts,
  ttf,
  txt,
  wasm,
  wbmp,
  webm,
  webp,
  wml,
  wmlc,
  wmv,
  woff,
  woff2,
  xhtml,
  xls,
  xlsx,
  xml,
  xpi,
  xspf,
  zip
};
var v, M, U, L, I, S, A, F, B, P, ne, D, ie, oe, ae;
class PHPRequestHandler {
  /**
   * The request handler needs to decide whether to serve a static asset or
   * run the PHP interpreter. For static assets it should just reuse the primary
   * PHP even if there's 50 concurrent requests to serve. However, for
   * dynamic PHP requests, it needs to grab an available interpreter.
   * Therefore, it cannot just accept PHP as an argument as serving requests
   * requires access to ProcessManager.
   *
   * @param  php    - The PHP instance.
   * @param  config - Request Handler configuration.
   */
  constructor(e) {
    y(this, P);
    y(this, v);
    y(this, M);
    y(this, U);
    y(this, L);
    y(this, I);
    y(this, S);
    y(this, A);
    y(this, F);
    y(this, B);
    const {
      documentRoot: t = "/www/",
      absoluteUrl: s = typeof location == "object" ? location.href : DEFAULT_BASE_URL,
      rewriteRules: n = [],
      pathAliases: i = [],
      getFileNotFoundAction: o = () => ({ type: "404" })
    } = e, a = (u) => {
      u.isDir(t) || u.mkdir(t), u.chdir(t), u.requestHandler = this;
    };
    if (e.php)
      a(e.php), this.instanceManager = new SinglePHPInstanceManager({
        php: e.php
      });
    else if (e.phpFactory)
      this.instanceManager = new PHPProcessManager({
        phpFactory: async (u) => {
          const h = await e.phpFactory({
            ...u,
            requestHandler: this
          });
          return a(h), h;
        },
        maxPhpInstances: e.maxPhpInstances
      });
    else
      throw new Error(
        "Either php or phpFactory must be provided in the configuration."
      );
    w(this, F, e.cookieStore === void 0 ? new HttpCookieStore() : e.cookieStore), w(this, v, t);
    const c = new URL(s);
    w(this, U, c.hostname), w(this, L, c.port ? Number(c.port) : c.protocol === "https:" ? 443 : 80), w(this, M, (c.protocol || "").replace(":", ""));
    const l = d(this, L) !== 443 && d(this, L) !== 80;
    w(this, I, [
      d(this, U),
      l ? `:${d(this, L)}` : ""
    ].join("")), w(this, S, c.pathname.replace(/\/+$/, "")), w(this, A, [
      `${d(this, M)}://`,
      d(this, I),
      d(this, S)
    ].join("")), this.rewriteRules = n, w(this, B, i), this.getFileNotFoundAction = o;
  }
  async getPrimaryPhp() {
    return await this.instanceManager.getPrimaryPhp();
  }
  /**
   * Converts a path to an absolute URL based at the PHPRequestHandler
   * root.
   *
   * @param  path The server path to convert to an absolute URL.
   * @returns The absolute URL.
   */
  pathToInternalUrl(e) {
    return e.startsWith("/") || (e = `/${e}`), `${this.absoluteUrl}${e}`;
  }
  /**
   * Converts an absolute URL based at the PHPRequestHandler to a relative path
   * without the server pathname and scope.
   *
   * @param  internalUrl An absolute URL based at the PHPRequestHandler root.
   * @returns The relative path.
   */
  internalUrlToPath(e) {
    const t = new URL(e, "https://playground.internal");
    return t.pathname.startsWith(d(this, S)) && (t.pathname = t.pathname.slice(d(this, S).length)), toRelativeUrl(t);
  }
  /**
   * The absolute URL of this PHPRequestHandler instance.
   */
  get absoluteUrl() {
    return d(this, A);
  }
  /**
   * The directory in the PHP filesystem where the server will look
   * for the files to serve. Default: `/var/www`.
   */
  get documentRoot() {
    return d(this, v);
  }
  /**
   * Serves the request – either by serving a static file, or by
   * dispatching it to the PHP runtime.
   *
   * The request() method mode behaves like a web server and only works if
   * the PHP was initialized with a `requestHandler` option (which the online
   * version of WordPress Playground does by default).
   *
   * In the request mode, you pass an object containing the request information
   * (method, headers, body, etc.) and the path to the PHP file to run:
   *
   * ```ts
   * const php = PHP.load('7.4', {
   * 	requestHandler: {
   * 		documentRoot: "/www"
   * 	}
   * })
   * php.writeFile("/www/index.php", `<?php echo file_get_contents("php://input");`);
   * const result = await php.request({
   * 	method: "GET",
   * 	headers: {
   * 		"Content-Type": "text/plain"
   * 	},
   * 	body: "Hello world!",
   * 	path: "/www/index.php"
   * });
   * // result.text === "Hello world!"
   * ```
   *
   * The `request()` method cannot be used in conjunction with `cli()`.
   *
   * @example
   * ```js
   * const output = await php.request({
   * 	method: 'GET',
   * 	url: '/index.php',
   * 	headers: {
   * 		'X-foo': 'bar',
   * 	},
   * 	body: {
   * 		foo: 'bar',
   * 	},
   * });
   * console.log(output.stdout); // "Hello world!"
   * ```
   *
   * @param  request - PHP Request data.
   */
  async request(e) {
    const t = await this.requestStreamed(e), s = await PHPResponse.fromStreamedResponse(t);
    return s.ok() && s.exitCode !== 0 ? new PHPResponse(
      500,
      s.headers,
      s.bytes,
      s.errors,
      s.exitCode
    ) : s;
  }
  /**
   * Serves the request with streaming support – returns a StreamedPHPResponse
   * that allows processing the response body incrementally without buffering
   * the entire response in memory.
   *
   * This is useful for large file downloads (>2GB) that would otherwise
   * exceed JavaScript's Uint8Array size limits.
   *
   * @param request - PHP Request data.
   * @returns A StreamedPHPResponse.
   */
  async requestStreamed(e) {
    const t = looksLikeAbsoluteUrl(e.url), s = new URL(
      // Remove the hash part of the URL as it's not meant for the server.
      e.url.split("#")[0],
      t ? void 0 : DEFAULT_BASE_URL
    ), n = m(this, P, ne).call(this, s), i = await this.getPrimaryPhp(), o = removePathPrefix(
      /**
       * URL.pathname returns a URL-encoded path. We need to decode it
       * before using it as a filesystem path.
       */
      decodeURIComponent(n.pathname),
      d(this, S)
    );
    let a = m(this, P, D).call(this, o);
    if (i.isDir(a)) {
      if (!o.endsWith("/"))
        return StreamedPHPResponse.fromPHPResponse(
          new PHPResponse(
            301,
            { location: [`${n.pathname}/`] },
            new Uint8Array(0)
          )
        );
      for (const c of ["index.php", "index.html"]) {
        const l = joinPaths(a, c);
        if (i.isFile(l)) {
          a = l, n.pathname = joinPaths(
            n.pathname,
            c
          );
          break;
        }
      }
    }
    if (!i.isFile(a)) {
      let c = o;
      for (; c.startsWith("/") && c !== dirname(c); ) {
        c = dirname(c);
        const l = m(this, P, D).call(this, c);
        if (i.isFile(l) && // Only run partial path resolution for PHP files.
        l.endsWith(".php")) {
          a = m(this, P, D).call(this, c);
          break;
        }
      }
    }
    if (!i.isFile(a)) {
      const c = this.getFileNotFoundAction(
        n.pathname
      );
      switch (c.type) {
        case "response":
          return StreamedPHPResponse.fromPHPResponse(
            c.response
          );
        case "internal-redirect":
          a = joinPaths(d(this, v), c.uri);
          break;
        case "404":
          return StreamedPHPResponse.forHttpCode(404);
        default:
          throw new Error(
            `Unsupported file-not-found action type: '${c.type}'`
          );
      }
    }
    return i.isFile(a) ? a.endsWith(".php") ? await m(this, P, oe).call(this, e, s, n, a) : StreamedPHPResponse.fromPHPResponse(
      m(this, P, ie).call(this, i, a)
    ) : StreamedPHPResponse.forHttpCode(404);
  }
  /**
   * Computes the essential $_SERVER entries for a request.
   *
   * php_wasm.c sets some defaults, assuming it runs as a CLI script.
   * This function overrides them with the values correct in the request
   * context.
   *
   * @TODO: Consolidate the $_SERVER setting logic into a single place instead
   *        of splitting it between the C SAPI and the TypeScript code. The PHP
   *        class has a `.cli()` method that could take care of the CLI-specific
   *        $_SERVER values.
   *
   * Path and URL-related $_SERVER entries are theoretically documented
   * at https://www.php.net/manual/en/reserved.variables.server.php,
   * but that page is not very helpful in practice. Here are tables derived
   * by interacting with PHP servers:
   *
   * ## PHP Dev Server
   *
   * Setup:
   *   – `/home/adam/subdir/script.php` file contains `<?php phpinfo(); ?>`
   *   – `php -S 127.0.0.1:8041` running in `/home/adam` directory
   *   – A request is sent to `http://127.0.0.1:8041/subdir/script.php/b.php/c.php`
   *
   * Results:
   *
   * $_SERVER['REQUEST_URI']    | `/subdir/script.php/b.php/c.php`
   * $_SERVER['SCRIPT_NAME']    | `/subdir/script.php`
   * $_SERVER['SCRIPT_FILENAME']| `/home/adam/subdir/script.php`
   * $_SERVER['PATH_INFO']      | `/b.php/c.php`
   * $_SERVER['PHP_SELF']       | `/subdir/script.php/b.php/c.php`
   *
   * ## Apache – rewriting rules
   *
   * Setup:
   *   – `/var/www/html/subdir/script.php` file contains `<?php phpinfo(); ?>`
   *   – Apache is listening on port 8041
   *   – The document root is `/var/www/html`
   *   – A request is sent to `http://127.0.0.1:8041/api/v1/user/123`
   *
   * .htaccess file:
   *
   * ```apache
   * RewriteEngine On
   * RewriteRule ^api/v1/user/([0-9]+)$ /subdir/script.php?endpoint=user&id=$1 [L,QSA]
   * ```
   *
   * Results:
   *
   * ```
   * $_SERVER['REQUEST_URI']             | /api/v1/user/123
   * $_SERVER['SCRIPT_NAME']             | /subdir/script.php
   * $_SERVER['SCRIPT_FILENAME']         | /var/www/html/subdir/script.php
   * $_SERVER['PATH_INFO']               | (key not set)
   * $_SERVER['PHP_SELF']                | /subdir/script.php
   * $_SERVER['QUERY_STRING']            | endpoint=user&id=123
   * $_SERVER['REDIRECT_STATUS']         | 200
   * $_SERVER['REDIRECT_URL']            | /api/v1/user/123
   * $_SERVER['REDIRECT_QUERY_STRING']   | endpoint=user&id=123
   * === $_GET Variables ===
   * $_GET['endpoint']                   | user
   * $_GET['id']                         | 123
   * ```
   *
   * ## Apache – vanilla request
   *
   * Setup:
   *    – The same as above.
   *    – A request sent http://localhost:8041/subdir/script.php?param=value
   *
   * Results:
   *
   * ```
   * $_SERVER['REQUEST_URI']     | /subdir/script.php?param=value
   * $_SERVER['SCRIPT_NAME']     | /subdir/script.php
   * $_SERVER['SCRIPT_FILENAME'] | /var/www/html/subdir/script.php
   * $_SERVER['PATH_INFO']       | (key not set)
   * $_SERVER['PHP_SELF']        | /subdir/script.php
   * $_SERVER['REDIRECT_URL']    | (key not set)
   * $_SERVER['REDIRECT_STATUS'] | (key not set)
   * $_SERVER['QUERY_STRING']    | param=value
   * $_SERVER['REQUEST_METHOD']  | GET
   * $_SERVER['DOCUMENT_ROOT']   | /var/www/html
   *
   * === $_GET Variables ===
   * $_GET['param']              | value
   * ```
   */
  prepare_$_SERVER_superglobal(e, t, s) {
    const n = {
      REMOTE_ADDR: "127.0.0.1",
      DOCUMENT_ROOT: d(this, v),
      HTTPS: d(this, A).startsWith("https://") ? "on" : ""
    };
    return n.REQUEST_URI = e.pathname + e.search, s.startsWith(d(this, v)) && (n.SCRIPT_NAME = s.substring(
      d(this, v).length
    ), n.PHP_SELF = t.pathname, n.REQUEST_URI.startsWith(n.SCRIPT_NAME) && (n.PATH_INFO = n.REQUEST_URI.substring(
      n.SCRIPT_NAME.length
    ), n.PATH_INFO.includes("?") && (n.PATH_INFO = n.PATH_INFO.substring(
      0,
      n.PATH_INFO.indexOf("?")
    )))), n.QUERY_STRING = t.search.substring(1), n;
  }
  async [Symbol.asyncDispose]() {
    await this.instanceManager[Symbol.asyncDispose]();
  }
}
v = new WeakMap(), M = new WeakMap(), U = new WeakMap(), L = new WeakMap(), I = new WeakMap(), S = new WeakMap(), A = new WeakMap(), F = new WeakMap(), B = new WeakMap(), P = new WeakSet(), /**
 * Apply the rewrite rules to the original request URL.
 *
 * @param originalRequestUrl - The original request URL.
 * @returns The rewritten request URL.
 */
ne = function(e) {
  const t = removePathPrefix(
    decodeURIComponent(e.pathname),
    d(this, S)
  ), s = applyRewriteRules(
    t,
    this.rewriteRules
  ), n = new URL(
    joinPaths(d(this, S), s),
    e.toString()
  );
  for (const [i, o] of e.searchParams.entries())
    n.searchParams.append(i, o);
  return n;
}, /**
 * Resolves a URL path to a filesystem path, checking path aliases first.
 *
 * If the URL path matches a configured alias prefix, the alias's
 * filesystem path is used instead of the document root.
 *
 * @param urlPath - The URL path to resolve (e.g., '/phpmyadmin/index.php')
 * @returns The resolved filesystem path
 */
D = function(e) {
  for (const t of d(this, B))
    if (e === t.urlPrefix || e.startsWith(t.urlPrefix + "/")) {
      const s = e.slice(t.urlPrefix.length);
      return joinPaths(t.fsPath, s);
    }
  return joinPaths(d(this, v), e);
}, /**
 * Serves a static file from the PHP filesystem.
 *
 * @param  fsPath - Absolute path of the static file to serve.
 * @returns The response.
 */
ie = function(e, t) {
  const s = e.readFileAsBuffer(t);
  return new PHPResponse(
    200,
    {
      "content-length": [`${s.byteLength}`],
      // @TODO: Infer the content-type from the arrayBuffer instead of the
      // file path. The code below won't return the correct mime-type if the
      // extension was tampered with.
      "content-type": [inferMimeType(t)],
      "accept-ranges": ["bytes"],
      "cache-control": ["public, max-age=0"]
    },
    s
  );
}, oe = async function(e, t, s, n) {
  let i;
  try {
    i = await this.instanceManager.acquirePHPInstance();
  } catch (a) {
    return a instanceof MaxPhpInstancesError ? StreamedPHPResponse.forHttpCode(502) : StreamedPHPResponse.forHttpCode(500);
  }
  let o;
  try {
    o = await m(this, P, ae).call(this, i.php, e, t, s, n);
  } catch (a) {
    throw i.reap(), a;
  }
  return o.finished.finally(() => {
    i == null || i.reap();
  }), o;
}, ae = async function(e, t, s, n, i) {
  let o = "GET";
  const a = {
    host: d(this, I),
    ...normalizeHeaders(t.headers || {})
  };
  d(this, F) && (a.cookie = d(this, F).getCookieRequestHeader());
  let c = t.body;
  if (typeof c == "object" && !(c instanceof Uint8Array)) {
    o = "POST";
    const { bytes: u, contentType: h } = await encodeAsMultipart(c);
    c = u, a["content-type"] = h;
  }
  const l = await e.runStream({
    relativeUri: ensurePathPrefix(
      toRelativeUrl(new URL(n.toString())),
      d(this, S)
    ),
    protocol: d(this, M),
    method: t.method || o,
    $_SERVER: this.prepare_$_SERVER_superglobal(
      s,
      n,
      i
    ),
    body: c,
    scriptPath: i,
    headers: a
  });
  if (d(this, F)) {
    const u = await l.headers;
    d(this, F).rememberCookiesFromResponseHeaders(
      u
    );
  }
  return l;
};
function inferMimeType(r) {
  const e = r.split(".").pop();
  return mimeTypes[e] || mimeTypes._default;
}
function applyRewriteRules(r, e) {
  for (const t of e)
    if (new RegExp(t.match).test(r)) {
      r = r.replace(t.match, t.replacement);
      break;
    }
  return r;
}
function looksLikeAbsoluteUrl(r) {
  try {
    return new URL(r), !0;
  } catch {
    return !1;
  }
}
function rotatePHPRuntime({
  php: r,
  recreateRuntime: e,
  maxRequests: t = 400
}) {
  return r.enableRuntimeRotation({
    recreateRuntime: e,
    maxRequests: t
  });
}
async function writeFiles(r, e, t, { rmRoot: s = !1 } = {}) {
  s && await r.isDir(e) && await r.rmdir(e, { recursive: !0 });
  for (const [n, i] of Object.entries(t)) {
    const o = joinPaths(e, n);
    await r.fileExists(dirname(o)) || await r.mkdir(dirname(o)), i instanceof Uint8Array || typeof i == "string" ? await r.writeFile(o, i) : await writeFiles(r, o, i);
  }
}
function ensureProxyFSHasMmapSupport(r) {
  const e = Object.getOwnPropertySymbols(r)[0], t = r[e], s = t.PROXYFS, n = t.FS;
  s.stream_ops.mmap || (s.stream_ops.mmap = function(i, o, a, c, l) {
    if (!n.isFile(i.node.mode))
      throw new n.ErrnoError(19);
    if (a !== 0)
      throw new n.ErrnoError(22);
    const u = t.malloc(o);
    if (!u)
      throw new n.ErrnoError(48);
    const h = t.HEAPU8.subarray(u, u + o);
    let p = 0;
    for (; p < o; ) {
      const g = i.stream_ops.read(
        i,
        h,
        p,
        o - p,
        p
      );
      if (g <= 0) break;
      p += g;
    }
    if (p !== o)
      throw t.free(u), new n.ErrnoError(5);
    return { ptr: u, allocated: !0 };
  }, s.stream_ops.msync = function(i, o, a, c, l) {
    return l & 2 || i.stream_ops.write(
      i,
      o,
      a,
      c,
      a,
      !1
    ), 0;
  });
}
async function proxyFileSystem(r, e, t) {
  const s = Object.getOwnPropertySymbols(r)[0];
  for (const n of t)
    r.fileExists(n) || r.mkdir(n), e.mkdir(n), await e.mount(n, (i) => {
      ensureProxyFSHasMmapSupport(i);
      const o = Object.getOwnPropertySymbols(i)[0];
      return i[o].FS.mount(
        // @ts-ignore
        i[o].PROXYFS,
        {
          root: n,
          // @ts-ignore
          fs: r[s].FS
        },
        n
      ), () => {
        try {
          i[o].FS.unmount(n);
        } catch {
        }
      };
    });
}
function isPathToSharedFS(r, e) {
  var i;
  const t = Object.getOwnPropertySymbols(r)[0], n = r[t].FS.lookupPath(e, { noent_okay: !0 });
  return ((i = n == null ? void 0 : n.node) == null ? void 0 : i.isSharedFS) ?? !1;
}
function sandboxedSpawnHandlerFactory(r) {
  return createSpawnHandler(async function(e, t, s) {
    t.notifySpawn(), (e == null ? void 0 : e[0]) === "/bin/sh" && (e == null ? void 0 : e[1]) === "-c" && typeof e[2] == "string" && (e = splitShellCommand(e[2])), e[0] === "exec" && e.shift(), (e[0].endsWith(".php") || e[0].endsWith(".phar")) && e.unshift("php");
    const n = e[0].split("/").pop();
    if (e[0] === "/usr/bin/env" && e[1] === "stty" && e[2] === "size")
      t.stdout("18 140"), t.exit(0);
    else if (n === "tput" && e[1] === "cols")
      t.stdout("140"), t.exit(0);
    else if (n === "less") {
      t.on("stdin", (a) => {
        t.stdout(a);
      }), await new Promise((a) => {
        t.childProcess.stdin.on("finish", () => {
          a(!0);
        });
      }), t.exit(0);
      return;
    }
    if (!["php", "ls", "pwd"].includes(n ?? "")) {
      t.exit(127);
      return;
    }
    if (!r) {
      logger.warn(
        "Tried to spawn a PHP subprocess, but the sandboxed spawn handler was created without a getPHPInstance function."
      ), t.exit(127);
      return;
    }
    const { php: i, reap: o } = await r();
    try {
      s.cwd && await i.chdir(s.cwd);
      const a = await i.cwd();
      switch (n) {
        case "php": {
          const c = await i.cli(e, {
            env: {
              ...s.env,
              SCRIPT_PATH: e[1],
              // Set SHELL_PIPE to 0 to ensure WP-CLI formats
              // the output as ASCII tables.
              // @see https://github.com/wp-cli/wp-cli/issues/1102
              SHELL_PIPE: "0"
            }
          });
          c.stdout.pipeTo(
            new WritableStream({
              write(l) {
                t.stdout(l);
              }
            })
          ), c.stderr.pipeTo(
            new WritableStream({
              write(l) {
                t.stderr(l);
              }
            })
          ), t.exit(await c.exitCode);
          break;
        }
        case "ls": {
          const c = await i.listFiles(e[1] ?? a);
          for (const l of c)
            t.stdout(l + `
`);
          await new Promise((l) => setTimeout(l, 10)), t.exit(0);
          break;
        }
        case "pwd": {
          t.stdout(a + `
`), await new Promise((c) => setTimeout(c, 10)), t.exit(0);
          break;
        }
      }
    } catch (a) {
      const c = a instanceof Error ? a.message + `
` + a.stack : typeof a == "object" && a !== null ? JSON.stringify(a, Object.getOwnPropertyNames(a)) : String(a);
      throw t.stderr(`[spawn error] ${c}`), t.exit(1), a;
    } finally {
      o();
    }
  });
}
function exposeSync(r, e, t, s = ["*"]) {
  return expose(r, e, s, t.afterResponseSent);
}
function createSyncProxy(r, e = [], t) {
  return new Proxy(() => {
  }, {
    get(s, n) {
      return n === "then" && !e.length ? {
        then: (i, o) => o(createSyncProxy(r, [], t))
      } : createSyncProxy(r, [...e, n], t);
    },
    set(s, n, i) {
      const [o, a] = toWireValue(i);
      return t.send(
        r,
        {
          type: MessageType.SET,
          path: [...e, n].map(String),
          value: o
        },
        a
      ), !0;
    },
    apply(s, n, i) {
      if (e.at(-1) === "bind")
        return createSyncProxy(r, e.slice(0, -1), t);
      const [a, c] = processArguments(i), l = t.send(
        r,
        {
          type: MessageType.APPLY,
          path: e.map(String),
          argumentList: a
        },
        c
      );
      return fromWireValue(l);
    },
    construct(s, n) {
      const [i, o] = processArguments(n), a = t.send(
        r,
        {
          type: MessageType.CONSTRUCT,
          path: e.map(String),
          argumentList: i
        },
        o
      );
      return fromWireValue(a);
    }
  });
}
function wrapSync(r, e) {
  return createSyncProxy(r, [], e);
}
class NodeSABSyncReceiveMessageTransport {
  static async create() {
    if (!NodeSABSyncReceiveMessageTransport.receiveMessageOnPort)
      try {
        NodeSABSyncReceiveMessageTransport.receiveMessageOnPort = require("worker_threads").receiveMessageOnPort;
      } catch {
        NodeSABSyncReceiveMessageTransport.receiveMessageOnPort = await import("worker_threads").then(
          (e) => e.receiveMessageOnPort
        );
      }
    return new NodeSABSyncReceiveMessageTransport();
  }
  constructor() {
  }
  afterResponseSent(e) {
    const { notifyBuffer: t } = e.data;
    if (t) {
      const s = new Int32Array(t);
      s[0] = 1, Atomics.notify(s, 0);
    }
  }
  send(e, t, s) {
    var l;
    const n = new SharedArrayBuffer(4), i = new Int32Array(n);
    i[0] = 0;
    const o = generateUUID();
    if (e.postMessage(
      { ...t, id: o, notifyBuffer: n },
      s
    ), Atomics.wait(i, 0, 0, 5e3) === "timed-out")
      throw new Error("Timeout waiting for response");
    for (; ; ) {
      const u = NodeSABSyncReceiveMessageTransport.receiveMessageOnPort(e);
      if (((l = u.message) == null ? void 0 : l.id) === o)
        return u.message;
      if (!u)
        throw new Error("No response received");
    }
  }
}
/**
 * Original, unmodified Comlink library from Google:
 *
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const proxyMarker = Symbol("Comlink.proxy"), createEndpoint = Symbol("Comlink.endpoint"), releaseProxy = Symbol("Comlink.releaseProxy"), finalizer = Symbol("Comlink.finalizer"), throwMarker = Symbol("Comlink.thrown");
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const WireValueType = {
  RAW: "RAW",
  HANDLER: "HANDLER"
}, MessageType = {
  GET: "GET",
  SET: "SET",
  APPLY: "APPLY",
  CONSTRUCT: "CONSTRUCT",
  ENDPOINT: "ENDPOINT",
  RELEASE: "RELEASE"
}, isObject = (r) => typeof r == "object" && r !== null || typeof r == "function", proxyTransferHandler = {
  canHandle: (r) => isObject(r) && r[proxyMarker],
  serialize(r) {
    const { port1: e, port2: t } = new MessageChannel();
    return expose(r, e), [t, [t]];
  },
  deserialize(r) {
    return r.start(), wrap(r);
  }
}, throwTransferHandler$1 = {
  canHandle: (r) => isObject(r) && throwMarker in r,
  serialize({ value: r }) {
    let e;
    return r instanceof Error ? e = {
      isError: !0,
      value: {
        message: r.message,
        name: r.name,
        stack: r.stack
      }
    } : e = { isError: !1, value: r }, [e, []];
  },
  deserialize(r) {
    throw r.isError ? Object.assign(
      new Error(r.value.message),
      r.value
    ) : r.value;
  }
}, transferHandlers = /* @__PURE__ */ new Map([
  ["proxy", proxyTransferHandler],
  ["throw", throwTransferHandler$1]
]);
function isAllowedOrigin(r, e) {
  for (const t of r)
    if (e === t || t === "*" || t instanceof RegExp && t.test(e))
      return !0;
  return !1;
}
function expose(r, e = globalThis, t = ["*"], s) {
  e.addEventListener("message", function n(i) {
    if (!i || !i.data)
      return;
    if (!isAllowedOrigin(t, i.origin)) {
      console.warn(`Invalid origin '${i.origin}' for comlink proxy`);
      return;
    }
    const { id: o, type: a, path: c } = {
      path: [],
      ...i.data
    }, l = (i.data.argumentList || []).map(fromWireValue);
    let u;
    try {
      const h = c.slice(0, -1).reduce((g, E) => g[E], r), p = c.reduce((g, E) => g[E], r);
      switch (a) {
        case MessageType.GET:
          u = p;
          break;
        case MessageType.SET:
          h[c.slice(-1)[0]] = fromWireValue(
            i.data.value
          ), u = !0;
          break;
        case MessageType.APPLY:
          u = p.apply(h, l);
          break;
        case MessageType.CONSTRUCT:
          {
            const g = new p(...l);
            u = proxy(g);
          }
          break;
        case MessageType.ENDPOINT:
          {
            const { port1: g, port2: E } = new MessageChannel();
            expose(r, E), u = transfer(g, [g]);
          }
          break;
        case MessageType.RELEASE:
          u = void 0;
          break;
        default:
          return;
      }
    } catch (h) {
      u = { value: h, [throwMarker]: 0 };
    }
    Promise.resolve(u).catch((h) => ({ value: h, [throwMarker]: 0 })).then((h) => {
      const [p, g] = toWireValue(h);
      e.postMessage({ ...p, id: o }, g), a === MessageType.RELEASE && (e.removeEventListener("message", n), closeEndPoint(e), finalizer in r && typeof r[finalizer] == "function" && r[finalizer]());
    }).catch(() => {
      const [h, p] = toWireValue({
        value: new TypeError("Unserializable return value"),
        [throwMarker]: 0
      });
      e.postMessage({ ...h, id: o }, p);
    }).finally(() => {
      s == null || s(i);
    });
  }), e.start && e.start();
}
function isMessagePort(r) {
  return r.constructor.name === "MessagePort";
}
function closeEndPoint(r) {
  isMessagePort(r) && r.close();
}
function wrap(r, e) {
  const t = /* @__PURE__ */ new Map();
  return r.addEventListener("message", function(n) {
    const { data: i } = n;
    if (!i || !i.id)
      return;
    const o = t.get(i.id);
    if (o)
      try {
        o(i);
      } finally {
        t.delete(i.id);
      }
  }), createProxy(r, t, [], e);
}
function throwIfProxyReleased(r) {
  if (r)
    throw new Error("Proxy has been released and is not useable");
}
function releaseEndpoint(r) {
  return requestResponseMessage(r, /* @__PURE__ */ new Map(), {
    type: MessageType.RELEASE
  }).then(() => {
    closeEndPoint(r);
  });
}
const proxyCounter = /* @__PURE__ */ new WeakMap(), proxyFinalizers = "FinalizationRegistry" in globalThis && new FinalizationRegistry((r) => {
  const e = (proxyCounter.get(r) || 0) - 1;
  proxyCounter.set(r, e), e === 0 && releaseEndpoint(r);
});
function registerProxy(r, e) {
  const t = (proxyCounter.get(e) || 0) + 1;
  proxyCounter.set(e, t), proxyFinalizers && proxyFinalizers.register(r, e, r);
}
function unregisterProxy(r) {
  proxyFinalizers && proxyFinalizers.unregister(r);
}
function createProxy(r, e, t = [], s = function() {
}) {
  let n = !1;
  const i = new Proxy(s, {
    get(o, a) {
      if (throwIfProxyReleased(n), a === releaseProxy)
        return () => {
          unregisterProxy(i), releaseEndpoint(r), e.clear(), n = !0;
        };
      if (a === "then") {
        if (t.length === 0)
          return { then: () => i };
        const c = requestResponseMessage(r, e, {
          type: MessageType.GET,
          path: t.map((l) => l.toString())
        }).then(fromWireValue);
        return c.then.bind(c);
      }
      return createProxy(r, e, [...t, a]);
    },
    set(o, a, c) {
      throwIfProxyReleased(n);
      const [l, u] = toWireValue(c);
      return requestResponseMessage(
        r,
        e,
        {
          type: MessageType.SET,
          path: [...t, a].map((h) => h.toString()),
          value: l
        },
        u
      ).then(fromWireValue);
    },
    apply(o, a, c) {
      throwIfProxyReleased(n);
      const l = t[t.length - 1];
      if (l === createEndpoint)
        return requestResponseMessage(r, e, {
          type: MessageType.ENDPOINT
        }).then(fromWireValue);
      if (l === "bind")
        return createProxy(r, e, t.slice(0, -1));
      const [u, h] = processArguments(c);
      return requestResponseMessage(
        r,
        e,
        {
          type: MessageType.APPLY,
          path: t.map((p) => p.toString()),
          argumentList: u
        },
        h
      ).then(fromWireValue);
    },
    construct(o, a) {
      throwIfProxyReleased(n);
      const [c, l] = processArguments(a);
      return requestResponseMessage(
        r,
        e,
        {
          type: MessageType.CONSTRUCT,
          path: t.map((u) => u.toString()),
          argumentList: c
        },
        l
      ).then(fromWireValue);
    }
  });
  return registerProxy(i, r), i;
}
function myFlat(r) {
  return Array.prototype.concat.apply([], r);
}
function processArguments(r) {
  const e = r.map(toWireValue);
  return [e.map((t) => t[0]), myFlat(e.map((t) => t[1]))];
}
const transferCache = /* @__PURE__ */ new WeakMap();
function transfer(r, e) {
  return transferCache.set(r, e), r;
}
function proxy(r) {
  return Object.assign(r, { [proxyMarker]: !0 });
}
function windowEndpoint(r, e = globalThis, t = "*") {
  return {
    postMessage: (s, n) => r.postMessage(s, t, n),
    addEventListener: e.addEventListener.bind(e),
    removeEventListener: e.removeEventListener.bind(e)
  };
}
function toWireValue(r) {
  for (const [e, t] of transferHandlers)
    if (t.canHandle(r)) {
      const [s, n] = t.serialize(r);
      return [
        {
          type: WireValueType.HANDLER,
          name: e,
          value: s
        },
        n
      ];
    }
  return [
    {
      type: WireValueType.RAW,
      value: r
    },
    transferCache.get(r) || []
  ];
}
function fromWireValue(r) {
  switch (r.type) {
    case WireValueType.HANDLER:
      return transferHandlers.get(r.name).deserialize(r.value);
    case WireValueType.RAW:
      return r.value;
  }
}
function requestResponseMessage(r, e, t, s) {
  return new Promise((n) => {
    const i = generateUUID();
    e.set(i, n), r.start && r.start(), r.postMessage({ id: i, ...t }, s);
  });
}
function generateUUID() {
  return new Array(4).fill(0).map(
    () => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)
  ).join("-");
}
function nodeEndpoint(r) {
  const e = /* @__PURE__ */ new WeakMap();
  return {
    postMessage: r.postMessage.bind(r),
    addEventListener: (t, s) => {
      const n = (i) => {
        "handleEvent" in s ? s.handleEvent({ data: i }) : s({ data: i });
      };
      r.on("message", n), e.set(s, n);
    },
    removeEventListener: (t, s) => {
      const n = e.get(s);
      n && (r.off("message", n), e.delete(s));
    },
    start: r.start && r.start.bind(r)
  };
}
const proxyByListener = /* @__PURE__ */ new WeakMap();
function nodeProcessEndpoint(r) {
  const e = r || process;
  if (typeof e.send != "function")
    throw new Error(
      "IPC channel is not available. Did you forget to fork the process?"
    );
  const t = e;
  return {
    postMessage(s, n) {
      var i;
      if (n && n.length > 0)
        throw new Error(
          "Transferable objects are not supported for nodeProcessEndpoint"
        );
      (i = t.send) == null || i.call(t, s);
    },
    addEventListener(s, n) {
      const i = typeof n == "function" ? (o) => n({ data: o }) : (o) => n.handleEvent({ data: o });
      proxyByListener.set(n, i), t.addListener(s, i);
    },
    removeEventListener(s, n) {
      const i = proxyByListener.get(n);
      i && (proxyByListener.delete(n), t.removeListener(s, i));
    },
    start() {
    }
  };
}
const list = [
  // Native ES errors https://262.ecma-international.org/12.0/#sec-well-known-intrinsic-objects
  Error,
  EvalError,
  RangeError,
  ReferenceError,
  SyntaxError,
  TypeError,
  URIError,
  AggregateError,
  // Built-in errors
  globalThis.DOMException,
  // Node-specific errors
  // https://nodejs.org/api/errors.html
  globalThis.AssertionError,
  globalThis.SystemError
].filter(Boolean).map((r) => [r.name, r]), errorConstructors = new Map(list);
class NonError extends Error {
  constructor(e) {
    super(NonError._prepareSuperMessage(e)), this.name = "NonError";
  }
  static _prepareSuperMessage(e) {
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  }
}
const errorProperties = [
  {
    property: "name",
    enumerable: !1
  },
  {
    property: "message",
    enumerable: !1
  },
  {
    property: "stack",
    enumerable: !1
  },
  {
    property: "code",
    enumerable: !0
  },
  {
    property: "cause",
    enumerable: !1
  },
  {
    property: "errors",
    enumerable: !1
  }
], toJsonWasCalled = /* @__PURE__ */ new WeakSet(), toJSON = (r) => {
  toJsonWasCalled.add(r);
  const e = r.toJSON();
  return toJsonWasCalled.delete(r), e;
}, newError = (r) => {
  const e = errorConstructors.get(r) ?? Error;
  return e === AggregateError ? new e([]) : new e();
}, destroyCircular = ({
  from: r,
  seen: e,
  to: t,
  forceEnumerable: s,
  maxDepth: n,
  depth: i,
  useToJSON: o,
  serialize: a
}) => {
  if (t || (Array.isArray(r) ? t = [] : !a && isErrorLike(r) ? t = newError(r.name) : t = {}), e.push(r), i >= n)
    return t;
  if (o && typeof r.toJSON == "function" && !toJsonWasCalled.has(r))
    return toJSON(r);
  const c = (l) => destroyCircular({
    from: l,
    seen: [...e],
    forceEnumerable: s,
    maxDepth: n,
    depth: i,
    useToJSON: o,
    serialize: a
  });
  for (const [l, u] of Object.entries(r)) {
    if (u && u instanceof Uint8Array && u.constructor.name === "Buffer") {
      t[l] = "[object Buffer]";
      continue;
    }
    if (u !== null && typeof u == "object" && typeof u.pipe == "function") {
      t[l] = "[object Stream]";
      continue;
    }
    if (typeof u != "function") {
      if (!u || typeof u != "object") {
        try {
          t[l] = u;
        } catch {
        }
        continue;
      }
      if (!e.includes(r[l])) {
        i++, t[l] = c(r[l]);
        continue;
      }
      t[l] = "[Circular]";
    }
  }
  if (a || t instanceof Error)
    for (const { property: l, enumerable: u } of errorProperties)
      r[l] !== void 0 && r[l] !== null && Object.defineProperty(t, l, {
        value: isErrorLike(r[l]) || Array.isArray(r[l]) ? c(r[l]) : r[l],
        enumerable: s ? !0 : u,
        configurable: !0,
        writable: !0
      });
  return t;
};
function serializeError(r, e = {}) {
  const { maxDepth: t = Number.POSITIVE_INFINITY, useToJSON: s = !0 } = e;
  return typeof r == "object" && r !== null ? destroyCircular({
    from: r,
    seen: [],
    forceEnumerable: !0,
    maxDepth: t,
    depth: 0,
    useToJSON: s,
    serialize: !0
  }) : typeof r == "function" ? `[Function: ${r.name || "anonymous"}]` : r;
}
function deserializeError(r, e = {}) {
  const { maxDepth: t = Number.POSITIVE_INFINITY } = e;
  return r instanceof Error ? r : isMinimumViableSerializedError(r) ? destroyCircular({
    from: r,
    seen: [],
    to: newError(r.name),
    maxDepth: t,
    depth: 0,
    serialize: !1
  }) : new NonError(r);
}
function isErrorLike(r) {
  return !!r && typeof r == "object" && typeof r.name == "string" && typeof r.message == "string" && typeof r.stack == "string";
}
function isMinimumViableSerializedError(r) {
  return !!r && typeof r == "object" && typeof r.message == "string" && !Array.isArray(r);
}
const releaseApiProxy = releaseProxy;
async function consumeAPISync(r) {
  setupTransferHandlers();
  const e = await NodeSABSyncReceiveMessageTransport.create();
  return wrapSync(r, e);
}
function consumeAPI(r, e = void 0) {
  setupTransferHandlers();
  let t;
  if (typeof process < "u" && typeof process.versions < "u" && typeof process.versions.node < "u")
    if ("postMessage" in r)
      t = nodeEndpoint(r);
    else if ("send" in r && "addListener" in r)
      t = nodeProcessEndpoint(r);
    else
      throw new Error(
        "consumeAPI: remote does not look like a Worker, MessagePort, or Process"
      );
  else
    t = r instanceof Worker ? r : windowEndpoint(r, e);
  const n = wrap(t), i = proxyClone(n);
  return new Proxy(i, {
    get: (o, a) => a === "isConnected" ? async () => {
      for (; ; )
        try {
          await runWithTimeout(n.isConnected(), 200);
          break;
        } catch {
        }
    } : n[a]
  });
}
async function runWithTimeout(r, e) {
  return new Promise((t, s) => {
    setTimeout(s, e), r.then(t);
  });
}
function exposeAPI(r, e, t) {
  const { setReady: s, setFailed: n, exposedApi: i } = prepareForExpose(
    r,
    e
  );
  let o;
  if (t)
    if ("addEventListener" in t)
      o = t;
    else if ("postMessage" in t)
      o = nodeEndpoint(t);
    else if ("send" in t && "addListener" in t)
      o = nodeProcessEndpoint(t);
    else
      throw new Error(
        "exposeAPI: targetWorker does not look like a Worker, MessagePort, or Process"
      );
  else
    o = typeof window < "u" ? windowEndpoint(self.parent) : void 0;
  return expose(i, o), [s, n, i];
}
async function exposeSyncAPI(r, e) {
  const { setReady: t, setFailed: s, exposedApi: n } = prepareForExpose(r), i = await NodeSABSyncReceiveMessageTransport.create(), o = nodeEndpoint(e);
  return exposeSync(n, o, i), [t, s, n];
}
function prepareForExpose(r, e) {
  setupTransferHandlers();
  const t = Promise.resolve();
  let s, n;
  const i = new Promise((c, l) => {
    s = c, n = l;
  }), o = proxyClone(r), a = new Proxy(o, {
    get: (c, l) => l === "isConnected" ? () => t : l === "isReady" ? () => i : l in c ? c[l] : e == null ? void 0 : e[l]
  });
  return { setReady: s, setFailed: n, exposedApi: a };
}
let isTransferHandlersSetup = !1;
function setupTransferHandlers() {
  if (isTransferHandlersSetup)
    return;
  isTransferHandlersSetup = !0, transferHandlers.set("EVENT", {
    canHandle: (t) => t instanceof CustomEvent,
    serialize: (t) => [
      {
        detail: t.detail
      },
      []
    ],
    deserialize: (t) => t
  }), transferHandlers.set("FUNCTION", {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-function-type
    canHandle: (t) => typeof t == "function",
    // eslint-disable-next-line @typescript-eslint/no-unsafe-function-type
    serialize(t) {
      const { port1: s, port2: n } = new MessageChannel();
      return expose(t, s), [n, [n]];
    },
    deserialize(t) {
      return t.start(), wrap(t);
    }
  }), transferHandlers.set("MESSAGE_PORT", {
    canHandle: (t) => t instanceof MessagePort,
    serialize(t) {
      return [t, [t]];
    },
    deserialize(t) {
      return t;
    }
  }), transferHandlers.set("PHPResponse", {
    canHandle: (t) => typeof t == "object" && t !== null && "headers" in t && "bytes" in t && "errors" in t && "exitCode" in t && "httpStatusCode" in t,
    serialize(t) {
      const s = t.toRawData(), n = [];
      return s.bytes.buffer.byteLength > 0 && n.push(s.bytes.buffer), [s, n];
    },
    deserialize(t) {
      return PHPResponse.fromRawData(t);
    }
  });
  const r = transferHandlers.get("throw"), e = r == null ? void 0 : r.serialize;
  r.serialize = ({ value: t }) => {
    const s = e({ value: t });
    return t.response && (s[0].value.response = t.response), t.source && (s[0].value.source = t.source), s;
  }, transferHandlers.set("StreamedPHPResponse", {
    canHandle: (t) => t instanceof StreamedPHPResponse,
    serialize(t) {
      const s = supportsTransferableStreams(), n = promiseToPort(t.exitCode), i = t.getHeadersStream();
      if (s)
        return [
          {
            __type: "StreamedPHPResponse",
            headers: i,
            stdout: t.stdout,
            stderr: t.stderr,
            exitCodePort: n
          },
          [
            i,
            t.stdout,
            t.stderr,
            n
          ]
        ];
      const o = streamToPort(i), a = streamToPort(t.stdout), c = streamToPort(t.stderr);
      return [
        {
          __type: "StreamedPHPResponse",
          headersPort: o,
          stdoutPort: a,
          stderrPort: c,
          exitCodePort: n
        },
        [o, a, c, n]
      ];
    },
    deserialize(t) {
      if (t.headers && t.stdout && t.stderr) {
        const a = portToPromise(
          t.exitCodePort
        );
        return new StreamedPHPResponse(
          t.headers,
          t.stdout,
          t.stderr,
          a
        );
      }
      const s = portToStream(t.headersPort), n = portToStream(t.stdoutPort), i = portToStream(t.stderrPort), o = portToPromise(t.exitCodePort);
      return new StreamedPHPResponse(s, n, i, o);
    }
  });
}
let _cachedSupportsTransferableStreams;
function supportsTransferableStreams() {
  if (typeof ReadableStream > "u" && (_cachedSupportsTransferableStreams = !1), _cachedSupportsTransferableStreams === void 0)
    try {
      const { port1: r } = new MessageChannel(), e = new ReadableStream();
      r.postMessage(e, [e]);
      try {
        r.close();
      } catch {
      }
      _cachedSupportsTransferableStreams = !0;
    } catch {
      _cachedSupportsTransferableStreams = !1;
    }
  return _cachedSupportsTransferableStreams;
}
function streamToPort(r) {
  const { port1: e, port2: t } = new MessageChannel();
  return (async () => {
    const s = r.getReader();
    try {
      for (; ; ) {
        const { done: n, value: i } = await s.read();
        if (n) {
          try {
            e.postMessage({ t: "close" });
          } catch {
          }
          try {
            e.close();
          } catch {
          }
          break;
        }
        if (i) {
          const o = i.byteOffset === 0 && i.byteLength === i.buffer.byteLength ? i : i.slice(), a = o.buffer;
          try {
            e.postMessage({ t: "chunk", b: a }, [
              a
            ]);
          } catch {
            e.postMessage({
              t: "chunk",
              b: o.buffer.slice(0)
            });
          }
        }
      }
    } catch (n) {
      try {
        e.postMessage({ t: "error", m: (n == null ? void 0 : n.message) || String(n) });
      } catch {
      }
    } finally {
      try {
        e.close();
      } catch {
      }
    }
  })(), t;
}
function portToStream(r) {
  return new ReadableStream({
    start(e) {
      const t = (n) => {
        const i = n.data;
        if (i)
          switch (i.t) {
            case "chunk":
              try {
                e.enqueue(new Uint8Array(i.b));
              } catch {
                s();
              }
              break;
            case "close":
              safeStreamClose(e), s();
              break;
            case "error":
              safeStreamError(
                e,
                new Error(i.m || "Stream error")
              ), s();
              break;
          }
      }, s = () => {
        var n;
        try {
          (n = r.removeEventListener) == null || n.call(r, "message", t);
        } catch {
        }
        try {
          r.onmessage = null;
        } catch {
        }
        try {
          r.close();
        } catch {
        }
      };
      r.addEventListener ? r.addEventListener("message", t) : r.on ? r.on(
        "message",
        (n) => t({ data: n })
      ) : r.onmessage = t, typeof r.start == "function" && r.start();
    },
    cancel() {
      try {
        r.close();
      } catch {
      }
    }
  });
}
function promiseToPort(r) {
  const { port1: e, port2: t } = new MessageChannel();
  return r.then((s) => {
    try {
      e.postMessage({ t: "resolve", v: s });
    } catch {
    }
  }).catch((s) => {
    try {
      e.postMessage({
        t: "reject",
        m: (s == null ? void 0 : s.message) || String(s)
      });
    } catch {
    }
  }).finally(() => {
    try {
      e.close();
    } catch {
    }
  }), t;
}
function portToPromise(r) {
  return new Promise((e, t) => {
    const s = (i) => {
      const o = i.data;
      o && (o.t === "resolve" ? (n(), e(o.v)) : o.t === "reject" && (n(), t(new Error(o.m || ""))));
    }, n = () => {
      var i;
      try {
        (i = r.removeEventListener) == null || i.call(r, "message", s);
      } catch {
      }
      try {
        r.onmessage = null;
      } catch {
      }
      try {
        r.close();
      } catch {
      }
    };
    r.addEventListener ? r.addEventListener("message", s) : r.on ? r.on(
      "message",
      (i) => s({ data: i })
    ) : r.onmessage = s, typeof r.start == "function" && r.start();
  });
}
const throwTransferHandler = transferHandlers.get(
  "throw"
), throwTransferHandlerCustom = {
  canHandle: throwTransferHandler.canHandle,
  serialize: ({ value: r }) => {
    let e;
    return r instanceof Error ? (e = {
      isError: !0,
      value: serializeError(r)
    }, e.value.originalErrorClassName = r.constructor.name) : e = { isError: !1, value: r }, [e, []];
  },
  deserialize: (r) => {
    if (r.isError) {
      const e = deserializeError(r.value), t = new Error("Comlink method call failed");
      let s = e;
      for (; s.cause; )
        s = s.cause;
      throw s.cause = t, e;
    }
    throw r.value;
  }
};
transferHandlers.set("throw", throwTransferHandlerCustom);
function proxyClone(r) {
  return new Proxy(r, {
    get(e, t) {
      switch (typeof e[t]) {
        case "function":
          return (...s) => e[t](...s);
        case "object":
          return e[t] === null ? e[t] : proxyClone(e[t]);
        case "undefined":
        case "number":
        case "string":
          return e[t];
        default:
          return proxy(e[t]);
      }
    }
  });
}
function safeStreamError(r, e) {
  try {
    r.error(e);
  } catch {
  }
}
function safeStreamClose(r) {
  try {
    r.close();
  } catch {
  }
}
const MAX_ADDRESSABLE_FILE_OFFSET = BigInt(Number.MAX_SAFE_INTEGER);
class IntervalNode {
  constructor(e) {
    this.left = null, this.right = null, this.range = e, this.max = e.end;
  }
}
class FileLockIntervalTree {
  constructor() {
    this.root = null;
  }
  isEmpty() {
    return this.root === null;
  }
  /**
   * Insert a new locked range into the tree
   */
  insert(e) {
    this.root = this.insertNode(this.root, e);
  }
  /**
   * Find all ranges that overlap with the given range
   */
  findOverlapping(e) {
    const t = [];
    return this.findOverlappingRanges(this.root, e, t), t;
  }
  /**
   * Remove a lock range from the tree
   */
  remove(e) {
    this.root = this.removeNode(this.root, e);
  }
  /**
   * Find all ranges locked by the given process.
   *
   * @param pid The process ID to find locks for.
   * @returns All locked ranges for the given process.
   */
  findLocksForProcess(e) {
    const t = [];
    return this.findLocksForProcessInNode(this.root, e, t), t;
  }
  /**
   * Find the strictest existing lock type in the range lock tree.
   *
   * @returns The strictest existing lock type, or 'unlocked' if no locks exist.
   */
  findStrictestExistingLockType() {
    let e = "unlocked";
    const t = (s) => {
      if (s) {
        if (s.range.type === "exclusive") {
          e = "exclusive";
          return;
        }
        s.range.type === "shared" && (e = "shared"), t(s.left), t(s.right);
      }
    };
    return t(this.root), e;
  }
  insertNode(e, t) {
    return e ? (t.start < e.range.start ? e.left = this.insertNode(e.left, t) : e.right = this.insertNode(e.right, t), e.max = this.bigintMax(e.max, t.end), e) : new IntervalNode(t);
  }
  bigintMax(...e) {
    return e.reduce((t, s) => s > t ? s : t, e[0]);
  }
  findOverlappingRanges(e, t, s) {
    e && (this.doRangesOverlap(e.range, t) && s.push(e.range), e.left && e.left.max >= t.start && this.findOverlappingRanges(e.left, t, s), e.right && e.range.start <= t.end && this.findOverlappingRanges(e.right, t, s));
  }
  doRangesOverlap(e, t) {
    return e.start < t.end && t.start < e.end;
  }
  removeNode(e, t) {
    if (!e)
      return null;
    if (this.areRangesEqual(e.range, t)) {
      if (!e.left)
        return e.right;
      if (!e.right)
        return e.left;
      const s = this.findMin(e.right);
      e.range = s.range, e.right = this.removeNode(e.right, s.range);
    } else t.start < e.range.start ? e.left = this.removeNode(e.left, t) : e.right = this.removeNode(e.right, t);
    return e.max = e.range.end, e.left && (e.max = this.bigintMax(e.max, e.left.max)), e.right && (e.max = this.bigintMax(e.max, e.right.max)), e;
  }
  findMin(e) {
    let t = e;
    for (; t.left; )
      t = t.left;
    return t;
  }
  areRangesEqual(e, t) {
    return e.start === t.start && e.end === t.end && e.pid === t.pid && e.fd === t.fd;
  }
  findLocksForProcessInNode(e, t, s) {
    e && (e.range.pid === t && s.push(e.range), this.findLocksForProcessInNode(e.left, t, s), this.findLocksForProcessInNode(e.right, t, s));
  }
}
class FileLockManagerInMemory {
  /**
   * Create a new FileLockManagerInMemory instance.
   *
   * @param nativeFlockSync A synchronous flock() function to lock files via the host OS.
   */
  constructor() {
    this.locks = /* @__PURE__ */ new Map();
  }
  /**
   * Lock the whole file.
   *
   * @param path The path to the file to lock. This should be the path
   *             of the file in the native filesystem.
   * @param op The whole file lock operation to perform.
   * @returns True if the lock was granted, false otherwise.
   */
  lockWholeFile(e, t) {
    if (this.locks.get(e) === void 0) {
      if (t.type === "unlock")
        return !0;
      this.locks.set(e, new FileLock());
    }
    const n = this.locks.get(e).lockWholeFile(t);
    return this.forgetPathIfUnlocked(e), n;
  }
  /**
   * Lock a byte range.
   *
   * @param path The path to the file to lock. This should be the path
   *             of the file in the native filesystem.
   * @param requestedLock The byte range lock to perform.
   * @returns True if the lock was granted, false otherwise.
   */
  lockFileByteRange(e, t) {
    if (!this.locks.has(e)) {
      if (t.type === "unlocked")
        return !0;
      this.locks.set(e, new FileLock());
    }
    return this.locks.get(e).lockFileByteRange(t);
  }
  /**
   * Find the first conflicting byte range lock.
   *
   * @param path The path to the file to find the conflicting lock for.
   * @param desiredLock The desired byte range lock.
   * @returns The first conflicting byte range lock, or undefined if no conflicting lock exists.
   */
  findFirstConflictingByteRangeLock(e, t) {
    const s = this.locks.get(e);
    if (s !== void 0)
      return s.findFirstConflictingByteRangeLock(t);
  }
  /**
   * Release all locks for the given process.
   *
   * @param pid The process ID to release locks for.
   */
  releaseLocksForProcess(e) {
    for (const [t, s] of this.locks.entries())
      s.releaseLocksForProcess(e), this.forgetPathIfUnlocked(t);
  }
  /**
   * Release all locks for the given process and file descriptor.
   *
   * @param pid The process ID to release locks for.
   * @param fd The file descriptor to release locks for.
   * @param path The path to the file to release locks for.
   */
  releaseLocksOnFdClose(e, t, s) {
    const n = this.locks.get(s);
    n && (n.releaseLocksOnFdClose(e, t), this.forgetPathIfUnlocked(s));
  }
  /**
   * Forget the path if it is unlocked.
   *
   * @param path The path to the file to forget.
   */
  forgetPathIfUnlocked(e) {
    const t = this.locks.get(e);
    t && t.isUnlocked() && this.locks.delete(e);
  }
}
class FileLock {
  constructor() {
    this.rangeLocks = new FileLockIntervalTree(), this.wholeFileLock = { type: "unlocked" };
  }
  /**
   * Lock the whole file.
   *
   * This method corresponds to the flock() function.
   *
   * @param op The whole file lock operation to perform.
   * @returns True if the lock was granted, false otherwise.
   */
  lockWholeFile(e) {
    if (e.type === "unlock")
      return this.wholeFileLock.type === "unlocked" || (this.wholeFileLock.type === "exclusive" && this.wholeFileLock.pid === e.pid && this.wholeFileLock.fd === e.fd ? this.wholeFileLock = { type: "unlocked" } : this.wholeFileLock.type === "shared" && this.wholeFileLock.pidFds.has(e.pid) && this.wholeFileLock.pidFds.get(e.pid).has(e.fd) && (this.wholeFileLock.pidFds.get(e.pid).delete(e.fd), this.wholeFileLock.pidFds.get(e.pid).size === 0 && this.wholeFileLock.pidFds.delete(e.pid), this.wholeFileLock.pidFds.size === 0 && (this.wholeFileLock = { type: "unlocked" }))), !0;
    if (this.isThereAConflictWithRequestedWholeFileLock(e))
      return !1;
    if (e.type === "exclusive")
      return this.wholeFileLock = {
        type: "exclusive",
        pid: e.pid,
        fd: e.fd
      }, !0;
    if (e.type === "shared") {
      this.wholeFileLock.type !== "shared" && (this.wholeFileLock = {
        type: "shared",
        pidFds: /* @__PURE__ */ new Map()
      });
      const t = this.wholeFileLock;
      return t.pidFds.has(e.pid) || t.pidFds.set(e.pid, /* @__PURE__ */ new Set()), t.pidFds.get(e.pid).add(e.fd), !0;
    }
    throw new Error(`Unexpected wholeFileLock() op: '${e.type}'`);
  }
  /**
   * Lock a byte range.
   *
   * This method corresponds to the fcntl() F_SETLK command.
   *
   * @param requestedLock The byte range lock to perform.
   * @returns True if the lock was granted, false otherwise.
   */
  lockFileByteRange(e) {
    if (e.start === e.end && (e = {
      ...e,
      end: MAX_ADDRESSABLE_FILE_OFFSET
    }), e.type === "unlocked") {
      const o = this.rangeLocks.findOverlapping(e).filter((a) => a.pid === e.pid);
      for (const a of o)
        this.rangeLocks.remove(a), a.start < e.start && this.rangeLocks.insert({
          ...a,
          end: e.start
        }), a.end > e.end && this.rangeLocks.insert({
          ...a,
          start: e.end
        });
      return !0;
    }
    if (this.isThereAConflictWithRequestedRangeLock(e))
      return !1;
    const t = this.rangeLocks.findOverlapping(e).filter((o) => o.pid === e.pid);
    let s = e.start, n = e.end;
    for (const o of t)
      this.rangeLocks.remove(o), o.start < s && (s = o.start), o.end > n && (n = o.end);
    const i = {
      ...e,
      start: s,
      end: n
    };
    return this.rangeLocks.insert(i), !0;
  }
  /**
   * Find the first conflicting byte range lock.
   *
   * This method corresponds to the fcntl() F_GETLK command.
   *
   * @param desiredLock The desired byte range lock.
   * @returns The first conflicting byte range lock, or undefined if no conflicting lock exists.
   */
  findFirstConflictingByteRangeLock(e) {
    e.start === e.end && (e = {
      ...e,
      end: MAX_ADDRESSABLE_FILE_OFFSET
    });
    const s = this.rangeLocks.findOverlapping(e).find(
      (i) => i.pid !== e.pid && (e.type === "exclusive" || i.type === "exclusive")
    );
    if (s)
      return s;
    if (this.wholeFileLock.type === "unlocked")
      return;
    if (this.wholeFileLock.type === "exclusive" || e.type === "exclusive")
      return {
        type: this.wholeFileLock.type,
        start: 0n,
        end: 0n,
        pid: -1
      };
  }
  /**
   * Release all locks for the given process.
   *
   * @param pid The process ID to release locks for.
   */
  releaseLocksForProcess(e) {
    for (const t of this.rangeLocks.findLocksForProcess(e))
      this.lockFileByteRange({
        ...t,
        type: "unlocked"
      });
    if (this.wholeFileLock.type === "exclusive" && this.wholeFileLock.pid === e)
      this.lockWholeFile({
        pid: e,
        fd: this.wholeFileLock.fd,
        type: "unlock"
      });
    else if (this.wholeFileLock.type === "shared" && this.wholeFileLock.pidFds.has(e))
      for (const t of this.wholeFileLock.pidFds.get(e))
        this.lockWholeFile({
          pid: e,
          fd: t,
          type: "unlock"
        });
  }
  /**
   * Release all locks for the given process and file descriptor.
   *
   * @param pid The process ID to release locks for.
   * @param fd The file descriptor to release locks for.
   */
  releaseLocksOnFdClose(e, t) {
    for (const s of this.rangeLocks.findLocksForProcess(e))
      this.lockFileByteRange({
        ...s,
        type: "unlocked"
      });
    this.lockWholeFile({
      pid: e,
      fd: t,
      type: "unlock"
    });
  }
  /**
   * Check if the file lock is unlocked.
   *
   * @returns True if the file lock is unlocked, false otherwise.
   */
  isUnlocked() {
    return this.wholeFileLock.type === "unlocked" && this.rangeLocks.isEmpty();
  }
  /**
   * Check if a lock exists that conflicts with the requested range lock.
   *
   * @param requestedLock The desired byte range lock.
   * @returns True if a conflicting lock exists, false otherwise.
   */
  isThereAConflictWithRequestedRangeLock(e) {
    return this.findFirstConflictingByteRangeLock(e) !== void 0;
  }
  /**
   * Check if a lock exists that conflicts with the requested whole-file lock.
   *
   * @param requestedLock The desired whole-file lock.
   * @returns True if a conflicting lock exists, false otherwise.
   */
  isThereAConflictWithRequestedWholeFileLock(e) {
    return e.type === "exclusive" ? !!(this.wholeFileLock.type === "exclusive" && (this.wholeFileLock.fd !== e.fd || this.wholeFileLock.pid !== e.pid) || this.wholeFileLock.type === "shared" && Array.from(this.wholeFileLock.pidFds).some(
      ([s]) => s !== e.pid
    ) || this.rangeLocks.findOverlapping({
      start: 0n,
      end: MAX_ADDRESSABLE_FILE_OFFSET
    }).length > 0) : e.type === "shared" ? this.wholeFileLock.type === "exclusive" && this.wholeFileLock.pid !== e.pid || this.rangeLocks.findOverlapping({
      start: 0n,
      end: MAX_ADDRESSABLE_FILE_OFFSET
    }).filter(
      (n) => n.type === "exclusive"
    ).length > 0 : !1;
  }
}
class FileLockManagerComposite {
  constructor({
    nativeLockManager: e,
    wasmLockManager: t
  }) {
    this.nativeLockManager = e, this.wasmLockManager = t;
  }
  lockWholeFile(e, t) {
    if (t.type !== "unlock") {
      let s, n;
      try {
        if (s = this.nativeLockManager.lockWholeFile(e, t), !s)
          return !1;
        n = this.wasmLockManager.lockWholeFile(e, t);
      } catch (i) {
        logger.error("Unexpected error in lockWholeFile()", i);
      } finally {
        s && !n && this.nativeLockManager.lockWholeFile(e, {
          ...t,
          type: "unlock"
        });
      }
      return !!s && !!n;
    }
    try {
      this.wasmLockManager.lockWholeFile(e, t);
    } catch (s) {
      logger.error(
        "Unexpected error unlocking whole file with in-memory lock manager",
        s
      );
    }
    try {
      this.nativeLockManager.lockWholeFile(e, t);
    } catch (s) {
      logger.error(
        "Unexpected error unlocking whole file with native lock manager",
        s
      );
    }
    return !0;
  }
  lockFileByteRange(e, t, s) {
    if (t.type !== "unlocked") {
      let n, i;
      try {
        if (n = this.nativeLockManager.lockFileByteRange(
          e,
          t,
          s
        ), !n)
          return !1;
        i = this.wasmLockManager.lockFileByteRange(
          e,
          t,
          s
        );
      } catch (o) {
        logger.error("Unexpected error in lockFileByteRange()", o);
      } finally {
        n && !i && this.nativeLockManager.lockFileByteRange(
          e,
          {
            ...t,
            type: "unlocked"
          },
          !1
        );
      }
      return !!n && !!i;
    }
    try {
      this.wasmLockManager.lockFileByteRange(
        e,
        t,
        s
      );
    } catch (n) {
      logger.error(
        "Unexpected error unlocking byte range with in-memory lock manager",
        n
      );
    }
    try {
      this.nativeLockManager.lockFileByteRange(
        e,
        t,
        s
      );
    } catch (n) {
      logger.error(
        "Unexpected error unlocking byte range with native lock manager",
        n
      );
    }
    return !0;
  }
  findFirstConflictingByteRangeLock(e, t) {
    try {
      const s = this.nativeLockManager.findFirstConflictingByteRangeLock(
        e,
        t
      );
      return s || this.wasmLockManager.findFirstConflictingByteRangeLock(
        e,
        t
      );
    } catch (s) {
      logger.error(
        "Unexpected error in findFirstConflictingByteRangeLock()",
        s
      );
      return;
    }
  }
  releaseLocksForProcess(e) {
    try {
      this.wasmLockManager.releaseLocksForProcess(e);
    } catch (t) {
      logger.error(
        "Unexpected error in wasmLockManager.releaseLocksForProcess()",
        t
      );
    }
    try {
      this.nativeLockManager.releaseLocksForProcess(e);
    } catch (t) {
      logger.error(
        "Unexpected error in nativeLockManager.releaseLocksForProcess()",
        t
      );
    }
  }
  releaseLocksOnFdClose(e, t, s) {
    try {
      this.wasmLockManager.releaseLocksOnFdClose(e, t, s);
    } catch (n) {
      logger.error(
        "Unexpected error in wasmLockManager.releaseLocksOnFdClose()",
        n
      );
    }
    try {
      this.nativeLockManager.releaseLocksOnFdClose(e, t, s);
    } catch (n) {
      logger.error(
        "Unexpected error in nativeLockManager.releaseLocksOnFdClose()",
        n
      );
    }
  }
}
function createObjectPoolProxy(r) {
  if (r.length === 0)
    throw new Error("At least one instance is required");
  const e = [...r], t = [], s = /* @__PURE__ */ new Set();
  function n(l) {
    const u = l, h = r.indexOf(u);
    h !== -1 && r.splice(h, 1);
    const p = e.indexOf(u);
    p !== -1 ? e.splice(p, 1) : s.add(u);
  }
  function i() {
    const l = e.shift();
    return l !== void 0 ? Promise.resolve(l) : new Promise((u) => {
      t.push(u);
    });
  }
  function o(l) {
    if (s.has(l)) {
      s.delete(l);
      return;
    }
    const u = t.shift();
    u ? u(l) : e.push(l);
  }
  function a(l) {
    return i().then((u) => {
      let h;
      try {
        h = l(u);
      } catch (p) {
        throw o(u), p;
      }
      return h != null && typeof h.then == "function" ? h.then(
        (p) => (o(u), p),
        (p) => {
          throw o(u), p;
        }
      ) : (o(u), h);
    });
  }
  const c = {};
  return c.__removeInstance = n, new Proxy(c, {
    get(l, u) {
      if (u in l)
        return l[u];
      if (u !== "then")
        return new Proxy(function() {
        }, {
          apply(h, p, g) {
            return a((E) => E[u](...g));
          },
          get(h, p) {
            if (p === "then")
              return (g, E) => a((j) => j[u]).then(
                g,
                E
              );
          }
        });
    }
  });
}
const maxValueForSigned32BitInteger = 2 ** 31 - 1;
class ProcessIdAllocator {
  constructor(e = 1, t = maxValueForSigned32BitInteger) {
    this.claimed = /* @__PURE__ */ new Set(), this.initialId = e, this.maxId = t, this.nextId = e;
  }
  claim() {
    const e = this.maxId - this.initialId + 1;
    for (let t = 0; t < e; t++)
      if (this.claimed.has(this.nextId))
        this.nextId++, this.nextId > this.maxId && (this.nextId = this.initialId);
      else
        return this.claimed.add(this.nextId), this.nextId;
    throw new Error(
      `Unable to find free process ID after ${e} tries.`
    );
  }
  release(e) {
    return this.claimed.has(e) ? (this.claimed.delete(e), !0) : !1;
  }
}
export {
  DEFAULT_BASE_URL,
  FSHelpers,
  FileLock,
  FileLockIntervalTree,
  FileLockManagerComposite,
  FileLockManagerInMemory,
  HttpCookieStore,
  LatestSupportedPHPVersion,
  MAX_ADDRESSABLE_FILE_OFFSET,
  PHP,
  PHPExecutionFailureError,
  PHPProcessManager,
  PHPRequestHandler,
  PHPResponse,
  PHPWorker,
  ProcessIdAllocator,
  SinglePHPInstanceManager,
  StreamedPHPResponse,
  SupportedPHPVersions,
  SupportedPHPVersionsList,
  UnhandledRejectionsTarget,
  __private__dont__use,
  applyRewriteRules,
  consumeAPI,
  consumeAPISync,
  createObjectPoolProxy,
  ensurePathPrefix,
  exposeAPI,
  exposeSyncAPI,
  getPhpIniEntries,
  inferMimeType,
  isExitCode,
  isPathToSharedFS,
  iteratePhpFiles as iterateFiles,
  loadPHPRuntime,
  popLoadedRuntime,
  portToStream,
  prettyPrintFullStackTrace,
  printDebugDetails,
  printResponseDebugDetails,
  proxyFileSystem,
  releaseApiProxy,
  removePathPrefix,
  rotatePHPRuntime,
  sandboxedSpawnHandlerFactory,
  setPhpIniEntries,
  streamToPort,
  toRelativeUrl,
  withPHPIniValues,
  writeFiles,
  writeFilesStreamToPhp
};
//# sourceMappingURL=index.js.map
