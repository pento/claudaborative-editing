/**
 * Determines whether the current process should respawn itself with
 * the --experimental-wasm-jspi flag to enable JSPI support.
 *
 * Returns true only when all of these hold:
 *  1. JSPI is not already available in this runtime.
 *  2. We're running on Node.js (not Bun, Deno, or another runtime).
 *  3. The flag hasn't already been passed (avoids infinite loops).
 *  4. The Node.js version is >= 23 (the first version whose V8 has
 *     the current JSPI spec with WebAssembly.Suspending).
 *
 * Why not Node 22? It ships V8 12.4 which only exposes the old,
 * since-removed JSPI API (WebAssembly.Suspender). The new API
 * (WebAssembly.Suspending) arrived in V8 12.6 = Node 23.
 */
export declare function shouldRespawnWithJSPI(): boolean;
