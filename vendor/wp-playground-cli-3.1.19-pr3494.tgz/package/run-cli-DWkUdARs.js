import { logger as w, LogSeverity as F, errorLogPath as oe } from "@php-wasm/logger";
import { consumeAPI as he, ProcessIdAllocator as ke, SupportedPHPVersions as U, printDebugDetails as Me, HttpCookieStore as Ce, FileLockManagerInMemory as Ae, StreamedPHPResponse as j, createObjectPoolProxy as Be, exposeAPI as De, PHPResponse as Re, exposeSyncAPI as We } from "@php-wasm/universal";
import { resolveRemoteBlueprint as _e, resolveRuntimeConfiguration as ie, compileBlueprintV1 as we, isBlueprintBundle as Le, runBlueprintV1Steps as ne } from "@wp-playground/blueprints";
import { zipDirectory as Ue, RecommendedPHPVersion as D } from "@wp-playground/common";
import p, { existsSync as Q, rmdirSync as He, mkdirSync as z, readdirSync as Ne } from "fs";
import { MessageChannel as ye, Worker as se } from "worker_threads";
import { createNodeFsMountHandler as Oe } from "@php-wasm/node";
import d, { basename as L, join as X } from "path";
import { exec as be } from "child_process";
import { promisify as Fe } from "util";
import ge from "express";
import { Readable as je } from "stream";
import { pipeline as Ve } from "stream/promises";
import Ye from "yargs";
import { NodeJsFilesystem as qe, OverlayFilesystem as ze, InMemoryFilesystem as Ge, ZipFilesystem as Qe } from "@wp-playground/storage";
import { EmscriptenDownloadMonitor as Xe, ProgressTracker as Ze } from "@php-wasm/progress";
import { resolveWordPressRelease as Je } from "@wp-playground/wordpress";
import k from "fs-extra";
import { createRequire as Ke } from "module";
import Z from "os";
import { startBridge as et } from "@php-wasm/xdebug-bridge";
import { dir as tt, setGracefulCleanup as rt } from "tmp-promise";
import { removeTempDirSymlink as ot, createTempDirSymlink as ae, makeXdebugConfig as it, DEFAULT_PATH_SKIPPINGS as le, clearXdebugIDEConfig as nt, addXdebugIDEConfig as st } from "@php-wasm/cli-util";
import { createHash as at } from "crypto";
import { PHPMYADMIN_INSTALL_PATH as ue, getPhpMyAdminInstallSteps as lt, PHPMYADMIN_ENTRY_PATH as ut } from "@wp-playground/tools";
import { jspi as de } from "wasm-feature-detect";
function V(e) {
  const t = [];
  for (const r of e) {
    const o = r.split(":");
    if (o.length !== 2)
      throw new Error(`Invalid mount format: ${r}.
				Expected format: /host/path:/vfs/path.
				If your path contains a colon, e.g. C:\\myplugin, use the --mount-dir option instead.
				Example: --mount-dir C:\\my-plugin /wordpress/wp-content/plugins/my-plugin`);
    const [i, n] = o;
    if (!Q(i))
      throw new Error(`Host path does not exist: ${i}`);
    t.push({ hostPath: i, vfsPath: n });
  }
  return t;
}
function ce(e) {
  if (e.length % 2 !== 0)
    throw new Error("Invalid mount format. Expected: /host/path /vfs/path");
  const t = [];
  for (let r = 0; r < e.length; r += 2) {
    const o = e[r], i = e[r + 1];
    if (!Q(o))
      throw new Error(`Host path does not exist: ${o}`);
    t.push({
      hostPath: d.resolve(process.cwd(), o),
      vfsPath: i
    });
  }
  return t;
}
async function br(e, t) {
  for (const r of t)
    await e.mount(
      r.vfsPath,
      Oe(r.hostPath)
    );
}
const pe = {
  step: "runPHP",
  code: {
    filename: "activate-theme.php",
    // @TODO: Remove DOCROOT check after moving totally to Blueprints v2.
    content: `<?php
			$docroot = getenv('DOCROOT') ? getenv('DOCROOT') : '/wordpress';
			require_once "$docroot/wp-load.php";
			$theme = wp_get_theme();
			if (!$theme->exists()) {
				$themes = wp_get_themes();
				if (count($themes) > 0) {
					$themeName = array_keys($themes)[0];
					switch_theme($themeName);
				}
			}
		`
  }
};
function Pe(e) {
  const t = e.autoMount, r = [...e.mount || []], o = [...e["mount-before-install"] || []], i = {
    ...e,
    mount: r,
    "mount-before-install": o,
    "additional-blueprint-steps": [
      ...e["additional-blueprint-steps"] || []
    ]
  };
  if (mt(t)) {
    const s = `/wordpress/wp-content/plugins/${L(t)}`;
    r.push({
      hostPath: t,
      vfsPath: s,
      autoMounted: !0
    }), i["additional-blueprint-steps"].push({
      step: "activatePlugin",
      pluginPath: `/wordpress/wp-content/plugins/${L(t)}`
    });
  } else if (pt(t)) {
    const n = L(t), s = `/wordpress/wp-content/themes/${n}`;
    r.push({
      hostPath: t,
      vfsPath: s,
      autoMounted: !0
    }), i["additional-blueprint-steps"].push(
      e["experimental-blueprints-v2-runner"] ? {
        step: "activateTheme",
        themeDirectoryName: n
      } : {
        step: "activateTheme",
        themeFolderName: n
      }
    );
  } else if (ct(t)) {
    const n = p.readdirSync(t);
    for (const s of n)
      s !== "index.php" && r.push({
        hostPath: X(t, s),
        vfsPath: `/wordpress/wp-content/${s}`,
        autoMounted: !0
      });
    i["additional-blueprint-steps"].push(pe);
  } else dt(t) && (o.push({
    hostPath: t,
    vfsPath: "/wordpress",
    autoMounted: !0
  }), i.mode = "apply-to-existing-site", i["additional-blueprint-steps"].push(pe), i.wordpressInstallMode || (i.wordpressInstallMode = "install-from-existing-files-if-needed"));
  return i;
}
function dt(e) {
  const t = p.readdirSync(e);
  return t.includes("wp-admin") && t.includes("wp-includes") && t.includes("wp-content");
}
function ct(e) {
  const t = p.readdirSync(e);
  return t.includes("themes") || t.includes("plugins") || t.includes("mu-plugins") || t.includes("uploads");
}
function pt(e) {
  if (!p.readdirSync(e).includes("style.css"))
    return !1;
  const r = p.readFileSync(X(e, "style.css"), "utf8");
  return !!/^(?:[ \t]*<\?php)?[ \t/*#@]*Theme Name:(.*)$/im.exec(r);
}
function mt(e) {
  const t = p.readdirSync(e), r = /^(?:[ \t]*<\?php)?[ \t/*#@]*Plugin Name:(.*)$/im;
  return !!t.filter((i) => i.endsWith(".php")).find((i) => {
    const n = p.readFileSync(X(e, i), "utf8");
    return !!r.exec(n);
  });
}
function ft(e) {
  if (e.length % 2 !== 0)
    throw new Error(
      "Invalid constant definition format. Expected pairs of NAME value"
    );
  const t = {};
  for (let r = 0; r < e.length; r += 2) {
    const o = e[r], i = e[r + 1];
    if (!o || !o.trim())
      throw new Error("Constant name cannot be empty");
    t[o.trim()] = i;
  }
  return t;
}
function ht(e) {
  if (e.length % 2 !== 0)
    throw new Error(
      "Invalid boolean constant definition format. Expected pairs of NAME value"
    );
  const t = {};
  for (let r = 0; r < e.length; r += 2) {
    const o = e[r], i = e[r + 1].trim().toLowerCase();
    if (!o || !o.trim())
      throw new Error("Constant name cannot be empty");
    if (i === "true" || i === "1")
      t[o.trim()] = !0;
    else if (i === "false" || i === "0")
      t[o.trim()] = !1;
    else
      throw new Error(
        `Invalid boolean value for constant "${o}": "${i}". Must be "true", "false", "1", or "0".`
      );
  }
  return t;
}
function wt(e) {
  if (e.length % 2 !== 0)
    throw new Error(
      "Invalid number constant definition format. Expected pairs of NAME value"
    );
  const t = {};
  for (let r = 0; r < e.length; r += 2) {
    const o = e[r], i = e[r + 1].trim();
    if (!o || !o.trim())
      throw new Error("Constant name cannot be empty");
    const n = Number(i);
    if (isNaN(n))
      throw new Error(
        `Invalid number value for constant "${o}": "${i}". Must be a valid number.`
      );
    t[o.trim()] = n;
  }
  return t;
}
function yt(e = {}, t = {}, r = {}) {
  const o = {}, i = /* @__PURE__ */ new Set(), n = (s, l) => {
    for (const u in s) {
      if (i.has(u))
        throw new Error(
          `Constant "${u}" is defined multiple times across different --define-${l} flags`
        );
      i.add(u), o[u] = s[u];
    }
  };
  return n(e, "string"), n(t, "bool"), n(r, "number"), o;
}
function J(e) {
  return yt(
    e.define,
    e["define-bool"],
    e["define-number"]
  );
}
const bt = Fe(be);
function gt(e) {
  return new Promise((t) => {
    if (e === 0) return t(!1);
    const r = ge().listen(e);
    r.once("listening", () => r.close(() => t(!1))), r.once(
      "error",
      (o) => t(o.code === "EADDRINUSE")
    );
  });
}
async function Pt(e) {
  const t = ge(), r = await new Promise((s, l) => {
    const u = t.listen(e.port, () => {
      const h = u.address();
      h === null || typeof h == "string" ? l(new Error("Server address is not available")) : s(u);
    }).once("error", l);
  });
  t.use("/", async (s, l) => {
    try {
      const u = {
        url: s.url,
        headers: Et(s),
        method: s.method,
        body: await St(s)
      };
      await e.handleRequest(
        u,
        (h) => vt(h, l)
      );
    } catch (u) {
      w.error(u), l.headersSent || (l.statusCode = 500, l.end("Internal Server Error"));
    }
  });
  const i = r.address().port, n = process.env.CODESPACE_NAME;
  return n && xt(i, n), await e.onBind(r, i);
}
async function vt(e, t) {
  const [r, o] = await Promise.all([
    e.headers,
    e.httpStatusCode
  ]);
  t.statusCode = o;
  for (const n in r)
    t.setHeader(n, r[n]);
  const i = je.fromWeb(e.stdout);
  try {
    await Ve(i, t);
  } catch (n) {
    if (n instanceof Error && "code" in n && (n.code === "ERR_STREAM_PREMATURE_CLOSE" || n.code === "ERR_STREAM_UNABLE_TO_PIPE"))
      return;
    throw n;
  }
}
const St = async (e) => await new Promise((t) => {
  const r = [];
  e.on("data", (o) => {
    r.push(o);
  }), e.on("end", () => {
    t(new Uint8Array(Buffer.concat(r)));
  });
});
async function xt(e, t) {
  w.log(`Publishing port ${e}...`);
  const r = `gh codespace ports visibility ${e}:public -c ${t}`;
  for (let o = 0; o < 10; o++)
    try {
      await bt(r);
      return;
    } catch {
      await new Promise((i) => setTimeout(i, 2e3));
    }
}
const Et = (e) => {
  const t = {};
  if (e.rawHeaders && e.rawHeaders.length)
    for (let r = 0; r < e.rawHeaders.length; r += 2)
      t[e.rawHeaders[r].toLowerCase()] = e.rawHeaders[r + 1];
  return t;
};
function $t(e) {
  return /^latest$|^beta$|^trunk$|^nightly$|^(?:(\d+)\.(\d+)(?:\.(\d+))?)((?:-beta(?:\d+)?)|(?:-RC(?:\d+)?))?$/.test(e);
}
async function Tt({
  sourceString: e,
  blueprintMayReadAdjacentFiles: t
}) {
  if (!e)
    return;
  if (e.startsWith("http://") || e.startsWith("https://"))
    return await _e(e);
  let r = d.resolve(process.cwd(), e);
  if (!p.existsSync(r))
    throw new Error(`Blueprint file does not exist: ${r}`);
  const o = p.statSync(r);
  if (o.isDirectory() && (r = d.join(r, "blueprint.json")), !o.isFile() && o.isSymbolicLink())
    throw new Error(
      `Blueprint path is neither a file nor a directory: ${r}`
    );
  const i = d.extname(r);
  switch (i) {
    case ".zip":
      return Qe.fromArrayBuffer(
        p.readFileSync(r).buffer
      );
    case ".json": {
      const n = p.readFileSync(r, "utf-8");
      try {
        JSON.parse(n);
      } catch {
        throw new Error(
          `Blueprint file at ${r} is not a valid JSON file`
        );
      }
      const s = d.dirname(r), l = new qe(s);
      return new ze([
        new Ge({
          "blueprint.json": n
        }),
        /**
         * Wrap the NodeJS filesystem to prevent access to local files
         * unless the user explicitly allowed it.
         */
        {
          read(u) {
            if (!t)
              throw new Error(
                `Error: Blueprint contained tried to read a local file at path "${u}" (via a resource of type "bundled"). Playground restricts access to local resources by default as a security measure. 

You can allow this Blueprint to read files from the same parent directory by explicitly adding the --blueprint-may-read-adjacent-files option to your command.`
              );
            return l.read(u);
          }
        }
      ]);
    }
    default:
      throw new Error(
        `Unsupported blueprint file extension: ${i}. Only .zip and .json files are supported.`
      );
  }
}
class It {
  constructor(t, r) {
    this.args = t, this.siteUrl = r.siteUrl, this.phpVersion = t.php, this.cliOutput = r.cliOutput;
  }
  getWorkerType() {
    return "v2";
  }
  async bootWordPress(t, r) {
    const o = {
      command: this.args.command,
      siteUrl: this.siteUrl,
      blueprint: this.args.blueprint,
      workerPostInstallMountsPort: r
    };
    return await t.bootWordPress(o, r), t;
  }
  async bootRequestHandler({
    worker: t,
    fileLockManagerPort: r,
    nativeInternalDirPath: o
  }) {
    const i = he(t.phpPort);
    await i.useFileLockManager(r);
    const n = {
      ...this.args,
      phpVersion: this.phpVersion,
      siteUrl: this.siteUrl,
      processId: t.processId,
      trace: this.args.verbosity === "debug",
      withIntl: this.args.intl,
      withRedis: this.args.redis,
      withMemcached: this.args.memcached,
      withXdebug: !!this.args.xdebug,
      nativeInternalDirPath: o,
      mountsBeforeWpInstall: this.args["mount-before-install"] || [],
      mountsAfterWpInstall: this.args.mount || [],
      constants: J(this.args)
    };
    return await i.bootWorker(n), i;
  }
}
const G = d.join(Z.homedir(), ".wordpress-playground");
async function kt() {
  const e = typeof __dirname < "u" ? __dirname : import.meta.dirname;
  let t = d.join(e, "sqlite-database-integration.zip");
  if (!k.existsSync(t)) {
    const r = Ke(import.meta.url), o = d.dirname(
      r.resolve("@wp-playground/wordpress-builds/package.json")
    );
    t = d.join(
      o,
      "src",
      "sqlite-database-integration",
      "sqlite-database-integration-trunk.zip"
    );
  }
  return new File([await k.readFile(t)], d.basename(t));
}
async function Mt(e, t, r) {
  const o = d.join(G, t);
  return k.existsSync(o) || (k.ensureDirSync(G), await Ct(e, o, r)), ve(o);
}
async function Ct(e, t, r) {
  const i = (await r.monitorFetch(fetch(e))).body.getReader(), n = `${t}.partial`, s = k.createWriteStream(n);
  for (; ; ) {
    const { done: l, value: u } = await i.read();
    if (u && s.write(u), l)
      break;
  }
  s.close(), s.closed || await new Promise((l, u) => {
    s.on("finish", () => {
      k.renameSync(n, t), l(null);
    }), s.on("error", (h) => {
      k.removeSync(n), u(h);
    });
  });
}
function ve(e, t) {
  return new File([k.readFileSync(e)], L(e));
}
class At {
  constructor(t, r) {
    this.args = t, this.siteUrl = r.siteUrl, this.cliOutput = r.cliOutput;
  }
  getWorkerType() {
    return "v1";
  }
  async bootWordPress(t, r) {
    let o, i, n;
    const s = new Xe();
    if (this.args.wordpressInstallMode === "download-and-install") {
      let h = !1;
      s.addEventListener("progress", (M) => {
        if (h)
          return;
        const { loaded: c, total: S } = M.detail, b = Math.floor(
          Math.min(100, 100 * c / S)
        );
        h = b === 100, this.cliOutput.updateProgress(
          "Downloading WordPress",
          b
        );
      }), o = await Je(this.args.wp), n = d.join(
        G,
        `prebuilt-wp-content-for-wp-${o.version}.zip`
      ), i = p.existsSync(n) ? ve(n) : await Mt(
        o.releaseUrl,
        `${o.version}.zip`,
        s
      ), w.debug(
        `Resolved WordPress release URL: ${o?.releaseUrl}`
      );
    }
    let l;
    this.args.skipSqliteSetup ? (w.debug("Skipping SQLite integration plugin setup..."), l = void 0) : (this.cliOutput.updateProgress("Preparing SQLite database"), l = await kt()), this.cliOutput.updateProgress("Booting WordPress");
    const u = await ie(
      this.getEffectiveBlueprint()
    );
    return await t.bootWordPress(
      {
        wpVersion: u.wpVersion,
        siteUrl: this.siteUrl,
        wordpressInstallMode: this.args.wordpressInstallMode || "download-and-install",
        wordPressZip: i && await i.arrayBuffer(),
        sqliteIntegrationPluginZip: await l?.arrayBuffer(),
        constants: J(this.args)
      },
      r
    ), n && !this.args["mount-before-install"] && !p.existsSync(n) && (this.cliOutput.updateProgress("Caching WordPress for next boot"), p.writeFileSync(
      n,
      // Comlink proxy is not assignable to UniversalPHP but
      // proxies all method calls transparently at runtime.
      await Ue(
        t,
        "/wordpress"
      )
    )), t;
  }
  async bootRequestHandler({
    worker: t,
    fileLockManagerPort: r,
    nativeInternalDirPath: o
  }) {
    const i = he(
      t.phpPort
    );
    await i.isConnected();
    const n = await ie(
      this.getEffectiveBlueprint()
    );
    return await i.useFileLockManager(r), await i.bootRequestHandler({
      phpVersion: n.phpVersion,
      siteUrl: this.siteUrl,
      mountsBeforeWpInstall: this.args["mount-before-install"] || [],
      mountsAfterWpInstall: this.args.mount || [],
      processId: t.processId,
      followSymlinks: this.args.followSymlinks === !0,
      trace: this.args.experimentalTrace === !0,
      withIntl: this.args.intl,
      withRedis: this.args.redis,
      withMemcached: this.args.memcached,
      withXdebug: !!this.args.xdebug,
      nativeInternalDirPath: o,
      pathAliases: this.args.pathAliases
    }), await i.isReady(), i;
  }
  async compileInputBlueprint(t) {
    const r = this.getEffectiveBlueprint(), o = new Ze();
    let i = "", n = !1;
    return o.addEventListener("progress", (s) => {
      if (n)
        return;
      n = s.detail.progress === 100;
      const l = Math.floor(s.detail.progress);
      i = s.detail.caption || i || "Running Blueprint", this.cliOutput.updateProgress(i.trim(), l);
    }), await we(r, {
      progress: o,
      additionalSteps: t
    });
  }
  getEffectiveBlueprint() {
    const t = this.args.blueprint;
    return Le(t) ? t : {
      login: this.args.login,
      ...t || {},
      preferredVersions: {
        php: this.args.php ?? t?.preferredVersions?.php ?? D,
        wp: this.args.wp ?? t?.preferredVersions?.wp ?? "latest",
        ...t?.preferredVersions || {}
      }
    };
  }
}
async function Bt(e, t = !0) {
  const o = `${d.basename(process.argv0)}${e}${process.pid}-`, i = await tt({
    prefix: o,
    /*
     * Allow recursive cleanup on process exit.
     *
     * NOTE: I worried about whether this cleanup would follow symlinks
     * and delete target files instead of unlinking the symlink,
     * but this feature uses rimraf under the hood which respects symlinks:
     * https://github.com/raszi/node-tmp/blob/3d2fe387f3f91b13830b9182faa02c3231ea8258/lib/tmp.js#L318
     */
    unsafeCleanup: !0
  });
  return t && rt(), i;
}
async function Dt(e, t, r) {
  const i = (await Rt(
    e,
    t,
    r
  )).map(
    (n) => new Promise((s) => {
      p.rm(n, { recursive: !0 }, (l) => {
        l ? w.warn(
          `Failed to delete stale Playground temp dir: ${n}`,
          l
        ) : w.info(
          `Deleted stale Playground temp dir: ${n}`
        ), s();
      });
    })
  );
  await Promise.all(i);
}
async function Rt(e, t, r) {
  try {
    const o = p.readdirSync(r).map((n) => d.join(r, n)), i = [];
    for (const n of o)
      await Wt(
        e,
        t,
        n
      ) && i.push(n);
    return i;
  } catch (o) {
    return w.warn(`Failed to find stale Playground temp dirs: ${o}`), [];
  }
}
async function Wt(e, t, r) {
  if (!p.lstatSync(r).isDirectory())
    return !1;
  const i = d.basename(r);
  if (!i.includes(e))
    return !1;
  const n = i.match(
    new RegExp(`^(.+)${e}(\\d+)-`)
  );
  if (!n)
    return !1;
  const s = {
    executableName: n[1],
    pid: n[2]
  };
  if (_t(s.pid))
    return !1;
  const l = Date.now() - t;
  return p.statSync(r).mtime.getTime() < l;
}
function _t(e, t) {
  try {
    return process.kill(Number(e), 0), !0;
  } catch (r) {
    const o = r, i = o && typeof o.code == "string" ? o.code : void 0;
    return i === "ESRCH" ? !1 : i === "EPERM" || i === "EACCES" ? (w.debug(
      `Permission denied while checking if process ${e} exists (code: ${i}).`,
      r
    ), !0) : (w.warn(
      `Could not determine if process ${e} exists due to unexpected error${i ? ` (code: ${i})` : ""}.`,
      r
    ), !0);
  }
}
function Lt(e) {
  return process.env.CI === "true" || process.env.CI === "1" || process.env.GITHUB_ACTIONS === "true" || process.env.GITHUB_ACTIONS === "1" || (process.env.TERM || "").toLowerCase() === "dumb" ? !1 : e ? !!e.isTTY : process.stdout.isTTY;
}
class Ut {
  constructor(t) {
    this.lastProgressLine = "", this.progressActive = !1, this.verbosity = t.verbosity, this.writeStream = t.writeStream || process.stdout;
  }
  get isTTY() {
    return !!this.writeStream.isTTY;
  }
  /**
   * Determines if progress updates should be rendered.
   *
   * Returns false when output is piped, redirected, or in CI environments.
   * This prevents progress spam in logs - users only see the final outcome.
   */
  get shouldRender() {
    return Lt(this.writeStream);
  }
  get isQuiet() {
    return this.verbosity === "quiet";
  }
  /**
   * ANSI formatting helpers.
   *
   * These only apply color codes when outputting to a terminal (TTY).
   * When piped to files or non-TTY streams, they return plain text to
   * avoid polluting logs with escape sequences.
   */
  bold(t) {
    return this.isTTY ? `\x1B[1m${t}\x1B[0m` : t;
  }
  dim(t) {
    return this.isTTY ? `\x1B[2m${t}\x1B[0m` : t;
  }
  green(t) {
    return this.isTTY ? `\x1B[32m${t}\x1B[0m` : t;
  }
  cyan(t) {
    return this.isTTY ? `\x1B[36m${t}\x1B[0m` : t;
  }
  yellow(t) {
    return this.isTTY ? `\x1B[33m${t}\x1B[0m` : t;
  }
  red(t) {
    return this.isTTY ? `\x1B[31m${t}\x1B[0m` : t;
  }
  printBanner() {
    if (this.isQuiet) return;
    const t = this.bold("WordPress Playground CLI");
    this.writeStream.write(`
${t}

`);
  }
  /**
   * Prints the configuration summary before starting the server.
   *
   * Displays PHP/WordPress versions, enabled extensions, all mounts
   * (with auto-mounts labeled), and any loaded blueprint. This gives
   * users a clear view of what's configured before the server boots.
   */
  printConfig(t) {
    if (this.isQuiet) return;
    const r = [];
    r.push(
      `${this.dim("PHP")} ${this.cyan(t.phpVersion)}  ${this.dim("WordPress")} ${this.cyan(t.wpVersion)}`
    );
    const o = [];
    if (t.intl && o.push("intl"), t.redis && o.push("redis"), t.memcached && o.push("memcached"), t.xdebug && o.push(this.yellow("xdebug")), o.length > 0 && r.push(`${this.dim("Extensions")} ${o.join(", ")}`), t.mounts.length > 0)
      for (const i of t.mounts) {
        const n = i.autoMounted ? ` ${this.dim("(auto-mount)")}` : "";
        r.push(
          `${this.dim("Mount")} ${i.hostPath} ${this.dim("→")} ${i.vfsPath}${n}`
        );
      }
    t.blueprint && r.push(`${this.dim("Blueprint")} ${t.blueprint}`), this.writeStream.write(r.join(`
`) + `

`);
  }
  /**
   * Starts a progress indicator that updates in-place.
   *
   * Subsequent updateProgress() calls rewrite the same line in TTY mode.
   * When output is piped or redirected, progress is completely skipped.
   */
  startProgress(t) {
    this.isQuiet || this.shouldRender && (this.progressActive = !0, this.updateProgress(t));
  }
  /**
   * Updates the current progress message and optional percentage.
   *
   * Rewrites the current line using ANSI cursor control in TTY mode.
   * Identical messages are skipped to prevent flickering. When piped,
   * this method does nothing (early return via shouldRender check).
   */
  updateProgress(t, r) {
    if (this.isQuiet || !this.shouldRender) return;
    this.progressActive || (this.progressActive = !0);
    let o = `${t}`;
    r !== void 0 && (o = `${t} ${this.dim(`${r}%`)}`), o !== this.lastProgressLine && (this.lastProgressLine = o, this.isTTY ? (this.writeStream.cursorTo(0), this.writeStream.write(o), this.writeStream.clearLine(1)) : this.writeStream.write(`${o}
`));
  }
  /**
   * Completes the progress indicator and moves to a new line.
   *
   * Optionally displays a final message before finishing. In TTY mode,
   * this ensures the cursor moves to the next line after the progress.
   */
  finishProgress(t) {
    this.isQuiet || this.shouldRender && (t && (this.isTTY ? (this.writeStream.cursorTo(0), this.writeStream.write(`${t}`), this.writeStream.clearLine(1)) : this.writeStream.write(`${t}
`)), this.isTTY && this.writeStream.write(`
`), this.progressActive = !1, this.lastProgressLine = "");
  }
  /**
   * Prints a status message, interrupting any active progress.
   *
   * Unlike progress updates, status messages are always printed on their
   * own line. Any active progress indicator is cleared before the message.
   */
  printStatus(t) {
    this.isQuiet || (this.progressActive && this.isTTY && (this.writeStream.cursorTo(0), this.writeStream.clearLine(0)), this.writeStream.write(`${t}
`), this.progressActive = !1, this.lastProgressLine = "");
  }
  /**
   * Prints an error message.
   *
   * Errors are always shown, even in quiet mode, and interrupt any
   * active progress display to ensure visibility.
   */
  printError(t) {
    this.progressActive && this.isTTY && (this.writeStream.cursorTo(0), this.writeStream.clearLine(0), this.progressActive = !1), this.writeStream.write(`${this.red("Error:")} ${t}
`);
  }
  /**
   * Prints the final "server ready" message with the URL.
   *
   * Note: The exact wording "WordPress is running on" is checked by
   * CI tests, so changes to this string will break test assertions.
   */
  printReady(t, r) {
    if (this.isQuiet) return;
    const o = r === 1 ? "worker" : "workers";
    this.writeStream.write(
      `
${this.green("Ready!")} WordPress is running on ${this.bold(t)} ${this.dim(`(${r} ${o})`)}

`
    );
  }
  printWarning(t) {
    this.isQuiet || this.writeStream.write(`${this.yellow("Warning:")} ${t}
`);
  }
  /**
   * Prints the phpMyAdmin URL when the --phpmyadmin flag is enabled.
   */
  printPhpMyAdminUrl(t) {
    this.isQuiet || this.writeStream.write(
      `${this.cyan("phpMyAdmin")} available at ${this.bold(t)}

`
    );
  }
}
const K = {
  Quiet: { name: "quiet", severity: F.Fatal },
  Normal: { name: "normal", severity: F.Info },
  Debug: { name: "debug", severity: F.Debug }
};
async function Ht(e) {
  try {
    const t = {
      "site-url": {
        describe: "Site URL to use for WordPress. Defaults to http://127.0.0.1:{port}",
        type: "string"
      },
      php: {
        describe: "PHP version to use.",
        type: "string",
        default: D,
        choices: U
      },
      wp: {
        describe: "WordPress version to use.",
        type: "string",
        default: "latest"
      },
      define: {
        describe: 'Define PHP string constants (can be used multiple times). Format: NAME value. These constants are set via php.defineConstant() and only exist for the current request. Examples: --define API_KEY secret --define CON=ST "va=lu=e"',
        type: "string",
        nargs: 2,
        array: !0,
        coerce: ft
      },
      "define-bool": {
        describe: 'Define PHP boolean constants (can be used multiple times). Format: NAME value. Value must be "true", "false", "1", or "0". Examples: --define-bool WP_DEBUG true --define-bool MY_FEATURE false',
        type: "string",
        nargs: 2,
        array: !0,
        coerce: ht
      },
      "define-number": {
        describe: "Define PHP number constants (can be used multiple times). Format: NAME value. Examples: --define-number LIMIT 100 --define-number RATE 45.67",
        type: "string",
        nargs: 2,
        array: !0,
        coerce: wt
      },
      // @TODO: Support read-only mounts, e.g. via WORKERFS, a custom
      // ReadOnlyNODEFS, or by copying the files into MEMFS
      mount: {
        describe: "Mount a directory to the PHP runtime (can be used multiple times). Format: /host/path:/vfs/path",
        type: "array",
        string: !0,
        nargs: 1,
        coerce: V
      },
      "mount-before-install": {
        describe: "Mount a directory to the PHP runtime before WordPress installation (can be used multiple times). Format: /host/path:/vfs/path",
        type: "array",
        string: !0,
        nargs: 1,
        coerce: V
      },
      "mount-dir": {
        describe: 'Mount a directory to the PHP runtime (can be used multiple times). Format: "/host/path" "/vfs/path"',
        type: "array",
        nargs: 2,
        array: !0,
        coerce: ce
      },
      "mount-dir-before-install": {
        describe: 'Mount a directory before WordPress installation (can be used multiple times). Format: "/host/path" "/vfs/path"',
        type: "string",
        nargs: 2,
        array: !0,
        coerce: ce
      },
      login: {
        describe: "Should log the user in",
        type: "boolean",
        default: !1
      },
      blueprint: {
        describe: "Blueprint to execute.",
        type: "string"
      },
      "blueprint-may-read-adjacent-files": {
        describe: 'Consent flag: Allow "bundled" resources in a local blueprint to read files in the same directory as the blueprint file.',
        type: "boolean",
        default: !1
      },
      "wordpress-install-mode": {
        describe: "Control how Playground prepares WordPress before booting.",
        type: "string",
        default: "download-and-install",
        choices: [
          "download-and-install",
          "install-from-existing-files",
          "install-from-existing-files-if-needed",
          "do-not-attempt-installing"
        ]
      },
      "skip-wordpress-install": {
        describe: "[Deprecated] Use --wordpress-install-mode instead.",
        type: "boolean",
        hidden: !0
      },
      "skip-sqlite-setup": {
        describe: "Skip the SQLite integration plugin setup to allow the WordPress site to use MySQL.",
        type: "boolean",
        default: !1
      },
      // Hidden - Deprecated in favor of verbosity
      quiet: {
        describe: "Do not output logs and progress messages.",
        type: "boolean",
        default: !1,
        hidden: !0
      },
      verbosity: {
        describe: "Output logs and progress messages.",
        type: "string",
        choices: Object.values(K).map(
          (a) => a.name
        ),
        default: "normal"
      },
      debug: {
        describe: "Print PHP error log content if an error occurs during Playground boot.",
        type: "boolean",
        default: !1,
        // Hide this deprecated option. Use verbosity=debug instead.
        hidden: !0
      },
      "auto-mount": {
        describe: "Automatically mount the specified directory. If no path is provided, mount the current working directory. You can mount a WordPress directory, a plugin directory, a theme directory, a wp-content directory, or any directory containing PHP and HTML files.",
        type: "string"
      },
      "follow-symlinks": {
        describe: `Allow Playground to follow symlinks by automatically mounting symlinked directories and files encountered in mounted directories. 
Warning: Following symlinks will expose files outside mounted directories to Playground and could be a security risk.`,
        type: "boolean",
        default: !1
      },
      "experimental-trace": {
        describe: "Print detailed messages about system behavior to the console. Useful for troubleshooting.",
        type: "boolean",
        default: !1,
        // Hide this option because we want to replace with a more general log-level flag.
        hidden: !0
      },
      "internal-cookie-store": {
        describe: "Enable internal cookie handling. When enabled, Playground will manage cookies internally using an HttpCookieStore that persists cookies across requests. When disabled, cookies are handled externally (e.g., by a browser in Node.js environments).",
        type: "boolean",
        default: !1
      },
      intl: {
        describe: "Enable Intl.",
        type: "boolean",
        default: !0
      },
      redis: {
        describe: "Enable Redis (requires JSPI support).",
        type: "boolean"
        // No default - will be determined at runtime based on JSPI availability
      },
      memcached: {
        describe: "Enable Memcached.",
        type: "boolean"
        // No default - will be determined at runtime based on JSPI availability
      },
      xdebug: {
        describe: "Enable Xdebug.",
        type: "boolean",
        default: !1
      },
      "experimental-unsafe-ide-integration": {
        describe: "Enable experimental IDE development tools. This option edits IDE config files to set Xdebug path mappings and web server details. CAUTION: If there are bugs, this feature may break your IDE config files. Please consider backing up your IDE configs before using this feature.",
        type: "string",
        // The empty value means the option is enabled for all
        // supported IDEs and, if needed, will create the relevant
        // config file for each.
        choices: ["", "vscode", "phpstorm"],
        coerce: (a) => a === "" ? ["vscode", "phpstorm"] : [a]
      },
      "experimental-blueprints-v2-runner": {
        describe: "Use the experimental Blueprint V2 runner.",
        type: "boolean",
        default: !1,
        // Remove the "hidden" flag once Blueprint V2 is fully supported
        hidden: !0
      },
      mode: {
        describe: "Blueprints v2 runner mode to use. This option is required when using the --experimental-blueprints-v2-runner flag with a blueprint.",
        type: "string",
        choices: ["create-new-site", "apply-to-existing-site"],
        // Remove the "hidden" flag once Blueprint V2 is fully supported
        hidden: !0
      },
      phpmyadmin: {
        describe: "Install phpMyAdmin for database management. The phpMyAdmin URL will be printed after boot. Optionally specify a custom URL path (default: /phpmyadmin).",
        type: "string",
        coerce: (a) => a === "" ? "/phpmyadmin" : a
      }
    }, r = {
      port: {
        describe: "Port to listen on when serving. Defaults to 9400 when available.",
        type: "number"
      },
      "experimental-multi-worker": {
        deprecated: "This option is not needed. Multiple workers are always used.",
        describe: "Enable experimental multi-worker support which requires a /wordpress directory backed by a real filesystem. Pass a positive number to specify the number of workers to use. Otherwise, default to the number of CPUs minus 1.",
        type: "number"
      },
      "experimental-devtools": {
        describe: "Enable experimental browser development tools.",
        type: "boolean"
      }
    }, o = {
      path: {
        describe: "Path to the project directory. Playground will auto-detect if this is a plugin, theme, wp-content, or WordPress directory.",
        type: "string",
        default: process.cwd()
      },
      php: {
        describe: "PHP version to use.",
        type: "string",
        default: D,
        choices: U
      },
      wp: {
        describe: "WordPress version to use.",
        type: "string",
        default: "latest"
      },
      port: {
        describe: "Port to listen on. Defaults to 9400 when available.",
        type: "number"
      },
      blueprint: {
        describe: "Path to a Blueprint JSON file to execute on startup.",
        type: "string"
      },
      login: {
        describe: "Auto-login as the admin user.",
        type: "boolean",
        default: !0
      },
      xdebug: {
        describe: "Enable Xdebug for debugging.",
        type: "boolean",
        default: !1
      },
      "experimental-unsafe-ide-integration": t["experimental-unsafe-ide-integration"],
      "skip-browser": {
        describe: "Do not open the site in your default browser on startup.",
        type: "boolean",
        default: !1
      },
      quiet: {
        describe: "Suppress non-essential output.",
        type: "boolean",
        default: !1
      },
      // Advanced options for power users who need more control
      "site-url": {
        describe: "Override the site URL. By default, derived from the port (http://127.0.0.1:<port>).",
        type: "string"
      },
      mount: {
        describe: "Mount a directory to the PHP runtime (can be used multiple times). Format: /host/path:/vfs/path. Use this for additional mounts beyond auto-detection.",
        type: "array",
        string: !0,
        coerce: V
      },
      reset: {
        describe: "Deletes the stored site directory and starts a new site from scratch.",
        type: "boolean",
        default: !1
      },
      "no-auto-mount": {
        describe: "Disable automatic project type detection. Use --mount to manually specify mounts instead.",
        type: "boolean",
        default: !1
      },
      // Define constants
      define: t.define,
      "define-bool": t["define-bool"],
      "define-number": t["define-number"],
      // Tools
      phpmyadmin: t.phpmyadmin
    }, i = {
      outfile: {
        describe: "When building, write to this output file.",
        type: "string",
        default: "wordpress.zip"
      }
    }, n = Ye(e).usage("Usage: wp-playground <command> [options]").command(
      "start",
      "Start a local WordPress server with automatic project detection (recommended)",
      (a) => a.usage(
        `Usage: wp-playground start [options]

The easiest way to run WordPress locally. Automatically detects
if your directory contains a plugin, theme, wp-content, or
WordPress installation and configures everything for you.

Examples:
  wp-playground start                    # Start in current directory
  wp-playground start --path=./my-plugin # Start with a specific path
  wp-playground start --wp=6.7 --php=8.3 # Use specific versions
  wp-playground start --skip-browser     # Skip opening browser
  wp-playground start --no-auto-mount    # Disable auto-detection`
      ).options(o)
    ).command(
      "server",
      "Start a local WordPress server (advanced, low-level)",
      (a) => a.options({
        ...t,
        ...r
      })
    ).command(
      "run-blueprint",
      "Execute a Blueprint without starting a server",
      (a) => a.options({ ...t })
    ).command(
      "build-snapshot",
      "Build a ZIP snapshot of a WordPress site based on a Blueprint",
      (a) => a.options({
        ...t,
        ...i
      })
    ).command(
      "php",
      "Run a PHP script",
      (a) => a.options({ ...t })
    ).demandCommand(1, "Please specify a command").strictCommands().conflicts(
      "experimental-unsafe-ide-integration",
      "experimental-devtools"
    ).showHelpOnFail(!1).fail((a, T, E) => {
      if (T)
        throw T;
      a && a.includes("Please specify a command") && (E.showHelp(), console.error(`
` + a), process.exit(1)), console.error(a), process.exit(1);
    }).strictOptions().check(async (a) => {
      if (a["skip-wordpress-install"] === !0 && (a["wordpress-install-mode"] = "do-not-attempt-installing", a.wordpressInstallMode = "do-not-attempt-installing"), a.wp !== void 0 && typeof a.wp == "string" && !$t(a.wp))
        try {
          new URL(a.wp);
        } catch {
          throw new Error(
            'Unrecognized WordPress version. Please use "latest", "beta", "trunk", "nightly", a URL, or a numeric version such as "6.2", "6.0.1", "6.2-beta1", or "6.2-RC1" (see --help for details).'
          );
        }
      const T = a["site-url"];
      if (typeof T == "string" && T.trim() !== "")
        try {
          new URL(T);
        } catch {
          throw new Error(
            `Invalid site-url "${T}". Please provide a valid URL (e.g., http://localhost:8080 or https://example.com)`
          );
        }
      if (a["auto-mount"]) {
        let E = !1;
        try {
          E = p.statSync(
            a["auto-mount"]
          ).isDirectory();
        } catch {
          E = !1;
        }
        if (!E)
          throw new Error(
            `The specified --auto-mount path is not a directory: '${a["auto-mount"]}'.`
          );
      }
      if (a["experimental-blueprints-v2-runner"] === !0)
        throw new Error(
          "Blueprints v2 are temporarily disabled while we rework their runtime implementation."
        );
      if (a.mode !== void 0)
        throw new Error(
          "The --mode option requires the --experimentalBlueprintsV2Runner flag."
        );
      return !0;
    });
    n.wrap(n.terminalWidth());
    const s = await n.argv, l = s._[0];
    [
      "start",
      "run-blueprint",
      "server",
      "build-snapshot",
      "php"
    ].includes(l) || (n.showHelp(), process.exit(1));
    const u = s.define || {}, h = s["define-bool"] || {}, M = s["define-number"] || {}, c = (a) => a in u || a in h || a in M;
    c("WP_DEBUG") || (u.WP_DEBUG = "true"), c("WP_DEBUG_LOG") || (u.WP_DEBUG_LOG = "true"), c("WP_DEBUG_DISPLAY") || (u.WP_DEBUG_DISPLAY = "false");
    const S = {
      ...s,
      define: u,
      command: l,
      mount: [
        ...s.mount || [],
        ...s["mount-dir"] || []
      ],
      "mount-before-install": [
        ...s["mount-before-install"] || [],
        ...s["mount-dir-before-install"] || []
      ]
    }, b = await xe(S);
    b === void 0 && process.exit(0);
    const x = /* @__PURE__ */ (() => {
      let a;
      return async () => {
        a === void 0 && (a = b[Symbol.asyncDispose]()), await a, process.exit(0);
      };
    })();
    return process.on("SIGINT", x), process.on("SIGTERM", x), {
      [Symbol.asyncDispose]: async () => {
        process.off("SIGINT", x), process.off("SIGTERM", x), await b[Symbol.asyncDispose]();
      },
      [ee]: { cliServer: b }
    };
  } catch (t) {
    console.error(t);
    const r = process.argv.includes("--debug");
    if (t instanceof Error)
      if (r)
        Me(t);
      else {
        const o = [];
        let i = t;
        do
          o.push(i.message), i = i.cause;
        while (i instanceof Error);
        console.error(
          "\x1B[1m" + o.join(" caused by: ") + "\x1B[0m"
        );
      }
    else
      console.error("\x1B[1m" + Se(t) + "\x1B[0m");
    process.exit(1);
  }
}
function Se(e) {
  if (e instanceof Error)
    return e.message;
  if (e && typeof e == "object") {
    const t = [], r = e;
    if (r.name && t.push(String(r.name)), r.message && t.push(String(r.message)), r.errno !== void 0 && t.push(`errno: ${r.errno}`), t.length > 0)
      return t.join(" — ");
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  }
  return String(e);
}
function me(e, t) {
  return e.find(
    (r) => r.vfsPath.replace(/\/$/, "") === t.replace(/\/$/, "")
  );
}
const ee = Symbol("playground-cli-testing"), C = (e) => process.stdout.isTTY ? "\x1B[1m" + e + "\x1B[0m" : e, Nt = (e) => process.stdout.isTTY ? "\x1B[31m" + e + "\x1B[0m" : e, fe = (e) => process.stdout.isTTY ? `\x1B[2m${e}\x1B[0m` : e, _ = (e) => process.stdout.isTTY ? `\x1B[3m${e}\x1B[0m` : e, Y = (e) => process.stdout.isTTY ? `\x1B[33m${e}\x1B[0m` : e;
async function xe(e) {
  let t;
  const r = e.internalCookieStore ? new Ce() : void 0, o = [], i = /* @__PURE__ */ new Map();
  if (e.command === "start" && (e = Ot(e)), e.autoMount !== void 0 && (e.autoMount === "" && (e = { ...e, autoMount: process.cwd() }), e = Pe(e)), e.wordpressInstallMode === void 0 && (e.wordpressInstallMode = "download-and-install"), e.quiet && (e.verbosity = "quiet", delete e.quiet), e.debug && (e.verbosity = "debug", delete e.debug), e.verbosity) {
    const c = Object.values(K).find(
      (S) => S.name === e.verbosity
    ).severity;
    w.setSeverityFilterLevel(c);
  }
  e.intl || (e.intl = !0), e.redis === void 0 && (e.redis = await de()), e.memcached === void 0 && (e.memcached = await de()), e.phpmyadmin && (e.phpmyadmin === !0 && (e.phpmyadmin = "/phpmyadmin"), e.pathAliases = [
    {
      urlPrefix: e.phpmyadmin,
      fsPath: ue
    }
  ]);
  const n = new Ut({
    verbosity: e.verbosity || "normal"
  });
  e.command === "server" && (n.printBanner(), n.printConfig({
    phpVersion: e.php || D,
    wpVersion: e.wp || "latest",
    port: e.port ?? 9400,
    xdebug: !!e.xdebug,
    intl: !!e.intl,
    redis: !!e.redis,
    memcached: !!e.memcached,
    mounts: [
      ...e.mount || [],
      ...e["mount-before-install"] || []
    ],
    blueprint: typeof e.blueprint == "string" ? e.blueprint : void 0
  }));
  const s = e.command === "server" ? e.port ?? 9400 : 0, l = new Ae();
  let u = !1, h = !0;
  const M = await Pt({
    port: e.port ? e.port : await gt(s) ? 0 : s,
    onBind: async (c, S) => {
      const b = "127.0.0.1", x = `http://${b}:${S}`, a = e["site-url"] || x, T = 6, E = "-playground-cli-site-", I = await Bt(E);
      w.debug(`Native temp dir for VFS root: ${I.path}`);
      const R = "WP Playground CLI - Listen for Xdebug", te = ".playground-xdebug-root", H = d.join(process.cwd(), te);
      if (await ot(H), e.xdebug) {
        const m = {
          hostPath: d.join(".", d.sep, te),
          vfsPath: "/"
        };
        if (U.indexOf(
          e.php || D
        ) <= U.indexOf("8.5"))
          await ae(
            I.path,
            H,
            process.platform
          ), e.xdebug = it({
            cwd: process.cwd(),
            mounts: [
              m,
              ...e["mount-before-install"] || [],
              ...e.mount || []
            ],
            pathSkippings: [...le]
          }), console.log(C("Xdebug configured successfully")), console.log(
            Y("Playground source root: ") + ".playground-xdebug-root" + _(
              fe(
                " – you can set breakpoints and preview Playground's VFS structure in there."
              )
            )
          );
        else if (e.experimentalUnsafeIdeIntegration) {
          await ae(
            I.path,
            H,
            process.platform
          );
          try {
            await nt(
              R,
              process.cwd()
            );
            const f = typeof e.xdebug == "object" ? e.xdebug : {}, g = await st({
              name: R,
              host: b,
              port: S,
              ides: e.experimentalUnsafeIdeIntegration,
              cwd: process.cwd(),
              mounts: [
                m,
                ...e["mount-before-install"] || [],
                ...e.mount || []
              ],
              pathSkippings: [...le],
              ideKey: f.ideKey || "WPPLAYGROUNDCLI"
            }), $ = e.experimentalUnsafeIdeIntegration, y = $.includes("vscode"), P = $.includes("phpstorm"), W = Object.values(g);
            console.log(""), W.length > 0 ? (console.log(
              C("Xdebug configured successfully")
            ), console.log(
              Y("Updated IDE config: ") + W.join(" ")
            ), console.log(
              Y("Playground source root: ") + ".playground-xdebug-root" + _(
                fe(
                  " – you can set breakpoints and preview Playground's VFS structure in there."
                )
              )
            )) : (console.log(
              C("Xdebug configuration failed.")
            ), console.log(
              "No IDE-specific project settings directory was found in the current working directory."
            )), console.log(""), y && g.vscode && (console.log(
              C("VS Code / Cursor instructions:")
            ), console.log(
              "  1. Ensure you have installed an IDE extension for PHP Debugging"
            ), console.log(
              `     (The ${C("PHP Debug")} extension by ${C(
                "Xdebug"
              )} has been a solid option)`
            ), console.log(
              "  2. Open the Run and Debug panel on the left sidebar"
            ), console.log(
              `  3. Select "${_(
                R
              )}" from the dropdown`
            ), console.log('  3. Click "start debugging"'), console.log(
              "  5. Set a breakpoint. For example, in .playground-xdebug-root/wordpress/index.php"
            ), console.log(
              "  6. Visit Playground in your browser to hit the breakpoint"
            ), P && console.log("")), P && g.phpstorm && (console.log(C("PhpStorm instructions:")), console.log(
              `  1. Choose "${_(
                R
              )}" debug configuration in the toolbar`
            ), console.log(
              "  2. Click the debug button (bug icon)`"
            ), console.log(
              "  3. Set a breakpoint. For example, in .playground-xdebug-root/wordpress/index.php"
            ), console.log(
              "  4. Visit Playground in your browser to hit the breakpoint"
            )), console.log("");
          } catch (f) {
            throw new Error("Could not configure Xdebug", {
              cause: f
            });
          }
        }
      }
      const $e = d.dirname(I.path), Te = 2 * 24 * 60 * 60 * 1e3;
      Dt(
        E,
        Te,
        $e
      );
      const re = d.join(I.path, "internal");
      z(re);
      const Ie = [
        "wordpress",
        "tools",
        // Note: These dirs are from Emscripten's "default dirs" list:
        // https://github.com/emscripten-core/emscripten/blob/f431ec220e472e1f8d3db6b52fe23fb377facf30/src/lib/libfs.js#L1400-L1402
        //
        // Any Playground process with multiple workers may assume
        // these are part of a shared filesystem, so let's recognize
        // them explicitly here.
        "tmp",
        "home"
      ];
      for (const m of Ie) {
        const v = (g) => g.vfsPath === `/${m}`;
        if (!(e["mount-before-install"]?.some(v) || e.mount?.some(v))) {
          const g = d.join(
            I.path,
            m
          );
          z(g), e["mount-before-install"] === void 0 && (e["mount-before-install"] = []), e["mount-before-install"].unshift({
            vfsPath: `/${m}`,
            hostPath: g
          });
        }
      }
      if (e["mount-before-install"])
        for (const m of e["mount-before-install"])
          w.debug(
            `Mount before WP install: ${m.vfsPath} -> ${m.hostPath}`
          );
      if (e.mount)
        for (const m of e.mount)
          w.debug(
            `Mount after WP install: ${m.vfsPath} -> ${m.hostPath}`
          );
      let A;
      e["experimental-blueprints-v2-runner"] ? A = new It(e, {
        siteUrl: a,
        cliOutput: n
      }) : (A = new At(e, {
        siteUrl: a,
        cliOutput: n
      }), typeof e.blueprint == "string" && (e.blueprint = await Tt({
        sourceString: e.blueprint,
        blueprintMayReadAdjacentFiles: e["blueprint-may-read-adjacent-files"] === !0
      })));
      let N = !1;
      const B = async function() {
        N || (N = !0, await Promise.all(
          o.map(async (v) => {
            await i.get(v)?.dispose(), await v.worker.terminate();
          })
        ), c && await new Promise((v) => {
          c.close(v), c.closeAllConnections();
        }), await I.cleanup());
      };
      try {
        const m = [], v = A.getWorkerType();
        for (let f = 0; f < T; f++) {
          const g = Ee(v, {
            onExit: ($) => {
              if (!N && $ !== 0 && (w.error(
                `Worker ${f} exited with code ${$}
`
              ), t)) {
                const y = o[f];
                if (y) {
                  const P = i.get(y);
                  P && (t.__removeInstance(
                    P
                  ), w.error(
                    `Worker ${f} removed from pool
`
                  ));
                }
              }
            }
          }).then(
            async ($) => {
              o.push($);
              const y = await Ft(l), P = await A.bootRequestHandler({
                worker: $,
                fileLockManagerPort: y,
                nativeInternalDirPath: re
              });
              return i.set(
                $,
                P
              ), [$, P];
            }
          );
          m.push(g), f === 0 && await g;
        }
        await Promise.all(m), t = Be(
          o.map(
            (f) => i.get(f)
          )
        );
        {
          const f = new ye(), g = f.port1, $ = f.port2;
          if (await De(
            {
              applyPostInstallMountsToAllWorkers: async () => {
                for (const y of i.values())
                  await y.mountAfterWordPressInstall(
                    e.mount || []
                  );
              }
            },
            void 0,
            g
          ), await A.bootWordPress(
            t,
            $
          ), g.close(), u = !0, !e["experimental-blueprints-v2-runner"]) {
            const y = await A.compileInputBlueprint(
              e["additional-blueprint-steps"] || []
            );
            y && await ne(
              y,
              t
            );
          }
          if (e.phpmyadmin && !await t.fileExists(
            `${ue}/index.php`
          )) {
            const y = await lt(), P = await we({ steps: y });
            await ne(P, t);
          }
          if (e.command === "build-snapshot") {
            await Vt(t, e.outfile), n.printStatus(`Exported to ${e.outfile}`), await B();
            return;
          } else if (e.command === "run-blueprint") {
            n.finishProgress("Done"), await B();
            return;
          } else if (e.command === "php") {
            const y = [
              // @TODO: Import this from somewhere?
              // Hardcoding it feels fragile.
              "/internal/shared/bin/php",
              ...(e._ || []).slice(1)
            ], P = await t.cli(y), [W] = await Promise.all([
              P.exitCode,
              P.stdout.pipeTo(
                new WritableStream({
                  write(O) {
                    process.stdout.write(O);
                  }
                })
              ),
              P.stderr.pipeTo(
                new WritableStream({
                  write(O) {
                    process.stderr.write(O);
                  }
                })
              )
            ]);
            await B(), process.exit(W);
          }
        }
        if (n.finishProgress(), n.printReady(x, T), e.phpmyadmin) {
          const f = d.join(
            e.phpmyadmin,
            ut
          );
          n.printPhpMyAdminUrl(
            new URL(f, x).toString()
          );
        }
        return e.xdebug && e.experimentalDevtools && (await et({
          phpInstance: t,
          phpRoot: "/wordpress"
        })).start(), {
          playground: t,
          server: c,
          serverUrl: x,
          [Symbol.asyncDispose]: B,
          [ee]: {
            workerThreadCount: T
          }
        };
      } catch (m) {
        if (e.verbosity !== "debug")
          throw m;
        let v = "";
        throw await t?.fileExists(oe) && (v = await t.readFileAsText(oe)), await B(), new Error(v, { cause: m });
      }
    },
    async handleRequest(c, S) {
      if (!u) {
        await S(
          j.forHttpCode(
            502,
            "WordPress is not ready yet"
          )
        );
        return;
      }
      if (h) {
        h = !1;
        const x = {
          "Content-Type": ["text/plain"],
          "Content-Length": ["0"],
          Location: [c.url]
        };
        c.headers?.cookie?.includes(
          "playground_auto_login_already_happened"
        ) && (x["Set-Cookie"] = [
          "playground_auto_login_already_happened=1; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/"
        ]), await S(
          j.fromPHPResponse(
            new Re(302, x, new Uint8Array())
          )
        );
        return;
      }
      r && (c = {
        ...c,
        headers: {
          ...c.headers,
          // While we have an internal cookie store, we
          // completely replace the incoming request's Cookie
          // header with the cookies from our store. This avoids
          // getting into a strange state where both browser and
          // server are managing cookies.
          cookie: r.getCookieRequestHeader()
        }
      });
      const b = await t.request(c);
      r && (r.rememberCookiesFromResponseHeaders(
        b.headers
      ), delete b.headers["set-cookie"]), await S(j.fromPHPResponse(b));
    }
  }).catch((c) => {
    n.printError(Se(c)), process.exit(1);
  });
  return M && e.command === "start" && !e.skipBrowser && jt(M.serverUrl), M;
}
function Ot(e) {
  let t = { ...e, command: "server" };
  e.noAutoMount || (t.autoMount = d.resolve(process.cwd(), t.path ?? ""), t = Pe(t), delete t.autoMount);
  const r = me(
    t["mount-before-install"] || [],
    "/wordpress"
  ) || me(t.mount || [], "/wordpress");
  if (r)
    console.log("Site files stored at:", r?.hostPath), e.reset && (console.log(""), console.log(
      Nt(
        "This site is not managed by Playground CLI and cannot be reset."
      )
    ), console.log(
      "(It's not stored in the ~/.wordpress-playground/sites/<site-id> directory.)"
    ), console.log(""), console.log(
      "You may still remove the site's directory manually if you wish."
    ), process.exit(1));
  else {
    const o = t.autoMount || process.cwd(), i = at("sha256").update(o).digest("hex"), n = Z.homedir(), s = d.join(
      n,
      ".wordpress-playground/sites",
      i
    );
    console.log("Site files stored at:", s), Q(s) && e.reset && (console.log("Resetting site..."), He(s, { recursive: !0 })), z(s, { recursive: !0 }), t["mount-before-install"] = [
      ...t["mount-before-install"] || [],
      { vfsPath: "/wordpress", hostPath: s }
    ], t.wordpressInstallMode = Ne(s).length === 0 ? (
      // Only download WordPress on the first run when the site directory is still
      // empty.
      "download-and-install"
    ) : (
      // After that, reuse the WordPress installation from the initial run.
      "install-from-existing-files-if-needed"
    );
  }
  return t;
}
const q = new ke();
function Ee(e, { onExit: t } = {}) {
  let r;
  return e === "v1" ? r = new se(new URL("./worker-thread-v1.js", import.meta.url)) : r = new se(new URL("./worker-thread-v2.js", import.meta.url)), new Promise((o, i) => {
    const n = q.claim();
    r.once("message", function(l) {
      l.command === "worker-script-initialized" && o({
        processId: n,
        worker: r,
        phpPort: l.phpPort
      });
    }), r.once("error", function(l) {
      q.release(n), console.error(l);
      const u = l?.message || (l ? String(l) : "unknown error"), h = new Error(
        `Worker failed to load. Original error: ${u}`,
        { cause: l }
      );
      i(h);
    });
    let s = !1;
    r.once("spawn", () => {
      s = !0;
    }), r.once("exit", (l) => {
      q.release(n), s || i(new Error(`Worker exited before spawning: ${l}`)), t?.(l);
    });
  });
}
async function Ft(e) {
  const { port1: t, port2: r } = new ye();
  return await We(e, t), r;
}
function jt(e) {
  const t = Z.platform();
  let r;
  switch (t) {
    case "darwin":
      r = `open "${e}"`;
      break;
    case "win32":
      r = `start "" "${e}"`;
      break;
    default:
      r = `xdg-open "${e}"`;
      break;
  }
  be(r, (o) => {
    o && w.debug(`Could not open browser: ${o.message}`);
  });
}
async function Vt(e, t) {
  await e.run({
    code: `<?php
		$zip = new ZipArchive();
		if(false === $zip->open('/tmp/build.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
			throw new Exception('Failed to create ZIP');
		}
		$files = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator('/wordpress')
		);
		foreach ($files as $file) {
			echo $file . PHP_EOL;
			if (!$file->isFile()) {
				continue;
			}
			$zip->addFile($file->getPathname(), $file->getPathname());
		}
		$zip->close();

	`
  });
  const r = await e.readFileAsBuffer("/tmp/build.zip");
  p.writeFileSync(t, r);
}
const gr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LogVerbosity: K,
  internalsKeyForTesting: ee,
  mergeDefinedConstants: J,
  parseOptionsAndRunCLI: Ht,
  runCLI: xe,
  spawnWorkerThread: Ee
}, Symbol.toStringTag, { value: "Module" }));
export {
  K as L,
  br as a,
  Lt as b,
  gr as c,
  ee as i,
  J as m,
  Ht as p,
  xe as r,
  Ee as s
};
//# sourceMappingURL=run-cli-DWkUdARs.js.map
