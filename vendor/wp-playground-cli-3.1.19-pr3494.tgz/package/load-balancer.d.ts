import type { PHPRequest, PHPResponse } from '@php-wasm/universal';
export interface LoadBalancerWorker {
    request(request: PHPRequest): Promise<PHPResponse>;
}
type InProgressRequest = {
    request: PHPRequest;
    promisedResponse: Promise<PHPResponse>;
};
type QueuedRequest = {
    request: PHPRequest;
    resolve: (response: PHPResponse | PromiseLike<PHPResponse>) => void;
    reject: (reason?: any) => void;
};
export declare class LoadBalancer {
    workers: LoadBalancerWorker[];
    freeWorkers: LoadBalancerWorker[];
    busyWorkers: Map<LoadBalancerWorker, InProgressRequest>;
    queuedRequests: QueuedRequest[];
    constructor(workers: LoadBalancerWorker[]);
    handleRequest(request: PHPRequest): Promise<PHPResponse>;
    private dispatchQueuedRequests;
}
export {};
