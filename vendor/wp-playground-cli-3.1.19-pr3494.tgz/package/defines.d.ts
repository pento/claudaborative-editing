/**
 * Parse an array of constant name-value pairs into a constants object.
 * Works similarly to parseMountDirArguments - each pair of array elements
 * represents a constant name and its value.
 *
 * Format: --define NAME value
 * Examples:
 *     --define API_KEY secret
 *     --define CON=ST "va=lu=e"
 *
 * @param defines - An array where each pair is [name, value]
 * @returns An object mapping constant names to their string values
 */
export declare function parseDefineStringArguments(defines: string[]): Record<string, string>;
/**
 * Parse an array of constant name-value pairs into a boolean constants object.
 * Works similarly to parseMountDirArguments - each pair of array elements
 * represents a constant name and its value.
 *
 * Format: --define-bool NAME value
 * Examples:
 *     --define-bool WP_DEBUG true
 *     --define-bool WP_DEBUG_LOG false
 *
 * @param defines - An array where each pair is [name, value]
 * @returns An object mapping constant names to their boolean values
 */
export declare function parseDefineBoolArguments(defines: string[]): Record<string, boolean>;
/**
 * Parse an array of constant name-value pairs into a number constants object.
 * Works similarly to parseMountDirArguments - each pair of array elements
 * represents a constant name and its value.
 *
 * Format: --define-number NAME value
 * Examples:
 *     --define-number LIMIT 100
 *     --define-number RATE 45.67
 *
 * @param defines - An array where each pair is [name, value]
 * @returns An object mapping constant names to their numeric values
 */
export declare function parseDefineNumberArguments(defines: string[]): Record<string, number>;
/**
 * Merge all constants from CLI arguments.
 *
 * @param args - CLI arguments
 * @returns Merged constants
 */
export declare function mergeDefinedConstants(args: {
    define?: Record<string, string>;
    'define-bool'?: Record<string, boolean>;
    'define-number'?: Record<string, number>;
}): Record<string, string | number | boolean>;
