import { loadNodeRuntime as P } from "@php-wasm/node";
import { EmscriptenDownloadMonitor as w } from "@php-wasm/progress";
import { exposeAPI as f, PHPWorker as y, consumeAPISync as g, consumeAPI as h, releaseApiProxy as I, sandboxedSpawnHandlerFactory as b } from "@php-wasm/universal";
import { sprintf as W } from "@php-wasm/util";
import { RecommendedPHPVersion as H } from "@wp-playground/common";
import { bootWordPress as R, bootRequestHandler as k } from "@wp-playground/wordpress";
import { rootCertificates as q } from "tls";
import { MessageChannel as A, parentPort as M } from "worker_threads";
import { a as n, s as _ } from "./run-cli-DWkUdARs.js";
import { logger as v } from "@php-wasm/logger";
function S(t, e, ...r) {
  console.log(
    performance.now().toFixed(6).padStart(15, "0"),
    t.toString().padStart(16, "0"),
    W(e, ...r)
  );
}
class F extends y {
  constructor(e) {
    super(void 0, e), this.bootedRequestHandler = !1, this.bootedWordPress = !1;
  }
  /**
   * Call this method before boot() to use file locking.
   *
   * This method is separate from boot() to simplify the related Comlink.transferHandlers
   * setup – if an argument is a MessagePort, we're transferring it, not copying it.
   *
   * @see comlink-sync.ts
   * @see phpwasm-emscripten-library-file-locking-for-node.js
   */
  async useFileLockManager(e) {
    this.fileLockManager = await g(e);
  }
  async bootWordPress(e, r) {
    if (this.bootedWordPress)
      throw new Error("WordPress already booted");
    this.bootedWordPress = !0;
    const {
      siteUrl: a,
      wordpressInstallMode: o,
      wordPressZip: l,
      sqliteIntegrationPluginZip: d,
      dataSqlPath: m,
      constants: u
    } = e;
    try {
      await R(this.__internal_getRequestHandler(), {
        siteUrl: a,
        wordpressInstallMode: o,
        wordPressZip: l !== void 0 ? new File([l], "wordpress.zip") : void 0,
        sqliteIntegrationPluginZip: d !== void 0 ? new File(
          [d],
          "sqlite-integration-plugin.zip"
        ) : void 0,
        // TODO: Are these redundant creations?
        createFiles: {
          "/internal/shared/ca-bundle.crt": q.join(`
`)
        },
        phpIniEntries: {
          "openssl.cafile": "/internal/shared/ca-bundle.crt",
          allow_url_fopen: "1",
          disable_functions: ""
        },
        dataSqlPath: m,
        constants: u
      });
      const s = h(r);
      await s.applyPostInstallMountsToAllWorkers(), s[I](), c();
    } catch (s) {
      throw p(s), s;
    }
  }
  async bootRequestHandler(e) {
    if (this.bootedRequestHandler)
      throw new Error("Playground already booted");
    this.bootedRequestHandler = !0;
    try {
      const r = await k({
        siteUrl: e.siteUrl,
        maxPhpInstances: 1,
        createPhpRuntime: x(
          e,
          this.fileLockManager
        ),
        onPHPInstanceCreated: async (o) => {
          await n(o, e.mountsBeforeWpInstall), this.bootedWordPress && await n(o, e.mountsAfterWpInstall);
        },
        sapiName: "cli",
        cookieStore: !1,
        pathAliases: e.pathAliases,
        spawnHandler: () => b(() => {
          let o = e;
          return this.bootedWordPress || (o = {
            ...e,
            mountsAfterWpInstall: []
          }), C(
            o,
            this.fileLockManager
          );
        })
      });
      this.__internal_setRequestHandler(r);
      const a = await r.getPrimaryPhp();
      await this.setPrimaryPHP(a), c();
    } catch (r) {
      throw p(r), r;
    }
  }
  async mountAfterWordPressInstall(e) {
    this.bootedWordPress = !0, await n(this.__internal_getPHP(), e);
  }
  // Provide a named disposal method that can be invoked via comlink.
  async dispose() {
    await this[Symbol.asyncDispose]();
  }
}
function x(t, e) {
  return async () => await P(
    t.phpVersion || H,
    {
      fileLockManager: e,
      emscriptenOptions: {
        processId: t.processId,
        trace: t.trace ? S : void 0,
        nativeInternalDirPath: t.nativeInternalDirPath
      },
      followSymlinks: t.followSymlinks,
      withIntl: t.withIntl,
      withRedis: t.withRedis,
      withMemcached: t.withMemcached,
      withXdebug: t.withXdebug
    }
  );
}
async function C(t, e) {
  const r = await _("v1"), a = h(
    r.phpPort
  );
  return a.useFileLockManager(e), await a.bootRequestHandler({
    ...t,
    processId: r.processId
  }), {
    php: a,
    reap: () => {
      try {
        a.dispose();
      } catch {
      }
      try {
        r.worker.terminate();
      } catch {
      }
    }
  };
}
process.on("unhandledRejection", (t) => {
  v.error("Unhandled rejection:", t);
});
const i = new A(), [c, p] = f(
  new F(new w()),
  void 0,
  i.port1
);
M?.postMessage(
  {
    command: "worker-script-initialized",
    phpPort: i.port2
  },
  [i.port2]
);
export {
  F as PlaygroundCliBlueprintV1Worker
};
//# sourceMappingURL=worker-thread-v1.js.map
