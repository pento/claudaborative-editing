import type { PHP } from '@php-wasm/universal';
import type { RunCLIArgs } from './run-cli';
import type { Mount } from '@php-wasm/cli-util';
/**
 * Parse an array of mount argument strings where the host path and VFS path
 * are separated by a colon.
 *
 * Example:
 *     parseMountWithDelimiterArguments( [ '/host/path:/vfs/path', '/host/path:/vfs/path' ] )
 *     // returns:
 *     [
 *         { hostPath: '/host/path', vfsPath: '/vfs/path' },
 *         { hostPath: '/host/path', vfsPath: '/vfs/path' }
 *     ]
 *
 * @param mounts - An array of mount argument strings separated by a colon.
 * @returns An array of Mount objects.
 */
export declare function parseMountWithDelimiterArguments(mounts: string[]): Mount[];
/**
 * Parse an array of mount argument strings where each odd array element is a host path
 * and each even element is the VFS path.
 * e.g. [ '/host/path', '/vfs/path', '/host/path2', '/vfs/path2' ]
 *
 * The result will be an array of Mount objects for each host path the
 * following element is it's VFS path.
 * e.g. [
 *   { hostPath: '/host/path', vfsPath: '/vfs/path' },
 *   { hostPath: '/host/path2', vfsPath: '/vfs/path2' }
 * ]
 *
 * @param mounts - An array of paths
 * @returns An array of Mount objects.
 */
export declare function parseMountDirArguments(mounts: string[]): Mount[];
export declare function mountResources(php: PHP, mounts: Mount[]): Promise<void>;
/**
 * Auto-mounts resolution logic:
 */
export declare function expandAutoMounts(args: RunCLIArgs): RunCLIArgs;
export declare function containsFullWordPressInstallation(path: string): boolean;
export declare function containsWpContentDirectories(path: string): boolean;
export declare function isThemeDirectory(path: string): boolean;
export declare function isPluginDirectory(path: string): boolean;
