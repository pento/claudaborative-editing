export declare function shouldRenderProgress(writeStream?: {
    isTTY?: boolean;
} | null): boolean;
