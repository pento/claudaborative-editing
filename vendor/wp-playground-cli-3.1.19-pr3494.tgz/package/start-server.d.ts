/// <reference types="node" />
import type { PHPRequest, StreamedPHPResponse } from '@php-wasm/universal';
import type { Server } from 'http';
import type { RunCLIServer } from './run-cli';
export interface ServerOptions {
    port: number;
    onBind: (server: Server, port: number) => Promise<RunCLIServer | void>;
    /**
     * Handler for requests. Receives the PHP request and a callback that
     * streams the response to the HTTP client. The handler must not resolve
     * until the response is fully streamed — this is critical for pool-based
     * concurrency control where the worker must be held for the entire
     * request lifecycle.
     */
    handleRequest: (request: PHPRequest, streamResponse: (response: StreamedPHPResponse) => Promise<void>) => Promise<void>;
}
export declare function isPortInUse(port: number): Promise<boolean>;
export declare function startServer(options: ServerOptions): Promise<RunCLIServer | void>;
