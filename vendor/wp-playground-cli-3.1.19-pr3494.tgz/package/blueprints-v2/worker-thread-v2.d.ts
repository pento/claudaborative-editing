/// <reference types="node" />
import type { FileLockManager } from '@php-wasm/universal';
import { EmscriptenDownloadMonitor } from '@php-wasm/progress';
import type { PathAlias, PHP, FileTree, SupportedPHPVersion, SpawnHandler } from '@php-wasm/universal';
import { PHPWorker } from '@php-wasm/universal';
import { type BlueprintV1Declaration } from '@wp-playground/blueprints';
import { type ParsedBlueprintV2String, type RawBlueprintV2Data } from '@wp-playground/blueprints';
import { type MessagePort } from 'worker_threads';
import { type RunCLIArgs } from '../run-cli';
import type { PhpIniOptions, PHPInstanceCreatedHook } from '@wp-playground/wordpress';
import type { Mount } from '@php-wasm/cli-util';
export type WorkerWordPressBootArgs = Omit<RunCLIArgs, 'mount-before-install' | 'mount'> & {
    siteUrl: string;
    blueprint: RawBlueprintV2Data | ParsedBlueprintV2String | BlueprintV1Declaration;
};
type WorkerRunBlueprintArgs = Omit<RunCLIArgs, 'mount-before-install' | 'mount'> & {
    siteUrl: string;
    blueprint: RawBlueprintV2Data | ParsedBlueprintV2String | BlueprintV1Declaration;
    mountsAfterWpInstall?: Array<Mount>;
};
export type SecondaryWorkerBootArgs = {
    siteUrl: string;
    allow?: string;
    phpVersion: SupportedPHPVersion;
    phpIniEntries?: PhpIniOptions;
    constants?: Record<string, string | number | boolean | null>;
    createFiles?: FileTree;
    processId: number;
    trace: boolean;
    nativeInternalDirPath: string;
    withIntl?: boolean;
    withRedis?: boolean;
    withMemcached?: boolean;
    withXdebug?: boolean;
    pathAliases?: PathAlias[];
    mountsBeforeWpInstall?: Array<Mount>;
    mountsAfterWpInstall?: Array<Mount>;
};
export type WorkerBootRequestHandlerOptions = Omit<SecondaryWorkerBootArgs, 'mountsBeforeWpInstall' | 'mountsAfterWpInstall'> & {
    onPHPInstanceCreated: PHPInstanceCreatedHook;
    spawnHandler: () => SpawnHandler;
};
export declare class PlaygroundCliBlueprintV2Worker extends PHPWorker {
    booted: boolean;
    blueprintTargetResolved: boolean;
    phpInstancesThatNeedMountsAfterTargetResolved: Set<PHP>;
    fileLockManager: FileLockManager | undefined;
    constructor(monitor: EmscriptenDownloadMonitor);
    /**
     * Call this method before boot() to use file locking.
     *
     * This method is separate from boot() to simplify the related Comlink.transferHandlers
     * setup – if an argument is a MessagePort, we're transferring it, not copying it.
     *
     * @see comlink-sync.ts
     * @see phpwasm-emscripten-library-file-locking-for-node.js
     */
    useFileLockManager(port: MessagePort): Promise<void>;
    bootWordPress(args: WorkerWordPressBootArgs, workerPostInstallMountsPort: MessagePort): Promise<void>;
    bootWorker(args: SecondaryWorkerBootArgs): Promise<void>;
    runBlueprintV2(args: WorkerRunBlueprintArgs, workerPostInstallMountsPort: MessagePort): Promise<void>;
    bootRequestHandler({ siteUrl, allow, phpVersion, processId, createFiles, constants, phpIniEntries, trace, nativeInternalDirPath, withIntl, withRedis, withMemcached, withXdebug, pathAliases, onPHPInstanceCreated, spawnHandler, }: WorkerBootRequestHandlerOptions): Promise<void>;
    mountAfterWordPressInstall(mounts: Array<Mount>): Promise<void>;
    applyPostInstallMountsToAllWorkers(postInstallMountsPort: MessagePort): Promise<void>;
    dispose(): Promise<void>;
}
export {};
