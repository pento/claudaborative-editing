/// <reference types="node" />
import type { Pooled } from '@php-wasm/universal';
import { type RemoteAPI } from '@php-wasm/universal';
import type { PlaygroundCliBlueprintV2Worker } from './worker-thread-v2';
import type { MessagePort as NodeMessagePort } from 'worker_threads';
import { type PlaygroundCliWorker, type RunCLIArgs, type SpawnedWorker, type WorkerType } from '../run-cli';
import type { CLIOutput } from '../cli-output';
/**
 * Boots Playground CLI workers using Blueprint version 2.
 *
 * Progress tracking, downloads, steps, and all other features are
 * implemented in PHP and orchestrated by the worker thread.
 */
export declare class BlueprintsV2Handler {
    private phpVersion;
    private siteUrl;
    private args;
    private cliOutput;
    constructor(args: RunCLIArgs, options: {
        siteUrl: string;
        cliOutput: CLIOutput;
    });
    getWorkerType(): WorkerType;
    bootWordPress(playground: Pooled<PlaygroundCliWorker>, workerPostInstallMountsPort: NodeMessagePort): Promise<Pooled<PlaygroundCliWorker>>;
    bootRequestHandler({ worker, fileLockManagerPort, nativeInternalDirPath, }: {
        worker: SpawnedWorker;
        fileLockManagerPort: NodeMessagePort;
        nativeInternalDirPath: string;
    }): Promise<RemoteAPI<PlaygroundCliBlueprintV2Worker>>;
}
