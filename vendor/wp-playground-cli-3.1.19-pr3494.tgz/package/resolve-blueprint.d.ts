type ResolveBlueprintOptions = {
    sourceString: string | undefined;
    blueprintMayReadAdjacentFiles: boolean;
};
/**
 * Resolves a blueprint from a URL or a local path.
 *
 * @TODO: Extract the common Blueprint resolution logic between CLI and
 *        the website into a single, isomorphic resolveBlueprint() function.
 *        Still retain the CLI-specific bits in the CLI package.
 *
 * @param sourceString - The source string to resolve the blueprint from.
 * @param blueprintMayReadAdjacentFiles - Whether the blueprint may read adjacent files.
 * @returns The resolved blueprint.
 */
export declare function resolveBlueprint({ sourceString, blueprintMayReadAdjacentFiles, }: ResolveBlueprintOptions): Promise<import("@wp-playground/storage").ReadableFilesystemBackend | undefined>;
export {};
