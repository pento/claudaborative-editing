/**
 * Manages formatted terminal output for the WordPress Playground CLI.
 *
 * This class handles two distinct output modes:
 * - TTY (terminal): Uses ANSI escape codes for colors and in-place progress updates
 * - Non-TTY (pipes/logs): Skips progress updates entirely, outputs plain text only
 *
 * Progress updates rewrite the same line in TTY mode to create smooth animations.
 * When output is piped or redirected, progress is suppressed to avoid cluttering
 * logs with intermediate states - only the final "Ready!" message appears.
 */
/// <reference types="node" />
import type { Mount } from '@php-wasm/cli-util';
export interface CLIOutputOptions {
    /** Verbosity level: 'quiet', 'normal', or 'debug' */
    verbosity: string;
    /** Output stream to write to. Defaults to process.stdout */
    writeStream?: NodeJS.WriteStream;
}
/**
 * Configuration details displayed at CLI startup.
 */
export interface ConfigSummary {
    phpVersion: string;
    wpVersion: string;
    port: number;
    xdebug: boolean;
    intl: boolean;
    redis: boolean;
    memcached: boolean;
    /** All mounts (both manual and auto-detected). Auto-mounts have autoMounted: true */
    mounts: Mount[];
    blueprint?: string;
}
export declare class CLIOutput {
    private verbosity;
    private writeStream;
    private lastProgressLine;
    private progressActive;
    constructor(options: CLIOutputOptions);
    get isTTY(): boolean;
    /**
     * Determines if progress updates should be rendered.
     *
     * Returns false when output is piped, redirected, or in CI environments.
     * This prevents progress spam in logs - users only see the final outcome.
     */
    get shouldRender(): boolean;
    get isQuiet(): boolean;
    /**
     * ANSI formatting helpers.
     *
     * These only apply color codes when outputting to a terminal (TTY).
     * When piped to files or non-TTY streams, they return plain text to
     * avoid polluting logs with escape sequences.
     */
    private bold;
    private dim;
    private green;
    private cyan;
    private yellow;
    private red;
    printBanner(): void;
    /**
     * Prints the configuration summary before starting the server.
     *
     * Displays PHP/WordPress versions, enabled extensions, all mounts
     * (with auto-mounts labeled), and any loaded blueprint. This gives
     * users a clear view of what's configured before the server boots.
     */
    printConfig(config: ConfigSummary): void;
    /**
     * Starts a progress indicator that updates in-place.
     *
     * Subsequent updateProgress() calls rewrite the same line in TTY mode.
     * When output is piped or redirected, progress is completely skipped.
     */
    startProgress(message: string): void;
    /**
     * Updates the current progress message and optional percentage.
     *
     * Rewrites the current line using ANSI cursor control in TTY mode.
     * Identical messages are skipped to prevent flickering. When piped,
     * this method does nothing (early return via shouldRender check).
     */
    updateProgress(message: string, percent?: number): void;
    /**
     * Completes the progress indicator and moves to a new line.
     *
     * Optionally displays a final message before finishing. In TTY mode,
     * this ensures the cursor moves to the next line after the progress.
     */
    finishProgress(finalMessage?: string): void;
    /**
     * Prints a status message, interrupting any active progress.
     *
     * Unlike progress updates, status messages are always printed on their
     * own line. Any active progress indicator is cleared before the message.
     */
    printStatus(message: string): void;
    /**
     * Prints an error message.
     *
     * Errors are always shown, even in quiet mode, and interrupt any
     * active progress display to ensure visibility.
     */
    printError(message: string): void;
    /**
     * Prints the final "server ready" message with the URL.
     *
     * Note: The exact wording "WordPress is running on" is checked by
     * CI tests, so changes to this string will break test assertions.
     */
    printReady(url: string, workerCount: number): void;
    printWarning(message: string): void;
    /**
     * Prints the phpMyAdmin URL when the --phpmyadmin flag is enabled.
     */
    printPhpMyAdminUrl(url: string): void;
}
