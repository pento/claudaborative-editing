/// <reference types="node" />
import type { FileLockManager } from '@php-wasm/universal';
import { EmscriptenDownloadMonitor } from '@php-wasm/progress';
import type { PathAlias, SupportedPHPVersion } from '@php-wasm/universal';
import { PHPWorker } from '@php-wasm/universal';
import { type WordPressInstallMode } from '@wp-playground/wordpress';
import { type MessagePort } from 'worker_threads';
import type { Mount } from '@php-wasm/cli-util';
export type WorkerBootWordPressOptions = {
    siteUrl: string;
    wpVersion?: string;
    wordpressInstallMode: WordPressInstallMode;
    wordPressZip?: ArrayBuffer;
    sqliteIntegrationPluginZip?: ArrayBuffer;
    dataSqlPath?: string;
    /**
     * PHP constants to define via php.defineConstant().
     */
    constants?: Record<string, string | number | boolean>;
};
interface WorkerBootRequestHandlerOptions {
    siteUrl: string;
    phpVersion: SupportedPHPVersion;
    processId: number;
    trace: boolean;
    nativeInternalDirPath: string;
    mountsBeforeWpInstall: Array<Mount>;
    mountsAfterWpInstall: Array<Mount>;
    followSymlinks: boolean;
    withIntl?: boolean;
    withRedis?: boolean;
    withMemcached?: boolean;
    withXdebug?: boolean;
    pathAliases?: PathAlias[];
}
export declare class PlaygroundCliBlueprintV1Worker extends PHPWorker {
    bootedRequestHandler: boolean;
    bootedWordPress: boolean;
    fileLockManager: FileLockManager | undefined;
    constructor(monitor: EmscriptenDownloadMonitor);
    /**
     * Call this method before boot() to use file locking.
     *
     * This method is separate from boot() to simplify the related Comlink.transferHandlers
     * setup – if an argument is a MessagePort, we're transferring it, not copying it.
     *
     * @see comlink-sync.ts
     * @see phpwasm-emscripten-library-file-locking-for-node.js
     */
    useFileLockManager(port: MessagePort): Promise<void>;
    bootWordPress(options: WorkerBootWordPressOptions, workerPostInstallMountsPort: MessagePort): Promise<void>;
    bootRequestHandler(options: WorkerBootRequestHandlerOptions): Promise<void>;
    mountAfterWordPressInstall(mounts: Array<Mount>): Promise<void>;
    dispose(): Promise<void>;
}
export {};
