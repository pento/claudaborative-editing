/// <reference types="node" />
import { type Pooled } from '@php-wasm/universal';
import type { PlaygroundCliBlueprintV1Worker } from './worker-thread-v1';
import type { MessagePort as NodeMessagePort } from 'worker_threads';
import { type PlaygroundCliWorker, type RunCLIArgs, type SpawnedWorker, type WorkerType } from '../run-cli';
import type { CLIOutput } from '../cli-output';
/**
 * Boots Playground CLI workers using Blueprint version 1.
 *
 * Progress tracking, downloads, steps, and all other features are
 * implemented in TypeScript and orchestrated by this class.
 */
export declare class BlueprintsV1Handler {
    private siteUrl;
    private args;
    private cliOutput;
    constructor(args: RunCLIArgs, options: {
        siteUrl: string;
        cliOutput: CLIOutput;
    });
    getWorkerType(): WorkerType;
    bootWordPress(playground: Pooled<PlaygroundCliWorker>, workerPostInstallMountsPort: NodeMessagePort): Promise<Pooled<PlaygroundCliWorker>>;
    bootRequestHandler({ worker, fileLockManagerPort, nativeInternalDirPath, }: {
        worker: SpawnedWorker;
        fileLockManagerPort: NodeMessagePort;
        nativeInternalDirPath: string;
    }): Promise<import("@php-wasm/universal").RemoteAPI<PlaygroundCliBlueprintV1Worker>>;
    compileInputBlueprint(additionalBlueprintSteps: any[]): Promise<import("@wp-playground/blueprints").CompiledBlueprintV1>;
    private getEffectiveBlueprint;
}
