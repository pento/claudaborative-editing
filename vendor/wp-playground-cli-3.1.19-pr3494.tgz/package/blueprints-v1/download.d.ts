import type { EmscriptenDownloadMonitor } from '@php-wasm/progress';
export declare const CACHE_FOLDER: string;
export declare function fetchSqliteIntegration(): Promise<File>;
export declare function cachedDownload(remoteUrl: string, cacheKey: string, monitor: EmscriptenDownloadMonitor): Promise<File>;
export declare function readAsFile(path: string, fileName?: string): File;
