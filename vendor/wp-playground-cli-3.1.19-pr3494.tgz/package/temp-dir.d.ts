/**
 * Create a temp dir for the Playground CLI.
 *
 * The temp dir is created in the system temp dir and is named
 * based on the Playground CLI binary name and the process ID.
 *
 * @param substrToIdentifyTempDirs The substring to identify the temp dir.
 * @param autoCleanup Whether to skip cleanup on process exit. Primarily used for unit testing.
 * @returns The path to the temp dir.
 */
export declare function createPlaygroundCliTempDir(substrToIdentifyTempDirs: string, autoCleanup?: boolean): Promise<import("tmp-promise").DirectoryResult>;
/**
 * Cleanup stale Playground temp dirs.
 *
 * A temp dir is considered stale if it is older than the specified age
 * and the associated process no longer exists.
 *
 * @param substrToIdentifyTempDirs The substring to identify the temp dir.
 * @param staleAgeInMillis The age in milliseconds after which a temp dir is considered stale.
 * @param tempRootDir The root directory of the temp dirs.
 */
export declare function cleanupStalePlaygroundTempDirs(substrToIdentifyTempDirs: string, staleAgeInMillis: number, tempRootDir: string): Promise<void>;
