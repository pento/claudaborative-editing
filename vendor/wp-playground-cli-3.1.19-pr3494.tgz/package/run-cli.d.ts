/// <reference types="node" />
/// <reference types="node" />
import { type Pooled, type PathAlias, type SupportedPHPVersion } from '@php-wasm/universal';
import type { BlueprintBundle, BlueprintV1Declaration, BlueprintV2Declaration } from '@wp-playground/blueprints';
import type { Server } from 'http';
import { Worker } from 'worker_threads';
import type { PlaygroundCliBlueprintV1Worker } from './blueprints-v1/worker-thread-v1';
import type { PlaygroundCliBlueprintV2Worker } from './blueprints-v2/worker-thread-v2';
import type { XdebugOptions } from '@php-wasm/node';
import type { MessagePort as NodeMessagePort } from 'worker_threads';
import { type WordPressInstallMode } from '@wp-playground/wordpress';
import { type Mount } from '@php-wasm/cli-util';
export declare const LogVerbosity: {
    readonly Quiet: {
        readonly name: "quiet";
        readonly severity: {
            readonly name: "fatal";
            readonly level: 0;
        };
    };
    readonly Normal: {
        readonly name: "normal";
        readonly severity: {
            readonly name: "info";
            readonly level: 4;
        };
    };
    readonly Debug: {
        readonly name: "debug";
        readonly severity: {
            readonly name: "debug";
            readonly level: 5;
        };
    };
};
type LogVerbosity = (typeof LogVerbosity)[keyof typeof LogVerbosity]['name'];
export type WorkerType = 'v1' | 'v2';
/**
 * Parse the CLI args and run the appropriate command.
 *
 * @param argsToParse string[] The CLI args to parse.
 */
export declare function parseOptionsAndRunCLI(argsToParse: string[]): Promise<{
    [Symbol.asyncDispose]: () => Promise<void>;
    [internalsKeyForTesting]: {
        cliServer: RunCLIServer;
    };
}>;
export interface RunCLIArgs {
    /**
     * `_` holds positional tokens in the order they appeared.
     * `_[0]` will typically be the command name.
     */
    _?: string[];
    blueprint?: BlueprintV1Declaration | BlueprintV2Declaration | BlueprintBundle;
    command: 'start' | 'server' | 'run-blueprint' | 'build-snapshot' | 'php';
    debug?: boolean;
    login?: boolean;
    mount?: Mount[];
    'mount-before-install'?: Mount[];
    outfile?: string;
    php?: SupportedPHPVersion;
    port?: number;
    'site-url'?: string;
    quiet?: boolean;
    verbosity?: LogVerbosity;
    wp?: string;
    autoMount?: string;
    pathAliases?: PathAlias[];
    experimentalTrace?: boolean;
    internalCookieStore?: boolean;
    'additional-blueprint-steps'?: any[];
    intl?: boolean;
    phpmyadmin?: boolean | string;
    redis?: boolean;
    memcached?: boolean;
    xdebug?: boolean | XdebugOptions;
    experimentalUnsafeIdeIntegration?: string[];
    experimentalDevtools?: boolean;
    'experimental-blueprints-v2-runner'?: boolean;
    wordpressInstallMode?: WordPressInstallMode;
    /**
     * PHP string constants defined via --define flag.
     * Set via php.defineConstant(), process-specific only.
     */
    define?: Record<string, string>;
    /**
     * PHP boolean constants defined via --define-bool flag.
     * Set via php.defineConstant(), process-specific only.
     */
    'define-bool'?: Record<string, boolean>;
    /**
     * PHP number constants defined via --define-number flag.
     * Set via php.defineConstant(), process-specific only.
     */
    'define-number'?: Record<string, number>;
    skipSqliteSetup?: boolean;
    followSymlinks?: boolean;
    'blueprint-may-read-adjacent-files'?: boolean;
    mode?: 'mount-only' | 'create-new-site' | 'apply-to-existing-site';
    'db-engine'?: 'sqlite' | 'mysql';
    'db-host'?: string;
    'db-user'?: string;
    'db-pass'?: string;
    'db-name'?: string;
    'db-path'?: string;
    'truncate-new-site-directory'?: boolean;
    allow?: string;
    path?: string;
    skipBrowser?: boolean;
    noAutoMount?: boolean;
    reset?: boolean;
}
export type PlaygroundCliWorker = PlaygroundCliBlueprintV1Worker | PlaygroundCliBlueprintV2Worker;
export declare const internalsKeyForTesting: unique symbol;
export interface RunCLIServer extends AsyncDisposable {
    playground: Pooled<PlaygroundCliWorker>;
    server: Server;
    serverUrl: string;
    [Symbol.asyncDispose](): Promise<void>;
    [internalsKeyForTesting]: {
        workerThreadCount: number;
    };
}
export { mergeDefinedConstants } from './defines';
export declare function runCLI(args: RunCLIArgs & {
    command: 'build-snapshot' | 'run-blueprint' | 'php';
}): Promise<void>;
export declare function runCLI(args: RunCLIArgs & {
    command: 'start';
}): Promise<RunCLIServer>;
export declare function runCLI(args: RunCLIArgs & {
    command: 'server';
}): Promise<RunCLIServer>;
export declare function runCLI(args: RunCLIArgs): Promise<RunCLIServer | void>;
export type SpawnedWorker = {
    processId: number;
    worker: Worker;
    phpPort: NodeMessagePort;
};
/**
 * A statically analyzable function that spawns a worker thread of a given type.
 *
 * **Important:** This function builds to code that has the worker URL hardcoded
 * inline, e.g. `new Worker(new URL('./worker-thread-v1.js', import.meta.url))`.
 * This allows the downstream consumers to statically analyze the code, recognize
 * it uses workers, create new entrypoints, and rewrite the new Worker() calls.
 *
 * @param workerType
 * @returns
 */
export declare function spawnWorkerThread(workerType: 'v1' | 'v2', { onExit }?: {
    onExit?: (code: number) => void;
}): Promise<SpawnedWorker>;
