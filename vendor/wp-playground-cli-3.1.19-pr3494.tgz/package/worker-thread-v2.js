import { logger as T, errorLogPath as H } from "@php-wasm/logger";
import { createNodeFsMountHandler as W, loadNodeRuntime as M, bindUserSpace as $ } from "@php-wasm/node";
import { EmscriptenDownloadMonitor as I } from "@php-wasm/progress";
import { exposeAPI as v, PHPWorker as A, consumeAPISync as S, setPhpIniEntries as L, writeFiles as B, sandboxedSpawnHandlerFactory as C, PHPResponse as E, PHPExecutionFailureError as F, consumeAPI as g, releaseApiProxy as U } from "@php-wasm/universal";
import { joinPaths as q, sprintf as D } from "@php-wasm/util";
import { runBlueprintV2 as O } from "@wp-playground/blueprints";
import { setupPlatformLevelMuPlugins as j, preloadPhpInfoRoute as V, bootRequestHandler as N } from "@wp-playground/wordpress";
import { existsSync as G } from "fs";
import m from "path";
import { rootCertificates as Y } from "tls";
import { MessageChannel as z, parentPort as K } from "worker_threads";
import { s as J, b as Q } from "./run-cli-DWkUdARs.js";
async function b(s, e) {
  for (const t of e)
    try {
      s.mkdir(t.vfsPath), await s.mount(
        t.vfsPath,
        W(t.hostPath)
      );
    } catch {
      a.stderr(
        `\x1B[31m\x1B[1mError mounting path ${t.hostPath} at ${t.vfsPath}\x1B[0m
`
      ), process.exit(1);
    }
}
function X(s, e, ...t) {
  console.log(
    performance.now().toFixed(6).padStart(15, "0"),
    s.toString().padStart(16, "0"),
    D(e, ...t)
  );
}
Object.defineProperty(process.stdout, "isTTY", { value: !0 });
Object.defineProperty(process.stderr, "isTTY", { value: !0 });
const a = {
  lastWriteWasProgress: !1,
  progress(s) {
    Q(process.stdout) && (process.stdout.isTTY ? (a.lastWriteWasProgress || process.stdout.write(`
`), process.stdout.write("\r\x1B[K" + s), a.lastWriteWasProgress = !0) : console.log(s));
  },
  stdout(s) {
    process.stdout.write(`


`), a.lastWriteWasProgress && (a.lastWriteWasProgress = !1), process.stdout.write(s);
  },
  stderr(s) {
    process.stdout.write(`


`), a.lastWriteWasProgress && (a.lastWriteWasProgress = !1), process.stderr.write(s);
  }
};
class Z extends A {
  constructor(e) {
    super(void 0, e), this.booted = !1, this.blueprintTargetResolved = !1, this.phpInstancesThatNeedMountsAfterTargetResolved = /* @__PURE__ */ new Set();
  }
  /**
   * Call this method before boot() to use file locking.
   *
   * This method is separate from boot() to simplify the related Comlink.transferHandlers
   * setup – if an argument is a MessagePort, we're transferring it, not copying it.
   *
   * @see comlink-sync.ts
   * @see phpwasm-emscripten-library-file-locking-for-node.js
   */
  async useFileLockManager(e) {
    this.fileLockManager = await S(e);
  }
  async bootWordPress(e, t) {
    const o = await this.__internal_getRequestHandler().getPrimaryPhp();
    if (o.defineConstant("WP_DEBUG", "true"), o.defineConstant("WP_DEBUG_LOG", "true"), o.defineConstant("WP_DEBUG_DISPLAY", "false"), o.defineConstant("WP_HOME", e.siteUrl), o.defineConstant("WP_SITEURL", e.siteUrl), await L(o, {
      "openssl.cafile": "/internal/shared/ca-bundle.crt",
      allow_url_fopen: "1",
      disable_functions: ""
    }), await j(o), await B(o, "/", {
      "/internal/shared/ca-bundle.crt": Y.join(`
`)
    }), await V(
      o,
      q(new URL(e.siteUrl).pathname, "phpinfo.php")
    ), e.mode === "mount-only") {
      await this.applyPostInstallMountsToAllWorkers(
        t
      );
      return;
    }
    await this.runBlueprintV2(
      {
        // TODO: Do we really want to create a new object or can we pass args directly?
        ...e
      },
      t
    );
  }
  async bootWorker(e) {
    await this.bootRequestHandler({
      ...e,
      onPHPInstanceCreated: async (t) => {
        await b(t, e.mountsBeforeWpInstall || []), await b(t, e.mountsAfterWpInstall || []), t.isDir("/wordpress/wp-content") || t.mkdir("/wordpress/wp-content"), t.isDir("/wordpress/wp-content/database") || t.mkdir("/wordpress/wp-content/database"), t.isFile("/wordpress/wp-content/database/.htaccess") || t.writeFile(
          "/wordpress/wp-content/database/.htaccess",
          "deny from all"
        ), t.isFile("/wordpress/wp-content/database/index.php") || t.writeFile(
          "/wordpress/wp-content/database/index.php",
          "deny from all"
        );
      },
      spawnHandler: () => C(
        () => ee(e, this.fileLockManager)
      )
    });
  }
  async runBlueprintV2(e, t) {
    const o = this.__internal_getRequestHandler(), { php: u, reap: h } = await o.instanceManager.acquirePHPInstance(), w = this.__internal_getPHP();
    let f = () => {
    };
    if (typeof e.blueprint == "string") {
      const n = m.resolve(process.cwd(), e.blueprint);
      G(n) && (w.mkdir("/internal/shared/cwd"), f = await w.mount(
        "/internal/shared/cwd",
        W(m.dirname(n))
      ), e.blueprint = m.join(
        "/internal/shared/cwd",
        m.basename(e.blueprint)
      ));
    }
    try {
      const i = [
        "mode",
        "db-engine",
        "db-host",
        "db-user",
        "db-pass",
        "db-name",
        "db-path",
        "truncate-new-site-directory",
        "allow"
      ].filter((r) => r in e).map((r) => `--${r}=${e[r]}`);
      i.push(`--site-url=${e.siteUrl}`);
      const l = await O({
        php: u,
        blueprint: e.blueprint,
        blueprintOverrides: {
          additionalSteps: e["additional-blueprint-steps"],
          wordpressVersion: e.wp
        },
        cliArgs: i,
        onMessage: async (r) => {
          switch (r.type) {
            case "blueprint.target_resolved": {
              this.blueprintTargetResolved || (this.blueprintTargetResolved = !0, await this.applyPostInstallMountsToAllWorkers(
                t
              ));
              break;
            }
            case "blueprint.progress": {
              const p = `${r.caption.trim()} – ${r.progress.toFixed(
                2
              )}%`;
              a.progress(p);
              break;
            }
            case "blueprint.error": {
              const p = "\x1B[31m", c = "\x1B[1m", d = "\x1B[0m";
              e.verbosity === "debug" && r.details ? a.stderr(
                `${p}${c}Fatal error:${d} Uncaught ${r.details.exception}: ${r.details.message}
  at ${r.details.file}:${r.details.line}
` + (r.details.trace ? r.details.trace + `
` : "")
              ) : a.stderr(
                `${p}${c}Error:${d} ${r.message}
`
              );
              break;
            }
          }
        }
      });
      if (e.verbosity === "debug" && (l.stdout.pipeTo(
        new WritableStream({
          write(r) {
            process.stdout.write(r);
          }
        })
      ), l.stderr.pipeTo(
        new WritableStream({
          write(r) {
            process.stderr.write(r);
          }
        })
      )), await l.finished, await l.exitCode !== 0) {
        const r = await E.fromStreamedResponse(l);
        throw new F(
          `PHP.run() failed with exit code ${r.exitCode}. ${r.errors} ${r.text}`,
          r,
          "request"
        );
      }
    } catch (n) {
      let i = "";
      try {
        i = u.readFileAsText(H);
      } catch {
      }
      throw n.phpLogs = i, n;
    } finally {
      h(), f();
    }
  }
  async bootRequestHandler({
    siteUrl: e,
    allow: t,
    phpVersion: o,
    processId: u,
    createFiles: h,
    constants: w,
    phpIniEntries: f,
    trace: n,
    nativeInternalDirPath: i,
    withIntl: l,
    withRedis: r,
    withMemcached: p,
    withXdebug: c,
    pathAliases: d,
    onPHPInstanceCreated: k,
    spawnHandler: x
  }) {
    if (this.booted)
      throw new Error("Playground already booted");
    this.booted = !0;
    try {
      const P = await N({
        siteUrl: e,
        createPhpRuntime: async () => await M(o, {
          fileLockManager: this.fileLockManager,
          emscriptenOptions: {
            processId: u,
            trace: n ? X : void 0,
            ENV: {
              DOCROOT: "/wordpress"
            },
            nativeInternalDirPath: i,
            bindUserSpace: (R) => $(
              {
                fileLockManager: this.fileLockManager
              },
              R
            )
          },
          followSymlinks: t?.includes("follow-symlinks"),
          withIntl: l,
          withRedis: r,
          withMemcached: p,
          withXdebug: c
        }),
        maxPhpInstances: 1,
        onPHPInstanceCreated: k,
        sapiName: "cli",
        createFiles: h,
        constants: w,
        phpIniEntries: f,
        pathAliases: d,
        cookieStore: !1,
        spawnHandler: x
      });
      this.__internal_setRequestHandler(P);
      const _ = await P.getPrimaryPhp();
      await this.setPrimaryPHP(_), te();
    } catch (P) {
      throw re(P), P;
    }
  }
  async mountAfterWordPressInstall(e) {
    await b(this.__internal_getPHP(), e);
  }
  async applyPostInstallMountsToAllWorkers(e) {
    const t = g(e);
    await t(), t[U]();
  }
  // Provide a named disposal method that can be invoked via comlink.
  async dispose() {
    await this[Symbol.asyncDispose]();
  }
}
async function ee({
  siteUrl: s,
  allow: e,
  phpVersion: t,
  createFiles: o,
  constants: u,
  phpIniEntries: h,
  trace: w,
  nativeInternalDirPath: f,
  withXdebug: n,
  pathAliases: i,
  mountsBeforeWpInstall: l,
  mountsAfterWpInstall: r
}, p) {
  const c = await J("v2"), d = g(
    c.phpPort
  );
  return d.useFileLockManager(p), await d.bootWorker({
    siteUrl: s,
    allow: e,
    phpVersion: t,
    createFiles: o,
    constants: u,
    phpIniEntries: h,
    processId: c.processId,
    trace: w,
    nativeInternalDirPath: f,
    withXdebug: n,
    pathAliases: i,
    mountsBeforeWpInstall: l,
    mountsAfterWpInstall: r
  }), {
    php: d,
    reap: () => {
      try {
        d.dispose();
      } catch {
      }
      try {
        c.worker.terminate();
      } catch {
      }
    }
  };
}
process.on("unhandledRejection", (s) => {
  T.error("Unhandled rejection:", s);
});
const y = new z(), [te, re] = v(
  new Z(new I()),
  void 0,
  y.port1
);
K?.postMessage(
  {
    command: "worker-script-initialized",
    phpPort: y.port2
  },
  [y.port2]
);
export {
  Z as PlaygroundCliBlueprintV2Worker
};
//# sourceMappingURL=worker-thread-v2.js.map
