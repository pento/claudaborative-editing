import { spawn as i } from "child_process";
function t() {
  return !("Suspending" in WebAssembly || process.env.PLAYGROUND_NO_JSPI_RESPAWN || process.versions.bun || "Deno" in globalThis || process.execArgv.includes("--experimental-wasm-jspi") || parseInt(process.versions.node.split(".")[0], 10) < 23);
}
function o() {
  const r = process.argv.slice(2);
  import("./run-cli-DWkUdARs.js").then((e) => e.c).then(({ parseOptionsAndRunCLI: e }) => {
    e(r);
  });
}
if (t()) {
  const r = Date.now(), e = i(
    process.execPath,
    [
      "--experimental-wasm-jspi",
      ...process.execArgv,
      ...process.argv.slice(1)
    ],
    { stdio: "inherit" }
  );
  for (const s of ["SIGINT", "SIGTERM"])
    process.on(s, () => e.kill(s));
  e.on("error", () => {
    o();
  }), e.on("close", (s, n) => {
    if (s !== 0 && !n && Date.now() - r < 1e3) {
      o();
      return;
    }
    n ? process.kill(process.pid, n) : process.exit(s);
  });
} else
  o();
//# sourceMappingURL=cli.js.map
